"""
Modern connection hub for Call Break.

Inspired by party-game hubs with bold cards and animated accents.
"""

from kivy.animation import Animation
from kivy.clock import Clock
from kivy.graphics import Color, Rectangle, RoundedRectangle
from kivy.properties import NumericProperty
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.screenmanager import Screen

from networking.game_code import ACTIVE_GAMES
from ui.widgets.modern_controls import CircularButton, IconButton, ModernButton, ModernOutlineButton


class MainMenuScreen(Screen):
    """Modern connection hub with host/join cards and player selector."""

    def __init__(self, app, **kwargs):
        super().__init__(**kwargs)
        self.app = app
        self.player_selector = None
        self.build_ui()

    def build_ui(self):
        root = FloatLayout(size_hint=(1, 1))

        # Animated gradient background
        with root.canvas.before:
            Color(0.08, 0.12, 0.18, 1)
            self.bg1 = Rectangle(pos=root.pos, size=root.size)
            self.bg2_color = Color(0.12, 0.16, 0.24, 0.5)
            self.bg2 = Rectangle(pos=root.pos, size=root.size)
        root.bind(size=lambda *_: self._update_bg(root), pos=lambda *_: self._update_bg(root))

        def animate_bg(_dt):
            anim = Animation(a=0.5, duration=3) + Animation(a=0.8, duration=3)
            anim.repeat = True
            anim.bind(on_progress=lambda inst, prog: setattr(self.bg2_color, "a", inst.a))
            anim.start(self.bg2_color)

        Clock.schedule_once(animate_bg, 0.5)

        # Header with logo
        header = BoxLayout(
            orientation="vertical",
            size_hint=(1, 0.2),
            pos_hint={"x": 0, "top": 1},
            padding=[24, 24, 24, 0],
            spacing=5,
        )

        title = Label(
            text="CALL BREAK",
            font_size="48sp",
            bold=True,
            color=(1, 0.84, 0, 1),
        )
        header.add_widget(title)

        subtitle = Label(
            text="Multiplayer Card Game",
            font_size="16sp",
            color=(1, 1, 1, 0.6),
        )
        header.add_widget(subtitle)

        root.add_widget(header)

        # Player count selector
        self.player_selector = ModernPlayerSelector()
        self.player_selector.pos_hint = {"center_x": 0.5, "center_y": 0.7}
        root.add_widget(self.player_selector)

        # Connection cards container
        cards_container = BoxLayout(
            orientation="horizontal",
            size_hint=(0.92, 0.35),
            pos_hint={"center_x": 0.5, "center_y": 0.35},
            spacing=16,
        )

        host_card = ModernConnectionCard(
            title="HOST",
            subtitle="Create a new game",
            icon="👑",
            color=(0.2, 0.8, 0.4, 1),
            on_press=self.goto_host,
        )
        cards_container.add_widget(host_card)

        join_card = ModernConnectionCard(
            title="JOIN",
            subtitle="Enter game code",
            icon="🔍",
            color=(0.2, 0.6, 0.9, 1),
            on_press=self.goto_join,
        )
        cards_container.add_widget(join_card)

        root.add_widget(cards_container)

        # Quick join scan
        quick_join_btn = ModernOutlineButton(
            text="📡 SCAN NEARBY GAMES",
            size_hint=(0.8, None),
            height=56,
            pos_hint={"center_x": 0.5, "y": 0.08},
        )
        quick_join_btn.bind(on_press=self.scan_games)
        root.add_widget(quick_join_btn)

        # Settings & Help
        settings_btn = IconButton(
            icon="⚙️",
            pos_hint={"x": 0.02, "y": 0.02},
        )
        settings_btn.bind(on_press=self.open_settings)
        root.add_widget(settings_btn)

        help_btn = IconButton(
            icon="❓",
            pos_hint={"right": 0.98, "y": 0.02},
        )
        help_btn.bind(on_press=self.show_help)
        root.add_widget(help_btn)

        self.add_widget(root)

    # ---------- Actions ----------

    def goto_host(self, *_):
        num_players = self.player_selector.current_count
        success, message = self.app.start_wifi_server(num_players)
        if not success:
            self._show_popup("Host Error", message)

    def goto_join(self, *_):
        if self.manager:
            self.manager.current = "join"

    def scan_games(self, *_):
        # Show any locally registered games (best-effort discovery)
        content = BoxLayout(orientation="vertical", padding=16, spacing=10)
        if ACTIVE_GAMES:
            for code, (ip, port, host_name) in ACTIVE_GAMES.items():
                lbl = Label(
                    text=f"{code} • {host_name} @ {ip}:{port}",
                    font_size="16sp",
                    color=(1, 1, 1, 0.85),
                    size_hint_y=None,
                    height=28,
                )
                content.add_widget(lbl)
        else:
            content.add_widget(Label(text="No nearby games found yet.", font_size="16sp"))
        popup = Popup(title="Nearby Games", content=content, size_hint=(0.8, 0.6))
        close_btn = ModernButton(text="Close", size_hint=(1, None), height=48)
        close_btn.bind(on_press=popup.dismiss)
        content.add_widget(close_btn)
        popup.open()

    def open_settings(self, *_):
        self._show_popup("Settings", "Settings screen coming soon.")

    def show_help(self, *_):
        text = (
            "1. Tap HOST to create a room and share the 6-digit code.\n\n"
            "2. Tap JOIN to enter a code or pick from nearby scans.\n\n"
            "3. Everyone must be on the same WiFi network."
        )
        self._show_popup("How to Connect", text)

    # ---------- Helpers ----------

    def _show_popup(self, title, message):
        content = BoxLayout(orientation="vertical", padding=14, spacing=10)
        content.add_widget(Label(text=message, halign="left", valign="middle"))
        close_btn = ModernButton(text="OK", size_hint=(1, None), height=48)
        content.add_widget(close_btn)
        popup = Popup(title=title, content=content, size_hint=(0.8, 0.5))
        close_btn.bind(on_press=lambda *_: popup.dismiss())
        popup.open()

    def _update_bg(self, root):
        self.bg1.pos = root.pos
        self.bg1.size = root.size
        self.bg2.pos = root.pos
        self.bg2.size = root.size


class ModernConnectionCard(ButtonBehavior, FloatLayout):
    """Animated card for Host/Join options."""

    scale_factor = NumericProperty(1.0)

    def __init__(self, title, subtitle, icon, color, on_press=None, **kwargs):
        super().__init__(**kwargs)
        self.size_hint = (0.5, 1)
        self.card_color = color
        self.press_callback = on_press

        with self.canvas.before:
            Color(0, 0, 0, 0.3)
            self.shadow1 = RoundedRectangle(pos=self.pos, size=self.size, radius=[12])
            Color(0, 0, 0, 0.2)
            self.shadow2 = RoundedRectangle(pos=self.pos, size=self.size, radius=[12])
            self.bg_color_instr = Color(*color)
            self.bg = RoundedRectangle(pos=self.pos, size=self.size, radius=[14])
            Color(1, 1, 1, 0.08)
            self.shine = RoundedRectangle(pos=self.pos, size=self.size, radius=[14])

        self.bind(pos=self.update_graphics, size=self.update_graphics, scale_factor=self.update_graphics)

        content = BoxLayout(orientation="vertical", padding=20, spacing=8)
        icon_label = Label(text=icon, font_size="72sp", size_hint_y=0.5)
        content.add_widget(icon_label)
        title_label = Label(text=title, font_size="28sp", bold=True, color=(1, 1, 1, 1), size_hint_y=0.25)
        content.add_widget(title_label)
        subtitle_label = Label(text=subtitle, font_size="14sp", color=(1, 1, 1, 0.8), size_hint_y=0.25)
        content.add_widget(subtitle_label)
        self.add_widget(content)

    def on_press(self):
        Animation(scale_factor=0.96, duration=0.1).start(self)
        darker = tuple(c * 0.85 for c in self.card_color[:3]) + (1,)
        self.bg_color_instr.rgba = darker

    def on_release(self):
        Animation(scale_factor=1.0, duration=0.18, transition="out_elastic").start(self)
        self.bg_color_instr.rgba = self.card_color
        if self.press_callback:
            self.press_callback()

    def update_graphics(self, *args):
        # Keep visuals centered during scaling
        scaled_w = self.width * self.scale_factor
        scaled_h = self.height * self.scale_factor
        offset_x = (self.width - scaled_w) / 2
        offset_y = (self.height - scaled_h) / 2
        pos = (self.x + offset_x, self.y + offset_y)
        size = (scaled_w, scaled_h)
        for shape in (self.shadow1, self.shadow2, self.bg, self.shine):
            shape.pos = pos
            shape.size = size
        self.shine.pos = (pos[0], pos[1] + size[1] * 0.6)
        self.shine.size = (size[0], size[1] * 0.4)


class ModernPlayerSelector(BoxLayout):
    """Swipeable player count selector."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.orientation = "horizontal"
        self.size_hint = (0.7, None)
        self.height = 100
        self.spacing = 20
        self.current_count = 4

        minus_btn = CircularButton(text="−", size=(60, 60), background_color=(0.3, 0.3, 0.35, 1))
        minus_btn.bind(on_press=self.decrease)
        self.add_widget(minus_btn)

        count_container = FloatLayout()
        with count_container.canvas.before:
            Color(0.2, 0.25, 0.3, 1)
            self.count_bg = RoundedRectangle(pos=count_container.pos, size=(100, 100), radius=[50])
        count_container.bind(pos=self._update_bg, size=self._update_bg)

        self.count_label = Label(text=str(self.current_count), font_size="52sp", bold=True, color=(1, 0.84, 0, 1))
        count_container.add_widget(self.count_label)
        self.add_widget(count_container)

        plus_btn = CircularButton(text="+", size=(60, 60), background_color=(0.3, 0.3, 0.35, 1))
        plus_btn.bind(on_press=self.increase)
        self.add_widget(plus_btn)

    def increase(self, *_):
        if self.current_count < 12:
            self.current_count += 1
            self.update_display()

    def decrease(self, *_):
        if self.current_count > 2:
            self.current_count -= 1
            self.update_display()

    def update_display(self):
        self.count_label.text = str(self.current_count)
        anim = Animation(font_size="60sp", duration=0.12) + Animation(font_size="52sp", duration=0.12)
        anim.start(self.count_label)

    def _update_bg(self, instance, *_):
        self.count_bg.pos = instance.pos
        self.count_bg.size = (instance.width, instance.height)
