from kivy.clock import Clock
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.label import Label
from kivy.uix.screenmanager import Screen


class SplashScreen(Screen):
    """Simple splash screen placeholder."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = FloatLayout()
        self.label = Label(
            text="[b]Call Break[/b]\nLoading...",
            markup=True,
            font_size="28sp",
            halign="center",
            valign="middle",
            size_hint=(1, 1),
            pos_hint={"center_x": 0.5, "center_y": 0.5},
        )
        self.label.bind(size=self._update_text_size)

        self.hall_label = Label(
            text="[b][color=ff3333]HALL 14 Production[/color][/b]",
            markup=True,
            font_size="30sp",
            halign="center",
            valign="middle",
            size_hint=(1, 1),
            pos_hint={"center_x": 0.5, "center_y": 0.5},
            opacity=0,
        )
        self.hall_label.bind(size=self._update_hall_text_size)

        self.credit_label = Label(
            text="[b]Made by\nDivyansh Kumar Singh[/b]",
            markup=True,
            font_size="24sp",
            halign="center",
            valign="middle",
            size_hint=(1, 1),
            pos_hint={"center_x": 0.5, "center_y": 0.5},
        )
        self.credit_label.bind(size=self._update_credit_text_size)

        layout.add_widget(self.label)
        layout.add_widget(self.hall_label)
        layout.add_widget(self.credit_label)
        self.add_widget(layout)

    def _update_text_size(self, instance, _value):
        instance.text_size = instance.size

    def _update_credit_text_size(self, instance, _value):
        instance.text_size = instance.size

    def _update_hall_text_size(self, instance, _value):
        instance.text_size = instance.size

    def on_enter(self, *args):
        # Sequence: show spooky hall slide for 1s, then credit overlay for 2s.
        self.hall_label.opacity = 1
        self.credit_label.opacity = 0
        Clock.schedule_once(lambda *_: setattr(self.hall_label, "opacity", 0), 1.0)
        Clock.schedule_once(lambda *_: setattr(self.credit_label, "opacity", 1), 1.0)
        Clock.schedule_once(lambda *_: setattr(self.credit_label, "opacity", 0), 3.0)
        Clock.schedule_once(lambda *_: None, 0)
