"""
Modern UI controls used by the connection hub and host/join screens.
"""

from kivy.animation import Animation
from kivy.graphics import Color, Ellipse, Line, RoundedRectangle
from kivy.properties import ListProperty, NumericProperty
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.button import Button
from kivy.uix.label import Label


class ModernButton(Button):
    """Solid button with consistent styling."""

    def __init__(self, background_color=(0.2, 0.8, 0.4, 1), **kwargs):
        super().__init__(**kwargs)
        self.background_normal = ""
        self.background_color = background_color
        self.color = (1, 1, 1, 1)
        self.bold = True
        self.font_size = kwargs.get("font_size", "18sp")


class ModernOutlineButton(Button):
    """Outlined button with subtle hover/press feedback."""

    def __init__(self, background_color=(0.2, 0.6, 0.9, 1), **kwargs):
        super().__init__(**kwargs)
        self.background_normal = ""
        self.background_color = (0, 0, 0, 0)
        self.color = background_color
        self.border = (2, 2, 2, 2)
        self.bold = True
        self.font_size = kwargs.get("font_size", "16sp")


class IconButton(ButtonBehavior, Label):
    """Lightweight icon-style button."""

    def __init__(self, **kwargs):
        icon = kwargs.pop("icon", None)
        super().__init__(**kwargs)
        if icon:
            self.text = icon
        self.font_size = kwargs.get("font_size", "22sp")
        self.size_hint = kwargs.get("size_hint", (None, None)) or (None, None)
        if not self.size:
            self.size = (48, 48)

    def on_press(self):
        Animation(scale=0.92, duration=0.08).start(self)

    def on_release(self):
        Animation(scale=1.0, duration=0.12, transition="out_quad").start(self)


class CircularButton(ButtonBehavior, Label):
    """Circular +/- control used by the player selector."""

    bg_color = ListProperty([0.3, 0.3, 0.35, 1])
    scale_factor = NumericProperty(1.0)

    def __init__(self, size=(60, 60), background_color=(0.3, 0.3, 0.35, 1), **kwargs):
        super().__init__(**kwargs)
        self.size_hint = (None, None)
        self.size = size
        self.font_size = "32sp"
        self.bold = True
        self.bg_color = list(background_color)
        with self.canvas.before:
            self.color_instr = Color(*self.bg_color)
            self.circle = Ellipse(pos=self.pos, size=self.size)
        self.bind(pos=self._update_graphics, size=self._update_graphics, scale_factor=self._update_graphics)

    def _update_graphics(self, *args):
        scaled_w = self.width * self.scale_factor
        scaled_h = self.height * self.scale_factor
        offset_x = (self.width - scaled_w) / 2
        offset_y = (self.height - scaled_h) / 2
        self.circle.pos = (self.x + offset_x, self.y + offset_y)
        self.circle.size = (scaled_w, scaled_h)

    def on_press(self):
        Animation(scale_factor=0.9, duration=0.1).start(self)

    def on_release(self):
        Animation(scale_factor=1.0, duration=0.1).start(self)


class Divider(Line):
    """Simple dashed divider utility."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.dash_length = kwargs.get("dash_length", 4)
        self.dash_offset = kwargs.get("dash_offset", 2)
