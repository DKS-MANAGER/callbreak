from kivy.app import App
from kivy.properties import BooleanProperty, ListProperty, NumericProperty, StringProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.screenmanager import Screen


class WaitingLobbyScreen(Screen):
    """Displays connected players while waiting for the host to start."""

    is_host = BooleanProperty(False)
    max_players = NumericProperty(0)
    players = ListProperty()
    ip_address = StringProperty("")
    game_code = StringProperty("")

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.layout = BoxLayout(orientation="vertical", padding=16, spacing=10)
        self.header = Label(text="Waiting for players...", font_size="20sp", bold=True)
        self.ip_label = Label(text="", font_size="14sp")
        self.code_label = Label(text="", font_size="16sp", bold=True)
        self.players_label = Label(text="", font_size="14sp")
        self.ready_label = Label(text="", font_size="13sp")
        self.start_button = Button(text="Start Game", size_hint_y=None, height=48)
        self.start_button.bind(on_release=self.start_game_clicked)
        self.start_button.disabled = True
        self.ready_button = Button(text="I'm Ready", size_hint_y=None, height=44)
        self.ready_button.bind(on_release=self.send_ready_clicked)
        self.layout.add_widget(self.header)
        self.layout.add_widget(self.ip_label)
        self.layout.add_widget(self.code_label)
        self.layout.add_widget(self.players_label)
        self.layout.add_widget(self.ready_label)
        self.layout.add_widget(self.start_button)
        self.layout.add_widget(self.ready_button)
        self.add_widget(self.layout)

    def setup_host(self, ip_address: str, max_players: int, game_code: str = ""):
        self.is_host = True
        self.max_players = max_players
        self.ip_address = ip_address
        self.game_code = game_code
        self.ip_label.text = f"Host IP: {ip_address}" if ip_address else ""
        self.code_label.text = f"Game Code: {game_code}" if game_code else ""
        self.start_button.disabled = True
        self.ready_button.disabled = True
        self.ready_button.opacity = 0

    def update_players(self, players_list, max_players=None):
        self.players = players_list or []
        if max_players:
            self.max_players = max_players
        count_text = f"{len(self.players)} / {self.max_players or '?'} players"
        self.players_label.text = count_text
        ready_count = sum(1 for p in self.players if p.get("is_ready"))
        self.ready_label.text = f"Ready: {ready_count}/{len(self.players)}"
        if self.is_host and len(self.players) >= 2:
            self.start_button.disabled = ready_count != len(self.players)

    def start_game_clicked(self, _instance):
        if not self.is_host:
            return
        app = App.get_running_app()
        if app and app.network_server:
            # Host triggers start; server responsible for broadcasts.
            app.network_server.start_game()

    def send_ready_clicked(self, _instance):
        if self.is_host:
            return
        app = App.get_running_app()
        if app and app.network_client:
            app.network_client.send_ready()
            self.ready_button.disabled = True
            self.ready_button.text = "Ready sent"
