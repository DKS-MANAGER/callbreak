Place the whoosh sting here as whoosh.wav (short, low-volume, ~0.5–1.0s). Keep volume modest to avoid clipping; 44.1kHz mono is fine.
