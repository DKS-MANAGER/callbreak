"""
Trick Display - Center area showing current trick cards.
Styled for the new Teslatech-inspired palette.
"""

from math import cos, pi, sin
from typing import List

from kivy.graphics import Color, Ellipse, Line
from kivy.properties import ListProperty
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.label import Label

from ui.theme.colors import GameColors
from ui.widgets.card_widget import CardWidget


class TrickDisplay(FloatLayout):
    """Central trick display with radial card placement."""

    cards = ListProperty()  # List of dicts: {card_code, player_name, is_trump, is_lead}

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.size_hint = (None, None)
        self.size = (320, 320)
        self._card_widgets: List[CardWidget] = []
        self._lead_badge = None

        with self.canvas.before:
            Color(*GameColors.SECONDARY_BG)
            self.bg = Ellipse()
            Color(*GameColors.ACCENT_GOLD)
            self.ring = Ellipse(angle_start=0, angle_end=360)
            Color(*GameColors.OVERLAY_LIGHT)
            self.inner_ring = Line(circle=(0, 0, 0), width=2)

        self.bind(size=self._update_bg, pos=self._update_bg, cards=self._refresh_cards)
        self._update_bg()

    def _update_bg(self, *args):
        diameter = min(self.width, self.height)
        self.bg.size = (diameter, diameter)
        self.bg.pos = (self.center_x - diameter / 2, self.center_y - diameter / 2)
        ring_size = diameter - 8
        self.ring.size = (ring_size, ring_size)
        self.ring.pos = (self.center_x - ring_size / 2, self.center_y - ring_size / 2)
        self.inner_ring.circle = (self.center_x, self.center_y, max(0, ring_size / 2.4))

    def _clear_cards(self):
        for w in self._card_widgets:
            if w.parent:
                self.remove_widget(w)
        self._card_widgets.clear()

    def _refresh_cards(self, *args):
        self._clear_cards()
        if not self.cards:
            center_hint = Label(text="Waiting for cards...", color=GameColors.TEXT_SECONDARY, bold=True)
            self.add_widget(center_hint)
            return

        radius = min(self.width, self.height) * 0.32
        total = len(self.cards)
        for idx, card_info in enumerate(self.cards):
            angle = (2 * pi / total) * idx - pi / 2
            cx = self.center_x + radius * cos(angle)
            cy = self.center_y + radius * sin(angle)

            card_code = card_info.get("card_code", "")
            widget = CardWidget(card_code, size=(90, 135))
            widget.pos = (cx - widget.width / 2, cy - widget.height / 2)
            widget.playable = True
            widget.selected = card_info.get("is_trump", False)
            self.add_widget(widget)
            self._card_widgets.append(widget)

            name_label = Label(
                text=card_info.get("player_name", ""),
                font_size="12sp",
                color=GameColors.TEXT_PRIMARY,
                size_hint=(None, None),
                size=(100, 20),
                halign="center",
                valign="middle",
                pos=(cx - 50, cy - widget.height / 2 - 18),
            )
            name_label.text_size = name_label.size
            self.add_widget(name_label)

            if card_info.get("is_lead", False):
                lead = Label(
                    text="Lead",
                    font_size="10sp",
                    color=GameColors.ACCENT_GOLD,
                    bold=True,
                    size_hint=(None, None),
                    size=(50, 16),
                    pos=(cx - 25, cy + widget.height / 2 - 12),
                )
                self.add_widget(lead)
                self._lead_badge = lead

    def set_trick(self, cards: List[dict]):
        """Public helper to update trick cards."""
        self.cards = cards or []
