"""Horror-style opening splash sequence for Call Break.

Plays two slides then routes to the lobby/main menu. Designed to run once on app launch.
"""

import random

from kivy.animation import Animation
from kivy.clock import Clock
from kivy.core.audio import SoundLoader
from kivy.graphics import Color, Rectangle
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.label import Label
from kivy.uix.screenmanager import Screen

class HorrorIntroScreen(Screen):
    """Plays the horror intro, then hands control to the main menu."""

    def __init__(self, app, **kwargs):
        super().__init__(**kwargs)
        self.app = app
        self.started = False
        self._events = []
        self._flicker_ev = None
        self._sound = SoundLoader.load("assets/sounds/whoosh.wav") if SoundLoader else None

        # Root dark background
        with self.canvas.before:
            Color(0, 0, 0, 1)
            self.bg_rect = Rectangle()
        self.bind(size=self._update_bg, pos=self._update_bg)

        self.slide1 = self._build_slide1()
        self.slide2 = self._build_slide2()
        self.add_widget(self.slide1)
        self.add_widget(self.slide2)

    # ---------- Lifecycle ----------

    def on_pre_enter(self, *args):
        if not self.started:
            self.started = True
            self._play_intro()

    def on_leave(self, *args):
        self._cancel_all()

    # ---------- Build slides ----------

    def _build_slide1(self):
        layout = FloatLayout(opacity=0)

        # Ghostly chromatic layers for subtle aberration
        base_kwargs = {
            "text": "HALL 14 PRODUCTIONS",
            "font_size": "32sp",
            "bold": True,
            "halign": "center",
            "valign": "middle",
            "size_hint": (1, 1),
            "text_size": (0, 0),
        }

        green_glow = Label(color=(0.3, 1, 0.3, 0.35), pos_hint={"center_x": 0.51, "center_y": 0.5}, **base_kwargs)
        red_glow = Label(color=(1, 0.15, 0.15, 0.35), pos_hint={"center_x": 0.49, "center_y": 0.5}, **base_kwargs)
        main_label = Label(color=(0.85, 0.95, 0.85, 1), pos_hint={"center_x": 0.5, "center_y": 0.5}, **base_kwargs)

        for lbl in (green_glow, red_glow, main_label):
            lbl.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
            layout.add_widget(lbl)

        self.slide1_labels = (main_label, green_glow, red_glow)
        return layout

    def _build_slide2(self):
        layout = FloatLayout(opacity=0)

        with layout.canvas.before:
            Color(0, 0, 0, 1)
            layout.bg_rect = Rectangle()
            Color(1, 1, 1, 0.03)
            layout.vignette = Rectangle()
        layout.bind(size=self._update_slide2_bg, pos=self._update_slide2_bg)

        label = Label(
            text="MADE BY DIVYANSH KUMAR SINGH",
            font_size="30sp",
            bold=True,
            color=(0.94, 0.94, 0.92, 0.95),
            outline_width=1,
            outline_color=(0.65, 0.08, 0.08, 0.45),
            halign="center",
            valign="middle",
            size_hint=(1, 1),
        )
        label.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        self.slide2_label = label
        layout.add_widget(label)
        return layout

    # ---------- Animations ----------

    def _play_intro(self):
        if self._sound:
            self._sound.volume = 0.15
            self._sound.play()

        # Slide 1 timeline (2s total)
        Animation(opacity=1, duration=0.7, transition="out_quad").start(self.slide1)
        self._start_flicker(duration=1.0)
        self._schedule(0.8, self._shake_once)
        self._schedule(1.5, lambda *_: Animation(opacity=0, duration=0.5, transition="in_quad").start(self.slide1))

        # Slide 2 timeline (starts at 2s)
        self._schedule(2.0, self._start_slide2)

    def _start_slide2(self, *_):
        Animation(opacity=1, duration=0.7, transition="out_quad").start(self.slide2)
        # Gentle zoom via font size growth
        Animation(font_size="34sp", duration=3.0, transition="linear").start(self.slide2_label)
        self._schedule(2.3, lambda *_: Animation(opacity=0, duration=0.7, transition="in_quad").start(self.slide2))
        self._schedule(3.0, self._goto_main)

    def _start_flicker(self, duration=1.0):
        def do_flicker(dt):
            for lbl in self.slide1_labels:
                lbl.opacity = random.uniform(0.6, 1.0)
                lbl.pos_hint = {
                    "center_x": 0.5 + random.uniform(-0.003, 0.003),
                    "center_y": 0.5 + random.uniform(-0.003, 0.003),
                }
        self._flicker_ev = Clock.schedule_interval(do_flicker, 0.08)
        self._schedule(duration, self._stop_flicker)

    def _stop_flicker(self, *_):
        if self._flicker_ev:
            self._flicker_ev.cancel()
            self._flicker_ev = None
            for lbl in self.slide1_labels:
                lbl.opacity = 1
                lbl.pos_hint = {"center_x": 0.5, "center_y": 0.5}

    def _shake_once(self, *_):
        def jitter(dt):
            self.slide1.pos = (
                random.randint(-2, 2),
                random.randint(-2, 2),
            )
        self._schedule(0, jitter)
        self._schedule(0.05, jitter)
        self._schedule(0.1, jitter)
        self._schedule(0.2, lambda *_: setattr(self.slide1, "pos", (0, 0)))

    # ---------- Navigation & skip ----------

    def _goto_main(self, *_):
        self._cancel_all()
        if self.app and self.app.screen_manager:
            self.app.goto_screen("menu", direction="left")

    def on_touch_down(self, touch):
        # Allow skipping the intro with a tap/click.
        self._goto_main()
        return True

    # ---------- Utilities ----------

    def _update_bg(self, *_):
        if hasattr(self, "bg_rect"):
            self.bg_rect.pos = self.pos
            self.bg_rect.size = self.size

    def _update_slide2_bg(self, instance, *_):
        instance.bg_rect.pos = instance.pos
        instance.bg_rect.size = instance.size
        instance.vignette.pos = (instance.x - 10, instance.y - 10)
        instance.vignette.size = (instance.width + 20, instance.height + 20)

    def _schedule(self, delay, func):
        ev = Clock.schedule_once(func, delay)
        self._events.append(ev)
        return ev

    def _cancel_all(self):
        self._stop_flicker()
        for ev in self._events:
            try:
                ev.cancel()
            except Exception:
                pass
        self._events.clear()
        # Reset slide positions to avoid side effects if revisited
        self.slide1.pos = (0, 0)
        self.slide2.pos = (0, 0)
