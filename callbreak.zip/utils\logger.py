"""
Logging configuration for Call Break game.
"""

import logging
import os
from datetime import datetime


def setup_logger(name: str = 'callbreak', log_to_file: bool = True) -> logging.Logger:
    """
    Setup logger for the application.
    
    Args:
        name: Logger name
        log_to_file: Whether to log to file
        
    Returns:
        Configured logger instance
    """
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)
    
    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_formatter = logging.Formatter(
        '%(levelname)s: %(message)s'
    )
    console_handler.setFormatter(console_formatter)
    logger.addHandler(console_handler)
    
    # File handler
    if log_to_file:
        try:
            # Create logs directory
            log_dir = 'logs'
            if not os.path.exists(log_dir):
                os.makedirs(log_dir)
            
            # Log file with timestamp
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            log_file = os.path.join(log_dir, f'callbreak_{timestamp}.log')
            
            file_handler = logging.FileHandler(log_file)
            file_handler.setLevel(logging.DEBUG)
            file_formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            file_handler.setFormatter(file_formatter)
            logger.addHandler(file_handler)
            
            logger.info(f"Logging to file: {log_file}")
            
        except Exception as e:
            logger.warning(f"Could not setup file logging: {e}")
    
    return logger


def log_game_event(logger: logging.Logger, event_type: str, details: dict):
    """
    Log a game event with structured data.
    
    Args:
        logger: Logger instance
        event_type: Type of event (e.g., 'bid', 'play', 'trick_won')
        details: Event details dictionary
    """
    logger.info(f"[{event_type}] {details}")


def log_network_event(logger: logging.Logger, event_type: str, 
                     player_id: str, details: str = ''):
    """
    Log a network event.
    
    Args:
        logger: Logger instance
        event_type: Type of event (e.g., 'connect', 'disconnect')
        player_id: Player involved
        details: Additional details
    """
    logger.info(f"[NETWORK:{event_type}] Player {player_id} - {details}")


def log_error(logger: logging.Logger, error: Exception, context: str = ''):
    """
    Log an error with context.
    
    Args:
        logger: Logger instance
        error: Exception object
        context: Context where error occurred
    """
    logger.error(f"[ERROR] {context}: {type(error).__name__}: {error}", 
                exc_info=True)
