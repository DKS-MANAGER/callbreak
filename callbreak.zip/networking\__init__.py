"""
Networking Module for Call Break Game

WiFi-only connections and messaging helpers.
"""

from .wifi_server import WiFiGameServer
from .wifi_client import WiFiGameClient
from .message_handler import MessageHandler
from .connection_manager import ConnectionManager

__all__ = [
    'WiFiGameServer',
    'WiFiGameClient',
    'MessageHandler',
    'ConnectionManager'
]
