"""
UI Module for Call Break Game

Contains all Kivy screens and widgets.
"""
