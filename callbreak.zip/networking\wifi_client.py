"""
WiFi Client for Call Break game (Join).

Connects to host's WiFi server.
"""

import socket
import threading
import time
import uuid
from typing import Optional, Callable, Dict

from kivy.app import App
from kivy.clock import Clock

from .message_handler import MessageHandler, MessageType


class WiFiGameClient:
    """
    WiFi game client using TCP sockets.
    
    Connects to host device via local IP address.
    
    Attributes:
        host_ip: IP address of host
        port: Port number
        player_name: This player's name
        player_id: Unique player ID
        client_socket: Socket connection to server
        message_callback: Callback for received messages
        connected: Connection state
    """
    
    def __init__(self, host_ip: str, port: int = 5555,
                 message_callback: Optional[Callable] = None):
        """
        Initialize WiFi client.
        
        Args:
            host_ip: Host's IP address (e.g., '192.168.1.5')
            port: Port number (default 5555)
            message_callback: Callback for received messages
        """
        self.host_ip = host_ip
        self.port = port
        self.message_callback = message_callback
        
        self.player_name = ''
        self.player_id = str(uuid.uuid4())
        self.client_socket: Optional[socket.socket] = None
        self.connected = False
        self.lock = threading.Lock()

        # Round / phase tracking
        self.current_round = 0
        self.current_phase: Optional[str] = None
        self.processed_messages = set()

        # Safety limits
        self.max_message_size = 1024 * 512  # 512KB
        self.connection_timeout = 10.0
        self.recv_timeout = 30.0
        self.retry_attempts = 3

    # ---------- Socket helpers ----------

    def _send_with_length(self, payload: bytes) -> None:
        header = len(payload).to_bytes(4, 'big')
        self.client_socket.sendall(header + payload)

    def _recv_exact(self, nbytes: int) -> Optional[bytes]:
        data = bytearray()
        while len(data) < nbytes:
            chunk = self.client_socket.recv(nbytes - len(data))
            if not chunk:
                return None
            data.extend(chunk)
        return bytes(data)

    def _recv_message(self) -> Optional[Dict]:
        try:
            header = self._recv_exact(4)
            if not header:
                return None
            length = int.from_bytes(header, 'big')
            if length <= 0 or length > self.max_message_size:
                return None
            payload = self._recv_exact(length)
            if not payload:
                return None
            return MessageHandler.decode(payload)
        except Exception as exc:
            print(f"Receive error: {exc}")
            return None
    
    def connect(self, player_name: str) -> tuple:
        """
        Connect to host server.
        
        Args:
            player_name: This player's display name
            
        Returns:
            Tuple of (success: bool, message: str)
        """
        self.player_name = player_name
        
        for attempt in range(self.retry_attempts):
            try:
                # Create socket
                self.client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                self.client_socket.settimeout(self.connection_timeout)
                
                # Connect to server
                print(f"🌐 Connecting to {self.host_ip}:{self.port} (attempt {attempt + 1})...")
                self.client_socket.connect((self.host_ip, self.port))
                
                # Send player info
                join_message = MessageHandler.create_player_join(
                    self.player_id,
                    self.player_name
                )
                data = MessageHandler.encode(join_message)
                self._send_with_length(data)
                
                self.connected = True
                self.client_socket.settimeout(self.recv_timeout)
                
                print(f"✅ Connected as {self.player_name}")
                
                # Start listening thread
                listen_thread = threading.Thread(target=self._listen_for_messages)
                listen_thread.daemon = True
                listen_thread.start()

                # Signal readiness to host for lobby updates
                self.send_ready()
                
                return True, "Connected successfully"
                
            except socket.timeout:
                print(f"Connection timed out (attempt {attempt + 1})")
            except ConnectionRefusedError:
                print(f"Connection refused (attempt {attempt + 1})")
            except Exception as e:
                print(f"Connection failed: {e}")

            time.sleep(1)

        return False, "Unable to connect after retries"
    
    def _listen_for_messages(self):
        """Listen for messages from server."""
        try:
            while self.connected:
                try:
                    message = self._recv_message()
                    if not message:
                        print("⚠️ Connection closed by server")
                        break

                    self._route_message(message)

                except socket.timeout:
                    continue
                    
        except Exception as e:
            print(f"⚠️ Listen error: {e}")
        finally:
            self.connected = False
            self._cleanup()
    
    def _route_message(self, message: Dict):
        """Route incoming messages to optional handlers and callback."""
        self._update_round_phase(message)
        msg_type = message.get('type')
        handlers = {
            MessageType.GAME_START: self._handle_game_start,
            MessageType.ROUND_START: self._handle_round_start,
            MessageType.CARDS_DEALT: self._handle_cards_dealt,
            MessageType.TRUMP_CHOOSER_SELECTED: self._handle_trump_chooser,
            MessageType.TRUMP_SELECTION_REQUEST: self._handle_trump_request,
            MessageType.TRUMP_SELECTED: self._handle_trump_chosen,
            MessageType.BID_TURN: self._handle_bid_turn,
            MessageType.BIDDING_STATUS: self._handle_bidding_status,
            MessageType.BID_MADE: self._handle_bid_made,
            MessageType.BIDDING_COMPLETE: self._handle_bidding_complete,
            MessageType.PLAY_TURN: self._handle_play_turn,
            MessageType.PLAYING_STATUS: self._handle_playing_status,
            MessageType.CARD_PLAYED: self._handle_card_played,
            MessageType.TRICK_WON: self._handle_trick_won,
            MessageType.ROUND_END: self._handle_round_end,
            MessageType.GAME_END: self._handle_game_end,
            MessageType.STATE_SYNC_SNAPSHOT: self._handle_state_sync_snapshot,
        }
        handler = handlers.get(msg_type)
        if handler:
            Clock.schedule_once(lambda *_: handler(message))
        if self.message_callback:
            Clock.schedule_once(lambda *_: self.message_callback(message))

    def send_message(self, message: Dict) -> bool:
        """
        Send message to server.
        
        Args:
            message: Message dictionary
            
        Returns:
            True if sent successfully
        """
        if not self.connected:
            return False
        
        try:
            data = MessageHandler.encode(message)
            self._send_with_length(data)
            return True
        except Exception as e:
            print(f"❌ Send error: {e}")
            self.connected = False
            return False
    def send_card_play(self, card: str) -> bool:
        """
        Send card play to server.
        
        Args:
            card: Card string (e.g., 'AS')
            
        Returns:
            True if sent successfully
        """
        message = {
            'type': MessageType.CARD_PLAYED,
            'player_id': self.player_id,
            'card': card
        }
        return self.send_message(message)

    def send_trump_selection(self, trump_suit: str) -> bool:
        message = {
            'type': MessageType.TRUMP_SELECTED,
            'player_id': self.player_id,
            'trump_suit': trump_suit,
            'timestamp': time.time()
        }
        return self.send_message(message)

    def send_state_sync_request(self) -> bool:
        """Request a state snapshot from the server."""
        message = MessageHandler.create_state_sync_request(self.player_id)
        return self.send_message(message)
    
    def send_ready(self) -> bool:
        """
        Send ready status to server.
        
        Returns:
            True if sent successfully
        """
        message = MessageHandler.create_ready(self.player_id)
        return self.send_message(message)
    
    def disconnect(self):
        """Disconnect from server."""
        print("🛑 Disconnecting...")
        self.connected = False
        
        # Send disconnect message
        if self.client_socket:
            try:
                message = MessageHandler.create_player_disconnect(
                    self.player_id,
                    "Player left"
                )
                data = MessageHandler.encode(message)
                self._send_with_length(data)
            except:
                pass
        
        self._cleanup()
        print("✅ Disconnected")
    
    def _cleanup(self):
        """Clean up socket resources."""
        if self.client_socket:
            try:
                self.client_socket.close()
            except:
                pass
            self.client_socket = None
    
    def is_connected(self) -> bool:
        """Check if connected to server."""
        return self.connected
    
    def get_connection_info(self) -> Dict:
        """Get connection information."""
        return {
            'host_ip': self.host_ip,
            'port': self.port,
            'player_id': self.player_id,
            'player_name': self.player_name,
            'connected': self.connected
        }

    # ---------- Trump message helpers ----------

    def _update_round_phase(self, message: Dict):
        round_number = message.get('round_number') or 0
        if round_number:
            if round_number > self.current_round:
                print(f"New round detected on client: {round_number}")
            self.current_round = max(self.current_round, round_number)
        phase = message.get('phase')
        if phase:
            self.current_phase = phase.upper()

    def _handle_game_start(self, message: Dict):
        self.current_phase = 'GAME_START'
        self.current_round = max(self.current_round, message.get('round_number', 0))

    def _handle_round_start(self, message: Dict):
        self.current_phase = 'DEALING'
        round_number = message.get('round_number', 0) or 0
        if round_number:
            self.current_round = max(self.current_round, round_number)

    def _handle_trump_chooser(self, message: Dict):
        app = App.get_running_app()
        if app and app.game_state:
            app.game_state.trump_chooser_id = message.get('player_id')
        round_number = message.get('round_number', 0)
        if round_number:
            self.current_round = max(self.current_round, round_number)
        self.current_phase = 'TRUMP_SELECTION'

    def _handle_trump_request(self, message: Dict):
        # UI is driven by app callback; nothing extra here
        pass

    def _handle_trump_chosen(self, message: Dict):
        trump_suit = message.get('trump_suit')
        app = App.get_running_app()
        if app:
            app.current_trump_suit = trump_suit
            if app.game_state:
                app.game_state.update_trump_suit(trump_suit)
        round_number = message.get('round_number', 0)
        if round_number:
            self.current_round = max(self.current_round, round_number)
        self.current_phase = 'BIDDING'

    def _handle_bid_turn(self, message: Dict):
        self.current_phase = 'BIDDING'

    def _handle_bidding_status(self, message: Dict):
        self.current_phase = 'BIDDING'

    def _handle_bid_made(self, message: Dict):
        self.current_phase = 'BIDDING'

    def _handle_cards_dealt(self, message: Dict):
        round_number = message.get('round_number', 0)
        if round_number and round_number < self.current_round:
            print(f"WARNING: Old cards_dealt for round {round_number} (current {self.current_round})")
            return
        if round_number:
            if round_number > self.current_round:
                print(f"New round detected on client: {round_number}")
            self.current_round = round_number
        self.current_phase = 'DEALING'

    def _handle_bidding_complete(self, message: Dict):
        round_number = message.get('round_number', 0)
        if round_number and round_number != self.current_round:
            print(f"WARNING: Bidding complete for round {round_number} but client on {self.current_round}")
        self.current_phase = 'PLAYING'

    def _handle_play_turn(self, message: Dict):
        self.current_phase = 'PLAYING'

    def _handle_playing_status(self, message: Dict):
        self.current_phase = 'PLAYING'

    def _handle_card_played(self, message: Dict):
        self.current_phase = 'PLAYING'

    def _handle_trick_won(self, message: Dict):
        self.current_phase = 'TRICK_END'

    def _handle_round_end(self, message: Dict):
        round_number = message.get('round_number', 0)
        if round_number and round_number != self.current_round:
            print(f"NOTE: Round end out of sync (msg {round_number}, client {self.current_round})")
        self.current_phase = 'ROUND_END'

    def _handle_game_end(self, message: Dict):
        self.current_phase = 'GAME_END'

    def _handle_state_sync_snapshot(self, message: Dict):
        """Update local tracking from a server snapshot; UI should consume via callback."""
        self._update_round_phase(message)
        # Retain latest snapshot for UI/app to hydrate
        self.last_snapshot = message
