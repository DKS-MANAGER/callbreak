"""
Helper utilities for Call Break game.
"""

import socket
from typing import Tuple


def get_local_ip() -> str:
    """
    Get device's local IP address on WiFi network.
    
    Returns:
        Local IP address string (e.g., '192.168.1.5')
        Returns '127.0.0.1' if unable to determine
        
    Example:
        >>> ip = get_local_ip()
        >>> print(f"Connect to: {ip}:5555")
    """
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # Connect to external address (doesn't actually send data)
        # This helps determine which interface is used for internet
        s.connect(('10.255.255.255', 1))
        ip = s.getsockname()[0]
    except Exception:
        ip = '127.0.0.1'
    finally:
        s.close()
    return ip


def get_deck_config(num_players: int) -> Tuple[int, int, int]:
    """
    Determine deck configuration based on player count.
    
    Args:
        num_players: Number of players (2-12)
        
    Returns:
        Tuple of (num_decks, cards_per_player, remaining_cards)
        
    Configuration Table:
    Players | Decks | Cards/Player | Total Tricks
    --------|-------|--------------|-------------
    2       | 1     | 26           | 26
    3       | 1     | 17           | 17
    4       | 1     | 13           | 13
    5       | 1     | 10           | 10
    6       | 1     | 8            | 8
    7       | 2     | 14           | 14
    8       | 2     | 13           | 13
    9       | 2     | 11           | 11
    10      | 2     | 10           | 10
    11      | 2     | 9            | 9
    12      | 2     | 8            | 8
    
    Example:
        >>> get_deck_config(4)
        (1, 13, 0)  # 1 deck, 13 cards each, 0 remaining
    """
    if not 2 <= num_players <= 12:
        raise ValueError("num_players must be between 2 and 12")
    
    if num_players <= 6:
        num_decks = 1
        total_cards = 52
    else:  # 7-12 players
        num_decks = 2
        total_cards = 104
    
    cards_per_player = total_cards // num_players
    remaining_cards = total_cards % num_players
    
    return num_decks, cards_per_player, remaining_cards


def validate_ip_address(ip: str) -> bool:
    """
    Validate IP address format.
    
    Args:
        ip: IP address string
        
    Returns:
        True if valid IPv4 address
        
    Example:
        >>> validate_ip_address('192.168.1.1')
        True
        >>> validate_ip_address('999.999.999.999')
        False
    """
    try:
        parts = ip.split('.')
        if len(parts) != 4:
            return False
        
        for part in parts:
            num = int(part)
            if not 0 <= num <= 255:
                return False
        
        return True
    except (ValueError, AttributeError):
        return False


def format_player_count(num_players: int) -> str:
    """
    Format player count with deck info.
    
    Args:
        num_players: Number of players
        
    Returns:
        Formatted string
        
    Example:
        >>> format_player_count(4)
        '4 Players (1 Deck, 13 Cards Each)'
    """
    num_decks, cards_per_player, _ = get_deck_config(num_players)
    return f"{num_players} Players ({num_decks} Deck{'s' if num_decks > 1 else ''}, {cards_per_player} Cards Each)"


def get_connection_method_recommendation(num_players: int) -> str:
    """
    Get recommended connection method based on player count.
    
    Args:
        num_players: Number of players
        
    Returns:
        Recommendation string
    """
    return "WiFi Local Network"


def get_game_duration_estimate(num_players: int, num_rounds: int = 5) -> str:
    """
    Estimate game duration.
    
    Args:
        num_players: Number of players
        num_rounds: Number of rounds
        
    Returns:
        Duration estimate string
    """
    # Rough estimates: ~2 min per player per round
    minutes_per_round = num_players * 2
    total_minutes = minutes_per_round * num_rounds
    
    if total_minutes < 60:
        return f"~{total_minutes} minutes"
    else:
        hours = total_minutes // 60
        mins = total_minutes % 60
        return f"~{hours}h {mins}m"
