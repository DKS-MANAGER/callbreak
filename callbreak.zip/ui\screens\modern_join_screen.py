"""
Modern join screen with code boxes and nearby game discovery.
"""

from kivy.animation import Animation
from kivy.clock import Clock
from kivy.graphics import Color, RoundedRectangle
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.label import Label
from kivy.uix.screenmanager import Screen
from kivy.uix.textinput import TextInput

from networking.game_code import ACTIVE_GAMES, GameCodeManager
from ui.widgets.modern_controls import IconButton, ModernButton


class ModernJoinScreen(Screen):
    """Join screen with 6-box code entry and nearby list."""

    def __init__(self, app, **kwargs):
        super().__init__(**kwargs)
        self.app = app
        self.code_inputs = []
        self.error_label = None
        self.scan_container = None
        self.scan_bg = None
        self.scanning_indicator = None
        self.build_ui()

    def build_ui(self):
        root = FloatLayout(size_hint=(1, 1))
        with root.canvas.before:
            Color(0.1, 0.15, 0.2, 1)
            self.bg_rect = RoundedRectangle(pos=root.pos, size=root.size, radius=[0])
        root.bind(pos=self._update_bg, size=self._update_bg)

        back_btn = IconButton(icon="←", pos_hint={"x": 0.02, "top": 0.98})
        back_btn.bind(on_press=lambda *_: setattr(self.manager, "current", "menu"))
        root.add_widget(back_btn)

        title = Label(
            text="JOIN GAME",
            font_size="32sp",
            bold=True,
            size_hint=(1, 0.08),
            pos_hint={"x": 0, "top": 0.98},
        )
        root.add_widget(title)

        # Code input card
        input_card = FloatLayout(size_hint=(0.88, 0.28), pos_hint={"center_x": 0.5, "center_y": 0.7})
        with input_card.canvas.before:
            Color(0.15, 0.20, 0.25, 1)
            self.input_bg = RoundedRectangle(pos=input_card.pos, size=input_card.size, radius=[6])
        input_card.bind(pos=self._update_input, size=self._update_input)

        input_content = BoxLayout(orientation="vertical", padding=20, spacing=12)
        instruction = Label(
            text="Enter 6-digit game code",
            font_size="18sp",
            size_hint_y=0.25,
            color=(1, 1, 1, 0.7),
        )
        input_content.add_widget(instruction)

        code_boxes = BoxLayout(orientation="horizontal", spacing=12, size_hint_y=0.5)
        self.code_inputs = []
        for i in range(6):
            box = CodeInputBox()
            box.bind(text=lambda inst, val, idx=i: self.on_code_input(idx, val))
            self.code_inputs.append(box)
            code_boxes.add_widget(box)
            if i == 2:
                dash = Label(text="-", font_size="36sp", size_hint_x=0.1)
                code_boxes.add_widget(dash)
        input_content.add_widget(code_boxes)

        self.error_label = Label(text="", font_size="14sp", size_hint_y=0.15, color=(1, 0.3, 0.3, 1))
        input_content.add_widget(self.error_label)

        join_btn = ModernButton(text="JOIN", size_hint_y=0.25, background_color=(0.2, 0.6, 0.9, 1))
        join_btn.bind(on_press=self.join_game)
        input_content.add_widget(join_btn)

        input_card.add_widget(input_content)
        root.add_widget(input_card)

        nearby_label = Label(
            text="📡 Nearby Games",
            font_size="20sp",
            bold=True,
            size_hint=(1, 0.06),
            pos_hint={"x": 0, "center_y": 0.45},
        )
        root.add_widget(nearby_label)

        self.scan_container = BoxLayout(
            orientation="vertical",
            size_hint=(0.88, 0.32),
            pos_hint={"center_x": 0.5, "y": 0.08},
            padding=16,
            spacing=10,
        )
        with self.scan_container.canvas.before:
            Color(0.12, 0.18, 0.24, 1)
            self.scan_bg = RoundedRectangle(pos=self.scan_container.pos, size=self.scan_container.size, radius=[6])
        self.scan_container.bind(pos=self._update_scan, size=self._update_scan)

        self.scanning_indicator = ScanningIndicator()
        self.scan_container.add_widget(self.scanning_indicator)
        root.add_widget(self.scan_container)

        self.add_widget(root)
        Clock.schedule_once(lambda *_: self.scan_nearby_games(), 0.5)

    # ---------- Code input ----------

    def on_code_input(self, index, value):
        if len(value) == 1 and index < 5:
            self.code_inputs[index + 1].focus = True
        code = "".join(box.text for box in self.code_inputs)
        if len(code) == 6:
            Clock.schedule_once(lambda *_: self.join_game(None), 0.2)

    def join_game(self, *_):
        code = "".join(box.text for box in self.code_inputs).upper()
        if len(code) != 6:
            self.error_label.text = "Enter all 6 characters"
            return
        resolved = GameCodeManager.resolve_code(f"{code[:3]}-{code[3:]}")
        if not resolved:
            self.error_label.text = "Game code not found. Ensure host is on the same WiFi."
            return
        host_ip, port, _host = resolved
        success, message = self.app.connect_wifi_client(host_ip, port=port)
        if success:
            self.error_label.text = ""
        else:
            self.error_label.text = message

    # ---------- Nearby scan ----------

    def scan_nearby_games(self):
        def show_results(_dt):
            self.scan_container.clear_widgets()
            if ACTIVE_GAMES:
                for code, (ip, _port, host) in ACTIVE_GAMES.items():
                    tile = NearbyGameTile(code=code, host=host, players=1)
                    tile.bind(on_press=lambda inst, c=code: self.quick_join(c))
                    self.scan_container.add_widget(tile)
            else:
                no_games = Label(
                    text="No nearby games found\nAsk host for the code",
                    font_size="16sp",
                    color=(1, 1, 1, 0.5),
                    halign="center",
                )
                no_games.bind(size=no_games.setter("text_size"))
                self.scan_container.add_widget(no_games)
        Clock.schedule_once(show_results, 1.5)

    def quick_join(self, code):
        # Fill inputs and attempt join
        clean = code.replace("-", "")
        for idx, ch in enumerate(clean[:6]):
            self.code_inputs[idx].text = ch
        self.join_game()

    # ---------- Layout updates ----------

    def _update_bg(self, widget, *_):
        self.bg_rect.pos = widget.pos
        self.bg_rect.size = widget.size

    def _update_input(self, widget, *_):
        self.input_bg.pos = widget.pos
        self.input_bg.size = widget.size

    def _update_scan(self, widget, *_):
        self.scan_bg.pos = widget.pos
        self.scan_bg.size = widget.size


class CodeInputBox(TextInput):
    """Single character input box."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.multiline = False
        self.font_size = "48sp"
        self.halign = "center"
        self.input_filter = "alphanum"
        self.size_hint = (None, None)
        self.size = (55, 70)
        self.background_color = (0.2, 0.25, 0.3, 1)
        self.foreground_color = (1, 0.84, 0, 1)
        self.cursor_color = (1, 0.84, 0, 1)
        self.padding = [12, 12, 12, 12]

    def insert_text(self, substring, from_undo=False):
        if len(self.text) >= 1 and not from_undo:
            return
        return super().insert_text(substring.upper(), from_undo=from_undo)


class NearbyGameTile(ButtonBehavior, BoxLayout):
    """Tile for showing a discovered game."""

    def __init__(self, code, host, players, **kwargs):
        super().__init__(**kwargs)
        self.orientation = "horizontal"
        self.padding = 12
        self.spacing = 12
        self.size_hint_y = None
        self.height = 70
        with self.canvas.before:
            Color(0.18, 0.24, 0.30, 1)
            self.bg = RoundedRectangle(pos=self.pos, size=self.size, radius=[8])
        self.bind(pos=self._update, size=self._update)

        icon = Label(text="🎮", font_size="32sp", size_hint_x=0.15)
        self.add_widget(icon)
        info = BoxLayout(orientation="vertical", size_hint_x=0.7)
        code_label = Label(
            text=f"Code: {code}",
            font_size="20sp",
            bold=True,
            color=(1, 0.84, 0, 1),
            halign="left",
        )
        code_label.bind(size=code_label.setter("text_size"))
        info.add_widget(code_label)
        host_label = Label(
            text=f"Host: {host} - {players} players",
            font_size="14sp",
            color=(1, 1, 1, 0.6),
            halign="left",
        )
        host_label.bind(size=host_label.setter("text_size"))
        info.add_widget(host_label)
        self.add_widget(info)
        arrow = Label(text="→", font_size="28sp", size_hint_x=0.15)
        self.add_widget(arrow)

    def _update(self, *_):
        self.bg.pos = self.pos
        self.bg.size = self.size


class ScanningIndicator(BoxLayout):
    """Animated scanning indicator."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.orientation = "vertical"
        self.spacing = 16
        radar = Label(text="📡", font_size="48sp")
        self.add_widget(radar)
        anim = Animation(opacity=0.4, duration=1) + Animation(opacity=1.0, duration=1)
        anim.repeat = True
        anim.start(radar)
        text = Label(text="Scanning for nearby games...", font_size="16sp", color=(1, 1, 1, 0.7))
        self.add_widget(text)
