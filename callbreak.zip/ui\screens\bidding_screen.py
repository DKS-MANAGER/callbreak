"""
Bidding Screen - Modal overlay for bidding phase.
"""

from kivy.properties import ListProperty, NumericProperty, StringProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.label import Label
from kivy.uix.slider import Slider


class BiddingScreen(FloatLayout):
    """Bidding overlay with slider and quick buttons."""

    player_name = StringProperty("You")
    hand_size = NumericProperty(13)
    min_bid = NumericProperty(1)
    max_bid = NumericProperty(13)
    current_bid = NumericProperty(1)
    other_bids = ListProperty()

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._build_modal()

    def _build_modal(self):
        # Dimmed background
        self.canvas.before.clear()
        with self.canvas.before:
            from kivy.graphics import Color, Rectangle
            Color(0, 0, 0, 0.65)
            self.bg = Rectangle(pos=self.pos, size=self.size)
        self.bind(pos=self._update_bg, size=self._update_bg)

        container = BoxLayout(orientation="vertical", padding=16, spacing=12, size_hint=(0.86, None))
        container.height = 360
        container.pos_hint = {"center_x": 0.5, "center_y": 0.5}
        container.canvas.before.clear()
        with container.canvas.before:
            from kivy.graphics import Color, RoundedRectangle
            Color(0.97, 0.97, 0.97, 1)
            container.bg = RoundedRectangle(radius=[18] * 4, pos=container.pos, size=container.size)
        container.bind(pos=lambda *_: self._update_card(container), size=lambda *_: self._update_card(container))

        title = Label(text="Place Your Bid", font_size="20sp", bold=True, color=(0.08, 0.2, 0.15, 1))
        info = Label(text=self._info_text(), font_size="14sp", color=(0.2, 0.2, 0.2, 1))
        timer = Label(text="30s", font_size="14sp", color=(0.83, 0.20, 0.20, 1))

        slider = Slider(min=self.min_bid, max=self.max_bid, step=1, value=self.current_bid)
        slider.bind(value=self._on_slider)
        self.slider = slider

        value_row = BoxLayout(size_hint=(1, None), height=60, spacing=8)
        minus_btn = Button(text="-", size_hint=(None, None), size=(64, 56))
        minus_btn.bind(on_release=lambda *_: self._nudge_bid(-1))
        self.value_label = Label(text=self._bid_text(), font_size="32sp", bold=True, color=(0.95, 0.7, 0.05, 1))
        plus_btn = Button(text="+", size_hint=(None, None), size=(64, 56))
        plus_btn.bind(on_release=lambda *_: self._nudge_bid(1))
        value_row.add_widget(minus_btn)
        value_row.add_widget(self.value_label)
        value_row.add_widget(plus_btn)

        quick_row = BoxLayout(size_hint=(1, None), height=46, spacing=8)
        quick_row.add_widget(Button(text="Safe", background_color=(0.18, 0.45, 0.25, 1), on_release=lambda *_: self._set_relative(0.6)))
        quick_row.add_widget(Button(text="Bold", background_color=(0.96, 0.49, 0.0, 1), on_release=lambda *_: self._set_relative(0.9)))
        quick_row.add_widget(Button(text="Max", background_color=(0.83, 0.20, 0.20, 1), on_release=lambda *_: self._set_relative(1.0)))

        other_row = BoxLayout(orientation="vertical", spacing=4)
        other_row.add_widget(Label(text="Other bids", font_size="12sp", color=(0.25, 0.25, 0.25, 1), bold=True))
        self.other_label = Label(text=self._other_text(), font_size="12sp", color=(0.3, 0.3, 0.3, 1))
        other_row.add_widget(self.other_label)

        confirm = Button(text="PLACE BID", size_hint=(1, None), height=52, background_color=(0.26, 0.65, 0.25, 1), bold=True)
        confirm.bind(on_release=lambda *_: self._confirm())

        container.add_widget(title)
        container.add_widget(info)
        container.add_widget(timer)
        container.add_widget(slider)
        container.add_widget(value_row)
        container.add_widget(quick_row)
        container.add_widget(other_row)
        container.add_widget(confirm)

        self.add_widget(container)

    def _update_bg(self, *args):
        if hasattr(self, "bg"):
            self.bg.pos = self.pos
            self.bg.size = self.size

    def _update_card(self, container):
        if hasattr(container, "bg"):
            container.bg.pos = container.pos
            container.bg.size = container.size

    def _info_text(self):
        return f"{self.player_name}, you have {self.hand_size} cards. Min {self.min_bid} | Max {self.max_bid}."

    def _bid_text(self):
        return f"{int(self.current_bid)}"

    def _other_text(self):
        if not self.other_bids:
            return "No bids yet"
        return ", ".join([f"{b['name']}: {b['bid']}" for b in self.other_bids])

    def _nudge_bid(self, delta):
        new_val = int(self.current_bid + delta)
        new_val = max(self.min_bid, min(self.max_bid, new_val))
        self.current_bid = new_val
        self.slider.value = new_val
        self._refresh_labels()

    def _set_relative(self, ratio: float):
        target = max(self.min_bid, min(self.max_bid, int(self.max_bid * ratio)))
        self.current_bid = target
        self.slider.value = target
        self._refresh_labels()

    def _on_slider(self, slider, value):
        self.current_bid = int(value)
        self._refresh_labels()

    def _confirm(self):
        # Walk up tree to let container handle submit (BiddingOverlay wires networking).
        parent = self.parent
        while parent:
            if hasattr(parent, "confirm_bid"):
                parent.confirm_bid()
                return
            parent = parent.parent
        self._refresh_labels()

    def _refresh_labels(self):
        self.value_label.text = self._bid_text()
        if hasattr(self, "other_label"):
            self.other_label.text = self._other_text()
