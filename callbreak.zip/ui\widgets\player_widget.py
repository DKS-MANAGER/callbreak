"""
Player Widget - Compact display for player status around the table.
Styled to match the professional Teslatech palette.
"""

from kivy.graphics import Color, Line, RoundedRectangle
from kivy.properties import BooleanProperty, DictProperty, NumericProperty, StringProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label

from ui.theme.colors import GameColors


class PlayerWidget(BoxLayout):
    """Player information widget shown on the ring."""

    data = DictProperty()
    is_turn = BooleanProperty(False)
    connection = StringProperty("online")
    bid = NumericProperty(0)
    tricks = NumericProperty(0)
    score = NumericProperty(0.0)

    def __init__(self, player_data: dict, **kwargs):
        super().__init__(orientation="vertical", padding=8, spacing=4, size_hint=(None, None), **kwargs)
        self.size = (130, 116)
        self.data = player_data
        self.is_turn = player_data.get("is_turn", False)
        self.connection = player_data.get("connection", "online")
        self.bid = player_data.get("bid", 0)
        self.tricks = player_data.get("tricks", 0)
        self.score = player_data.get("score", 0.0)

        with self.canvas.before:
            Color(*GameColors.OVERLAY_DARK)
            self.shadow = RoundedRectangle(radius=[12, 12, 12, 12])

            self.bg_color = Color(*GameColors.SECONDARY_BG)
            self.bg_rect = RoundedRectangle(radius=[12, 12, 12, 12])

            self.turn_outline_color = Color(*GameColors.ACCENT_GREEN)
            self.turn_outline = Line(rounded_rectangle=(0, 0, 0, 0, 14), width=3)

        name = player_data.get("name", "Player")
        self.name_label = Label(
            text=name,
            bold=True,
            font_size="14sp",
            halign="center",
            valign="middle",
            size_hint_y=None,
            height=22,
            color=GameColors.TEXT_PRIMARY,
        )
        self.bid_label = Label(
            text=self._bid_text(),
            font_size="12sp",
            halign="center",
            valign="middle",
            size_hint_y=None,
            height=20,
            color=GameColors.TEXT_SECONDARY,
        )
        self.trick_label = Label(
            text=self._trick_text(),
            font_size="12sp",
            halign="center",
            valign="middle",
            size_hint_y=None,
            height=20,
            color=GameColors.TEXT_SECONDARY,
        )
        self.score_label = Label(
            text=self._score_text(),
            font_size="13sp",
            bold=True,
            color=GameColors.ACCENT_GOLD,
        )
        self.status_label = Label(
            text=self._status_text(),
            font_size="11sp",
            color=self._status_color(),
            size_hint_y=None,
            height=18,
        )

        for lbl in (self.name_label, self.bid_label, self.trick_label, self.score_label, self.status_label):
            lbl.text_size = (self.width, None)
            lbl.bind(size=lambda inst, *_: setattr(inst, "text_size", (inst.width, None)))
            self.add_widget(lbl)

        self.bind(pos=self._update_rect, size=self._update_rect)
        self.bind(is_turn=self._refresh_styles, bid=self._refresh_labels, tricks=self._refresh_labels, score=self._refresh_labels, connection=self._refresh_labels)
        self._refresh_styles()

    def _update_rect(self, *args):
        self.shadow.pos = (self.x - 2, self.y - 3)
        self.shadow.size = (self.width + 4, self.height + 6)

        self.bg_rect.pos = self.pos
        self.bg_rect.size = self.size

        self.turn_outline.rounded_rectangle = (
            self.x - 2,
            self.y - 2,
            self.width + 4,
            self.height + 4,
            14,
        )

    def _refresh_styles(self, *args):
        if self.is_turn:
            self.bg_color.rgba = (*GameColors.SECONDARY_BG[:3], 0.95)
            self.turn_outline_color.rgba = (*GameColors.ACCENT_GREEN[:3], 1)
        else:
            self.bg_color.rgba = (*GameColors.SECONDARY_BG[:3], 0.85)
            self.turn_outline_color.rgba = (*GameColors.ACCENT_GREEN[:3], 0)
        self.status_label.color = self._status_color()

    def _refresh_labels(self, *args):
        self.bid_label.text = self._bid_text()
        self.trick_label.text = self._trick_text()
        self.score_label.text = self._score_text()
        self.status_label.text = self._status_text()

    def _bid_text(self) -> str:
        return f"Bid: {self.bid}" if self.bid else "Bid: -"

    def _trick_text(self) -> str:
        return f"Tricks: {self.tricks}"

    def _score_text(self) -> str:
        score_str = f"{self.score:+.1f}" if isinstance(self.score, (float, int)) else str(self.score)
        return f"Score: {score_str}"

    def _status_text(self) -> str:
        if self.connection == "offline":
            return "Offline"
        return "Your Turn" if self.is_turn else "Connected"

    def _status_color(self):
        if self.connection == "offline":
            return GameColors.ERROR
        return GameColors.SUCCESS if self.is_turn else GameColors.TEXT_SECONDARY
