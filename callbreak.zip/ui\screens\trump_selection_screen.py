import random

from kivy.animation import Animation
from kivy.app import App
from kivy.clock import Clock
from kivy.graphics import Color, Line
from kivy.properties import ListProperty, NumericProperty, StringProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.label import Label
from kivy.uix.screenmanager import Screen

from ui.widgets.animated_button import AnimatedButton


class TrumpSelectionScreen(Screen):
    """Allows the chosen player to pick trump with a timeout."""

    countdown = NumericProperty(30)
    available_suits = ListProperty(["Spades", "Hearts", "Diamonds", "Clubs"])
    selected_suit = StringProperty("")

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.countdown_event = None
        self.selection_made = False
        self.bg_pulse = None
        self.pulsing = False
        self.build_ui()

    def build_ui(self):
        self.layout = BoxLayout(orientation="vertical", padding=16, spacing=14)
        self.header = Label(text="Select Trump Suit", font_size="22sp", bold=True)
        self.subtitle = Label(text="You are the chooser", font_size="16sp")

        # Circular progress timer
        progress_container = FloatLayout(size_hint=(None, None), size=(150, 150))
        progress_container.pos_hint = {"center_x": 0.5}
        with progress_container.canvas:
            Color(0.3, 0.3, 0.3, 0.5)
            self.bg_circle = Line(circle=(75, 75, 65), width=8)
            Color(1, 0.84, 0, 1)
            self.progress_circle = Line(circle=(75, 75, 65, 0, 360), width=8, cap="round")
        self.countdown_label = Label(
            text="30",
            font_size="48sp",
            bold=True,
            color=(1, 1, 1, 1),
            pos_hint={"center_x": 0.5, "center_y": 0.5},
        )
        progress_container.add_widget(self.countdown_label)

        self.timer_label = Label(text="30s", font_size="16sp")

        self.buttons_box = BoxLayout(spacing=8, size_hint=(1, None), height=80)

        self.layout.add_widget(self.header)
        self.layout.add_widget(self.subtitle)
        self.layout.add_widget(progress_container)
        self.layout.add_widget(self.timer_label)
        self.layout.add_widget(self.buttons_box)
        self.add_widget(self.layout)
        self._build_buttons()

    def _build_buttons(self):
        self.buttons_box.clear_widgets()
        for suit in self.available_suits:
            btn = AnimatedButton(text=suit, font_size="20sp", on_release=lambda inst, s=suit: self.suit_selected(s))
            self.buttons_box.add_widget(btn)
        self.selection_made = False

    def setup_selection(self, available_suits, timeout_seconds=30):
        if available_suits:
            self.available_suits = available_suits
        self.countdown = timeout_seconds
        self.timer_label.text = f"{self.countdown}s"
        self.selected_suit = ""
        self.selection_made = False
        self.pulsing = False
        self.countdown_label.text = str(self.countdown)
        self.progress_circle.circle = (75, 75, 65, 0, 360)
        Animation.cancel_all(self.countdown_label)
        if self.countdown_event:
            self.countdown_event.cancel()
        self.countdown_event = Clock.schedule_interval(self.update_countdown, 1.0)
        self._build_buttons()

    def on_enter(self, *args):
        if not self.countdown_event:
            self.countdown_event = Clock.schedule_interval(self.update_countdown, 1.0)

    def update_countdown(self, _dt):
        if self.selection_made:
            return
        self.countdown -= 1
        self.timer_label.text = f"{self.countdown}s"
        self.countdown_label.text = str(self.countdown)
        progress_angle = (self.countdown / 30.0) * 360
        self.progress_circle.circle = (75, 75, 65, 0, progress_angle)

        if self.countdown <= 5:
            self.countdown_label.color = (1, 0.2, 0.2, 1)
            self.progress_circle.rgba = (1, 0.2, 0.2, 1)
            if not self.pulsing:
                self.pulsing = True
                pulse = Animation(scale=1.1, duration=0.3) + Animation(scale=1.0, duration=0.3)
                pulse.repeat = True
                pulse.start(self.countdown_label)
        elif self.countdown <= 10:
            self.countdown_label.color = (1, 0.6, 0, 1)
            self.progress_circle.rgba = (1, 0.6, 0, 1)
        elif self.countdown <= 20:
            self.countdown_label.color = (1, 0.9, 0, 1)
            self.progress_circle.rgba = (1, 0.9, 0, 1)

        if self.countdown <= 0:
            self.auto_select_trump()

    def show_selection(self, suits):
        self.setup_selection(suits, timeout_seconds=self.countdown or 30)

    def suit_selected(self, suit_name: str):
        if self.selection_made:
            return
        self.selection_made = True
        app = App.get_running_app()
        if self.countdown_event:
            self.countdown_event.cancel()
        if app:
            if app.network_client:
                app.network_client.send_trump_selection(suit_name)
            elif app.network_server:
                app.network_server.handle_trump_selection(app.player_id, suit_name)
        self.selected_suit = suit_name
        self.subtitle.text = f"You chose {suit_name}" if suit_name else "Trump chosen"

    def auto_select_trump(self):
        suits = self.available_suits or ["Spades", "Hearts", "Diamonds", "Clubs"]
        random_suit = random.choice(suits)
        self.subtitle.text = "Time's up! Auto-selecting..."
        Clock.schedule_once(lambda *_: self.suit_selected(random_suit), 0.2)

    def on_leave(self):
        if self.countdown_event:
            self.countdown_event.cancel()
            self.countdown_event = None
