from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.screenmanager import Screen


class FinalResultsScreen(Screen):
    """Displays final standings at game end."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = BoxLayout(orientation="vertical", padding=16, spacing=12)
        self.title = Label(text="Game Over", font_size="24sp", bold=True)
        self.results_label = Label(text="", halign="center", valign="middle")
        self.results_label.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        home_btn = Button(text="Back to Lobby", size_hint_y=None, height=48)
        home_btn.bind(on_release=lambda *_: self._back_to_lobby())
        layout.add_widget(self.title)
        layout.add_widget(self.results_label)
        layout.add_widget(home_btn)
        self.add_widget(layout)

    def display_final_results(self, final_scores, winner_id, all_rounds=None):
        lines = [f"Winner: {winner_id}"] if winner_id else []
        for pid, score in (final_scores or {}).items():
            lines.append(f"{pid}: {score:+.1f}")
        self.results_label.text = "\n".join(lines) if lines else "Waiting for results"

    def _back_to_lobby(self):
        from kivy.app import App
        app = App.get_running_app()
        if app:
            app.goto_screen("lobby", direction="right")
