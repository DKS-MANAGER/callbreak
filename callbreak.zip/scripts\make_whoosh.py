"""Generate a short low-volume whoosh sting for the intro.

Outputs: assets/sounds/whoosh.wav (mono, 44.1kHz, ~0.7s)
Usage: python scripts/make_whoosh.py
"""

import math
import os
import random
import wave
from struct import pack

SAMPLE_RATE = 44100
DURATION = 0.7  # seconds
PEAK = 2200  # max amplitude (out of 32767)
OUT_PATH = os.path.join(os.path.dirname(__file__), "..", "assets", "sounds", "whoosh.wav")


def envelope(t: float, total: float) -> float:
    """Cosine fade-in/out envelope."""
    attack = 0.12
    release = 0.18
    sustain = max(total - attack - release, 0)
    if t < attack:
        return 0.5 * (1 - math.cos(math.pi * (t / attack)))
    if t < attack + sustain:
        return 1.0
    # release
    r_t = (t - attack - sustain) / max(release, 1e-6)
    return 0.5 * (1 + math.cos(math.pi * r_t))


def make_sample(n: int, total_samples: int) -> int:
    t = n / SAMPLE_RATE
    total = total_samples / SAMPLE_RATE
    env = envelope(t, total)
    # Noise-based whoosh with gentle low-pass via cumulative blend.
    white = random.uniform(-1, 1)
    tone = math.sin(2 * math.pi * 220 * t) * 0.1
    blended = 0.65 * white + 0.35 * tone
    # Light low-pass smoothing
    global prev
    prev = 0.7 * prev + 0.3 * blended if 'prev' in globals() else blended
    sample = int(max(-1, min(1, prev * env)) * PEAK)
    return sample


def main():
    os.makedirs(os.path.join(os.path.dirname(__file__), "..", "assets", "sounds"), exist_ok=True)
    total_samples = int(DURATION * SAMPLE_RATE)
    frames = bytearray()
    global prev
    prev = 0.0
    for i in range(total_samples):
        sample = make_sample(i, total_samples)
        frames += pack('<h', sample)
    with wave.open(OUT_PATH, 'wb') as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(SAMPLE_RATE)
        wf.writeframes(frames)
    print(f"Wrote whoosh to {os.path.abspath(OUT_PATH)}")


if __name__ == "__main__":
    main()
