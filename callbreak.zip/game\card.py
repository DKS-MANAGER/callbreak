"""
Card and Deck classes for Call Break game.

This module implements the card game mechanics including:
- Standard 52-card deck representation
- Multi-deck support (1-2 decks based on player count)
- Dynamic trump support (trump suit set per round)
- Card comparison logic using provided trump context
"""

import random
from typing import List, Tuple


class Card:
    """
    Represents a single playing card.
    
    Attributes:
        suit: Card suit (Spades, Hearts, Diamonds, Clubs)
        rank: Card rank (2-10, J, Q, K, A)
        value: Numeric value for comparison (2=2, A=14)
    """
    
    SUITS = ['Spades', 'Hearts', 'Diamonds', 'Clubs']
    RANKS = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A']
    SUIT_SYMBOLS = {'Spades': '♠', 'Hearts': '♥', 'Diamonds': '♦', 'Clubs': '♣'}
    
    def __init__(self, suit: str, rank: str):
        """
        Initialize a card.
        
        Args:
            suit: One of SUITS
            rank: One of RANKS
            
        Raises:
            ValueError: If suit or rank is invalid
        """
        if suit not in self.SUITS:
            raise ValueError(f"Invalid suit: {suit}")
        if rank not in self.RANKS:
            raise ValueError(f"Invalid rank: {rank}")
            
        self.suit = suit
        self.rank = rank
        self.value = self.RANKS.index(rank) + 2  # 2=2, 3=3, ..., A=14
    
    def is_trump_card(self, trump_suit: str) -> bool:
        """Check if this card is trump given current trump suit."""
        return bool(trump_suit) and self.suit == trump_suit

    def compare(self, other: 'Card', trump_suit: str) -> int:
        """
        Compare two cards using current trump suit.
        
        Returns:
            1 if self > other, -1 if self < other, 0 if equal
        """
        self_trump = self.is_trump_card(trump_suit)
        other_trump = other.is_trump_card(trump_suit)
        if self_trump and not other_trump:
            return 1
        if other_trump and not self_trump:
            return -1
        if self.value == other.value:
            return 0
        return 1 if self.value > other.value else -1

    def __gt__(self, other: 'Card') -> bool:
        """Default comparison ignores trump (used rarely)."""
        if not isinstance(other, Card):
            return False
        return self.value > other.value
    
    def __eq__(self, other: 'Card') -> bool:
        """Check if two cards are identical."""
        if not isinstance(other, Card):
            return False
        return self.suit == other.suit and self.rank == other.rank
    
    def __lt__(self, other: 'Card') -> bool:
        """Less than comparison."""
        return not (self > other or self == other)
    
    def __str__(self) -> str:
        """String representation: e.g., 'AS' (Ace of Spades)."""
        return f"{self.rank}{self.suit[0]}"
    
    def __repr__(self) -> str:
        """Detailed representation."""
        symbol = self.SUIT_SYMBOLS[self.suit]
        return f"Card({self.rank}{symbol})"
    
    def to_dict(self) -> dict:
        """Convert card to dictionary for JSON serialization."""
        return {
            'suit': self.suit,
            'rank': self.rank,
            'code': str(self)
        }
    
    @classmethod
    def from_string(cls, card_str: str) -> 'Card':
        """
        Create card from string representation.
        
        Args:
            card_str: String like 'AS', 'KH', '10D'
            
        Returns:
            Card instance
            
        Example:
            >>> Card.from_string('AS')
            Card(A♠)
        """
        # Extract rank and suit code
        suit_code = card_str[-1]
        rank = card_str[:-1]
        
        suit_map = {'S': 'Spades', 'H': 'Hearts', 'D': 'Diamonds', 'C': 'Clubs'}
        suit = suit_map.get(suit_code)
        
        if not suit or rank not in cls.RANKS:
            raise ValueError(f"Invalid card string: {card_str}")
        
        return cls(suit, rank)


class Deck:
    """
    Represents a deck of cards with multi-deck support.
    
    Configuration:
    - 2-6 players: 1 deck (52 cards)
    - 7-12 players: 2 decks (104 cards)
    """
    
    def __init__(self, num_decks: int = 1):
        """
        Initialize deck with specified number of standard 52-card decks.
        
        Args:
            num_decks: Number of decks to use (1 or 2)
        """
        if num_decks not in [1, 2]:
            raise ValueError("num_decks must be 1 or 2")
            
        self.num_decks = num_decks
        self.cards: List[Card] = []
        self._build_deck()
    
    def _build_deck(self):
        """Build the deck with all cards."""
        self.cards = []
        for _ in range(self.num_decks):
            for suit in Card.SUITS:
                for rank in Card.RANKS:
                    self.cards.append(Card(suit, rank))
    
    def shuffle(self):
        """Shuffle the deck randomly."""
        random.shuffle(self.cards)
    
    def deal(self, num_players: int) -> Tuple[List[List[Card]], List[Card]]:
        """
        Deal cards evenly to players.
        
        Args:
            num_players: Number of players (2-12)
            
        Returns:
            Tuple of (hands, remaining_cards)
            hands: List of card lists, one per player
            remaining_cards: Undealt cards (if any)
            
        Example:
            >>> deck = Deck(num_decks=1)
            >>> deck.shuffle()
            >>> hands, remaining = deck.deal(4)
            >>> len(hands)
            4
            >>> len(hands[0])  # Each player gets 13 cards
            13
        """
        if not 2 <= num_players <= 12:
            raise ValueError("num_players must be between 2 and 12")
        
        cards_per_player = len(self.cards) // num_players
        hands = []
        
        for i in range(num_players):
            start = i * cards_per_player
            end = start + cards_per_player
            hands.append(self.cards[start:end])
        
        # Any remaining cards
        remaining_start = num_players * cards_per_player
        remaining_cards = self.cards[remaining_start:]
        
        return hands, remaining_cards
    
    def reset(self):
        """Reset deck to full unshuffled state."""
        self._build_deck()
    
    def __len__(self) -> int:
        """Return number of cards in deck."""
        return len(self.cards)
    
    def __str__(self) -> str:
        """String representation."""
        return f"Deck({self.num_decks} deck(s), {len(self.cards)} cards)"


def get_deck_config(num_players: int) -> Tuple[int, int, int]:
    """
    Determine deck configuration based on player count.
    
    Args:
        num_players: Number of players (2-12)
        
    Returns:
        Tuple of (num_decks, cards_per_player, remaining_cards)
        
    Configuration Table:
    Players | Decks | Cards/Player | Total Tricks
    --------|-------|--------------|-------------
    2       | 1     | 26           | 26
    3       | 1     | 17           | 17
    4       | 1     | 13           | 13
    5       | 1     | 10           | 10
    6       | 1     | 8            | 8
    7       | 2     | 14           | 14
    8       | 2     | 13           | 13
    9       | 2     | 11           | 11
    10      | 2     | 10           | 10
    11      | 2     | 9            | 9
    12      | 2     | 8            | 8
    
    Example:
        >>> get_deck_config(4)
        (1, 13, 0)  # 1 deck, 13 cards each, 0 remaining
        >>> get_deck_config(9)
        (2, 11, 5)  # 2 decks, 11 cards each, 5 remaining
    """
    if not 2 <= num_players <= 12:
        raise ValueError("num_players must be between 2 and 12")
    
    if num_players <= 6:
        num_decks = 1
        total_cards = 52
    else:  # 7-12 players
        num_decks = 2
        total_cards = 104
    
    cards_per_player = total_cards // num_players
    remaining_cards = total_cards % num_players
    
    return num_decks, cards_per_player, remaining_cards
