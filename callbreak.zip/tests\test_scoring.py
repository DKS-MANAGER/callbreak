"""
Unit tests for scoring logic.

Run with: pytest tests/test_scoring.py
"""

import pytest
from game.player import Player
from game.scoring import (
    calculate_score,
    format_score,
    get_score_summary
)


class TestScoring:
    """Test scoring functions."""
    
    def test_exact_match_scoring(self):
        """Test exact match scoring."""
        player = Player('id1', 'Test')
        player.current_bid = 5
        player.tricks_won_this_round = 5
        
        score = calculate_score(player)
        assert score == 5.0
        assert player.total_score == 5.0
    
    def test_over_trick_scoring(self):
        """Test over-trick scoring."""
        player = Player('id1', 'Test')
        player.current_bid = 3
        player.tricks_won_this_round = 6
        
        score = calculate_score(player)
        assert score == pytest.approx(3.3)
    
    def test_under_trick_penalty(self):
        """Test under-trick penalty."""
        player = Player('id1', 'Test')
        player.current_bid = 4
        player.tricks_won_this_round = 2
        
        score = calculate_score(player)
        assert score == -4.0
    
    def test_format_score_positive(self):
        """Test formatting positive scores."""
        assert format_score(5.0) == '+5.0'
        assert format_score(3.3) == '+3.3'
    
    def test_format_score_negative(self):
        """Test formatting negative scores."""
        assert format_score(-4.0) == '-4.0'
    
    def test_score_summary(self):
        """Test score summary generation."""
        player = Player('id1', 'John')
        player.current_bid = 5
        player.tricks_won_this_round = 5
        player.calculate_score()
        
        summary = get_score_summary(player)
        assert 'John' in summary
        assert '5' in summary


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
