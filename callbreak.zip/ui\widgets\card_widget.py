"""
Card Widget - Professional clickable card with Teslatech-style visuals.

Features:
- Clean white face with layered shadows and subtle border
- Suit-aware colors and typography fallback when art is missing
- Trump/playable highlighting with pulse animation
"""

from kivy.animation import Animation
from kivy.graphics import Color, Line, RoundedRectangle
from kivy.properties import BooleanProperty, ListProperty, StringProperty
from kivy.resources import resource_find
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.image import Image
from kivy.uix.label import Label
from kivy.uix.relativelayout import RelativeLayout

from ui.theme.colors import GameColors
from utils.asset_manager import asset_manager


class CardWidget(ButtonBehavior, RelativeLayout):
    """Clickable card widget with professional styling."""

    card_code = StringProperty("")
    playable = BooleanProperty(True)
    selected = BooleanProperty(False)
    glow_color = ListProperty([1, 1, 1, 0])

    def __init__(self, card_code: str, **kwargs):
        super().__init__(**kwargs)
        self.card_code = card_code
        self.size_hint = (None, None)
        self.size = (110, 160)
        self._has_art = False
        self.glow_instruction = None
        self.glow_animation = None
        self.is_trump_card = False
        self._last_trump_suit = ""

        self._build_graphics()
        self._build_face(card_code)

        self.bind(pos=self._update_graphics, size=self._update_graphics)
        self.bind(selected=self._on_state_change, playable=self._on_state_change)
        self._on_state_change()

    # ---------- Layout helpers ----------

    def _build_graphics(self):
        """Create layered shadows and card body."""
        with self.canvas.before:
            Color(0, 0, 0, 0.15)
            self.shadow_large = RoundedRectangle(radius=[16, 16, 16, 16])

            Color(0, 0, 0, 0.10)
            self.shadow_medium = RoundedRectangle(radius=[14, 14, 14, 14])

            self.bg_color = Color(*GameColors.CARD_WHITE)
            self.bg_rect = RoundedRectangle(radius=[12, 12, 12, 12])

            self.border_color = Color(0.9, 0.9, 0.9, 0.6)
            self.inner_border = Line(width=1)

    def _build_face(self, card_code: str):
        """Add either textured card art or typographic fallback."""
        self.clear_widgets()
        texture = None
        art_path = resource_find(f"assets/cards/{card_code}.png")
        cached = asset_manager.get_card_image(card_code)
        if cached:
            texture = cached.texture
        elif art_path:
            self._has_art = True
            texture = Image(source=art_path, allow_stretch=True, keep_ratio=True).texture

        if texture:
            self.image = Image(texture=texture, allow_stretch=True, keep_ratio=True)
            self.add_widget(self.image)
        else:
            self.image = None
            suit, rank = self._parse_card(card_code)
            suit_symbol = self._suit_symbol(suit)
            suit_color = self._suit_color(suit)

            self.center_symbol = Label(
                text=suit_symbol,
                font_size="64sp",
                color=suit_color,
                size_hint=(1, 0.5),
                pos_hint={"center_x": 0.5, "center_y": 0.52},
                bold=True,
            )
            self.add_widget(self.center_symbol)

            self.rank_label = Label(
                text=rank,
                font_size="22sp",
                color=suit_color,
                size_hint=(0.4, 0.28),
                pos_hint={"x": 0.05, "top": 0.98},
                bold=True,
                halign="left",
                valign="top",
            )
            self.rank_label.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
            self.add_widget(self.rank_label)

            self.mini_suit = Label(
                text=suit_symbol,
                font_size="18sp",
                color=suit_color,
                size_hint=(0.4, 0.2),
                pos_hint={"x": 0.05, "top": 0.76},
            )
            self.add_widget(self.mini_suit)

            self.rank_label_bottom = Label(
                text=rank,
                font_size="22sp",
                color=suit_color,
                size_hint=(0.4, 0.28),
                pos_hint={"right": 0.95, "y": 0.02},
                bold=True,
                halign="right",
                valign="bottom",
            )
            self.rank_label_bottom.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
            self.add_widget(self.rank_label_bottom)

    # ---------- State / visuals ----------

    def _update_graphics(self, *args):
        self.shadow_large.pos = (self.x - 4, self.y - 6)
        self.shadow_large.size = (self.width + 8, self.height + 12)

        self.shadow_medium.pos = (self.x - 2, self.y - 3)
        self.shadow_medium.size = (self.width + 4, self.height + 6)

        self.bg_rect.pos = self.pos
        self.bg_rect.size = self.size

        self.inner_border.rounded_rectangle = (
            self.x + 1,
            self.y + 1,
            self.width - 2,
            self.height - 2,
            12,
        )

        if self.glow_instruction and self.is_trump_card:
            self._realign_glow()

    def _on_state_change(self, *args):
        """Refresh visuals based on selected/playable flags."""
        Animation.cancel_all(self)
        tint = GameColors.ACCENT_GOLD if self.selected else GameColors.CARD_WHITE
        self.bg_color.rgba = tint
        self.opacity = 0.45 if not self.playable else 1.0

    # ---------- Suit helpers ----------

    def _parse_card(self, code: str):
        if not code:
            return "", ""
        suit = code[-1].upper()
        rank = code[:-1] if len(code) > 1 else code
        return suit, rank

    def _suit_symbol(self, suit: str) -> str:
        return {"S": "♠", "H": "♥", "D": "♦", "C": "♣"}.get(suit, "?")

    def _suit_color(self, suit: str):
        return {
            "S": GameColors.SPADES,
            "H": GameColors.HEARTS,
            "D": GameColors.DIAMONDS,
            "C": GameColors.CLUBS,
        }.get(suit, GameColors.TEXT_PRIMARY)

    # ---------- Trump / glow ----------

    def update_trump_glow(self, is_trump: bool, trump_suit: str):
        """Apply colored outline for trump cards."""
        self.is_trump_card = is_trump
        self._last_trump_suit = trump_suit
        self.remove_glow()
        if not is_trump:
            return

        glow_colors = {
            "Spades": (*GameColors.SPADES[:3], 0.9),
            "Hearts": (*GameColors.HEARTS[:3], 0.9),
            "Diamonds": (*GameColors.DIAMONDS[:3], 0.9),
            "Clubs": (*GameColors.CLUBS[:3], 0.9),
        }
        color = glow_colors.get(trump_suit, (1, 1, 1, 0.8))
        with self.canvas.after:
            Color(*color)
            self.glow_instruction = Line(rounded_rectangle=(0, 0, 0, 0, 14), width=3)
        self._realign_glow()

        pulse = Animation(opacity=0.7, duration=1.0, transition="in_out_sine") + Animation(
            opacity=1.0, duration=1.0, transition="in_out_sine"
        )
        pulse.repeat = True
        pulse.start(self)
        self.glow_animation = pulse

    def _realign_glow(self):
        if not self.glow_instruction:
            return
        self.glow_instruction.rounded_rectangle = (
            self.x - 3,
            self.y - 3,
            self.width + 6,
            self.height + 6,
            14,
        )

    def on_pos(self, *args):
        if self.glow_instruction and self.is_trump_card:
            self._realign_glow()

    def remove_glow(self):
        if self.glow_animation:
            self.glow_animation.cancel(self)
            self.glow_animation = None
        if self.glow_instruction:
            try:
                self.canvas.after.remove(self.glow_instruction)
            except Exception:
                pass
            self.glow_instruction = None
        self.opacity = 1.0
