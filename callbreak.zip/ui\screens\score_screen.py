"""
Score Screen - Round results and leaderboard.
"""

from kivy.graphics import Color, Rectangle
from kivy.properties import ListProperty, StringProperty
from kivy.clock import Clock
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.scrollview import ScrollView
from kivy.uix.gridlayout import GridLayout

from ui.widgets.animated_button import AnimatedButton


class ScoreScreen(BoxLayout):
    """Score display screen showing round and total scores."""

    title = StringProperty("Round Complete")
    entries = ListProperty()

    def __init__(self, **kwargs):
        super().__init__(orientation="vertical", padding=16, spacing=12, **kwargs)
        self.score_labels = {}
        self._build_layout()
        # Example data for quick visual testing
        self.set_entries([
            {"rank": 1, "name": "You", "bid": 5, "won": 6, "round": 5.1, "total": 12.3},
            {"rank": 2, "name": "Ravi", "bid": 4, "won": 4, "round": 4.0, "total": 9.4},
            {"rank": 3, "name": "Anita", "bid": 3, "won": 2, "round": -3.0, "total": 3.2},
        ])

    def _build_layout(self):
        self.header = Label(text=self.title, font_size="22sp", bold=True, color=(0.99, 0.84, 0.0, 1), size_hint=(1, None), height=36)
        self.add_widget(self.header)

        columns = BoxLayout(size_hint=(1, None), height=28)
        columns.add_widget(Label(text="Rank", bold=True))
        columns.add_widget(Label(text="Player", bold=True))
        columns.add_widget(Label(text="Bid/Won", bold=True))
        columns.add_widget(Label(text="Round", bold=True))
        columns.add_widget(Label(text="Total", bold=True))
        self.add_widget(columns)

        self.scroll = ScrollView(size_hint=(1, 1))
        self.grid = GridLayout(cols=5, size_hint_y=None, spacing=6, padding=[0, 4], row_default_height=32)
        self.grid.bind(minimum_height=self.grid.setter("height"))
        self.scroll.add_widget(self.grid)
        self.add_widget(self.scroll)

        buttons = BoxLayout(size_hint=(1, None), height=60, spacing=12)
        buttons.add_widget(AnimatedButton(text="Next Round", background_color=(0.26, 0.65, 0.25, 1), bold=True))
        buttons.add_widget(AnimatedButton(text="Final Results", background_color=(0.98, 0.82, 0.18, 1), bold=True))
        buttons.add_widget(AnimatedButton(text="Exit to Lobby", background_color=(0.18, 0.25, 0.3, 1), bold=True))
        self.add_widget(buttons)

    def set_entries(self, entries):
        self.entries = entries or []
        self._refresh_table()

    def _refresh_table(self):
        self.grid.clear_widgets()
        self.score_labels = {}
        for idx, entry in enumerate(self.entries):
            rank = entry.get("rank", "-")
            name = entry.get("name", "-")
            bid = entry.get("bid", 0)
            won = entry.get("won", 0)
            round_score = entry.get("round", 0)
            total = entry.get("total", 0)

            bg = (0.15, 0.18, 0.18, 0.45) if idx % 2 == 0 else (0.10, 0.12, 0.12, 0.4)
            self.grid.add_widget(self._cell(str(rank), bg=bg, bold=True))
            self.grid.add_widget(self._cell(name, bg=bg))
            self.grid.add_widget(self._cell(f"{bid} / {won}", bg=bg))
            round_lbl = self._cell(
                f"{round_score:+.1f}",
                color=(0.26, 0.65, 0.25, 1) if round_score >= 0 else (0.78, 0.2, 0.2, 1),
                bg=bg,
            )
            self.score_labels[name] = round_lbl
            self.grid.add_widget(round_lbl)
            self.grid.add_widget(self._cell(f"{total:+.1f}", color=(0.99, 0.84, 0.0, 1), bold=True, bg=bg))

    def _cell(self, text, color=(1, 1, 1, 0.9), bold=False, bg=(0, 0, 0, 0)):
        lbl = Label(text=text, color=color, bold=bold)
        with lbl.canvas.before:
            Color(*bg)
            lbl.bg = Rectangle(pos=lbl.pos, size=lbl.size)
        lbl.bind(pos=lambda inst, *_: setattr(inst.bg, 'pos', inst.pos))
        lbl.bind(size=lambda inst, *_: setattr(inst.bg, 'size', inst.size))
        return lbl

    # ---------- Game integration ----------

    def display_scores(self, round_number: int, round_scores: dict, total_scores: dict, tricks_won: dict):
        self.title = f"Round {round_number} Complete!"
        self.header.text = self.title
        ordered = sorted(total_scores.items(), key=lambda item: item[1], reverse=True)
        entries = []
        for rank, (pid, total) in enumerate(ordered, 1):
            entries.append({
                "rank": rank,
                "name": pid,
                "bid": round_scores.get(pid, 0),
                "won": tricks_won.get(pid, 0),
                "round": round_scores.get(pid, 0),
                "total": total,
            })
        self.set_entries(entries)
        self.animate_score_counting(round_scores)

    def animate_score_counting(self, scores_dict):
        """Animate round scores counting up from 0."""
        duration = 1.0
        steps = 20
        for player_name, final_score in (scores_dict or {}).items():
            label = self.score_labels.get(player_name)
            if not label:
                continue
            increment = final_score / steps if steps else final_score
            current = 0

            def update_score(dt, lbl=label, target=final_score):
                nonlocal current
                current += increment
                if (increment >= 0 and current >= target) or (increment < 0 and current <= target):
                    lbl.text = f"{target:+.1f}"
                    return False
                lbl.text = f"{current:+.1f}"
                return True

            Clock.schedule_interval(update_score, duration / steps)
