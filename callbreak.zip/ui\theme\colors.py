"""Centralized color palette for the Call Break UI (Teslatech-inspired).

Values are normalized RGBA tuples (0-1).
"""


class GameColors:
    # Primary surfaces
    PRIMARY_BG = (0.09, 0.12, 0.15, 1)       # #171E26 deep blue-gray
    SECONDARY_BG = (0.12, 0.16, 0.20, 1)     # #1F2933 card table
    ACCENT_GREEN = (0.20, 0.75, 0.50, 1)     # #33BF80 success/action
    ACCENT_GOLD = (1.0, 0.84, 0.0, 1)        # #FFD700 premium highlight

    # Suits
    SPADES = (0.35, 0.20, 0.80, 1)           # #5933CC
    HEARTS = (0.95, 0.20, 0.30, 1)           # #F23349
    DIAMONDS = (1.0, 0.60, 0.0, 1)           # #FF9900
    CLUBS = (0.20, 0.80, 0.40, 1)            # #33CC66

    # UI text / surfaces
    CARD_WHITE = (0.98, 0.98, 0.98, 1)       # #FAFAFA
    TEXT_PRIMARY = (1.0, 1.0, 1.0, 0.95)
    TEXT_SECONDARY = (1.0, 1.0, 1.0, 0.7)
    TEXT_DISABLED = (1.0, 1.0, 1.0, 0.4)

    # Status
    SUCCESS = (0.30, 0.85, 0.40, 1)
    WARNING = (1.0, 0.75, 0.0, 1)
    ERROR = (0.95, 0.26, 0.21, 1)
    INFO = (0.13, 0.59, 0.95, 1)

    # Overlays / gradients
    OVERLAY_DARK = (0, 0, 0, 0.85)
    OVERLAY_LIGHT = (0, 0, 0, 0.5)
    GRADIENT_START = (0.15, 0.20, 0.25, 1)
    GRADIENT_END = (0.08, 0.10, 0.13, 1)
