"""
Message Handler for Call Break networking.

Encodes and decodes JSON messages for game communication.
"""

import json
from typing import Dict, Any, List, Optional


class MessageType:
    """Message type constants."""
    # Connection
    PLAYER_JOIN = 'join'
    LOBBY_UPDATE = 'lobby_update'
    PLAYER_DISCONNECT = 'disconnect'
    READY = 'ready'
    
    # Game flow
    GAME_START = 'game_start'
    CARDS_DEALT = 'cards_dealt'
    ROUND_START = 'round_start'
    
    # Bidding
    BID_TURN = 'bid_turn'
    BID_MADE = 'bid_made'
    BIDDING_STATUS = 'bidding_status'
    BIDDING_COMPLETE = 'bidding_complete'

    # Trump selection
    TRUMP_CHOOSER_SELECTED = 'trump_chooser'
    TRUMP_SELECTION_REQUEST = 'trump_request'
    TRUMP_SELECTED = 'trump_chosen'
    
    # Playing
    PLAY_TURN = 'play_turn'
    PLAYING_STATUS = 'playing_status'
    CARD_PLAYED = 'card_played'
    TRICK_WON = 'trick_won'
    
    # Scoring
    ROUND_END = 'round_end'
    GAME_END = 'game_end'

    # State sync / reconnect
    STATE_SYNC_REQUEST = 'state_sync_request'
    STATE_SYNC_SNAPSHOT = 'state_sync_snapshot'
    PLAYER_REJOIN = 'player_rejoin'
    
    # Error
    ERROR = 'error'


class MessageHandler:
    """
    Handles encoding and decoding of game messages.
    
    All messages are JSON-based with a 'type' field.
    """
    
    @staticmethod
    def encode(message: Dict[str, Any]) -> bytes:
        """
        Encode message to JSON bytes.
        
        Args:
            message: Message dictionary
            
        Returns:
            UTF-8 encoded JSON bytes
        """
        try:
            json_str = json.dumps(message)
            return json_str.encode('utf-8')
        except Exception as e:
            raise ValueError(f"Failed to encode message: {e}")
    
    @staticmethod
    def decode(data: bytes) -> Dict[str, Any]:
        """
        Decode JSON bytes to message dictionary.
        
        Args:
            data: UTF-8 encoded JSON bytes
            
        Returns:
            Message dictionary
        """
        try:
            json_str = data.decode('utf-8')
            return json.loads(json_str)
        except Exception as e:
            raise ValueError(f"Failed to decode message: {e}")
    
    # Connection messages
    @staticmethod
    def create_ready(player_id: str) -> Dict:
        return {
            'type': MessageType.READY,
            'player_id': player_id,
            'timestamp': __import__('time').time()
        }

    @staticmethod
    def create_player_join(player_id: str, player_name: str) -> Dict:
        """Create player join message."""
        return {
            'type': MessageType.PLAYER_JOIN,
            'player_id': player_id,
            'player_name': player_name,
            'timestamp': __import__('time').time()
        }
    
    @staticmethod
    def create_lobby_update(players: List[Dict], max_players: int) -> Dict:
        """Create lobby update message."""
        ready_count = sum(1 for p in players if p.get('is_ready', False))
        return {
            'type': MessageType.LOBBY_UPDATE,
            'players': players,
            'ready_count': ready_count,
            'max_players': max_players
        }
    
    @staticmethod
    def create_player_disconnect(player_id: str, reason: str = '') -> Dict:
        """Create player disconnect message."""
        return {
            'type': MessageType.PLAYER_DISCONNECT,
            'player_id': player_id,
            'reason': reason
        }
    
    # Game flow messages
    @staticmethod
    def create_game_start(player_order: List[str], dealer: str, num_decks: int, num_rounds: int = 5) -> Dict:
        """Create game start message."""
        return {
            'type': MessageType.GAME_START,
            'player_order': player_order,
            'dealer': dealer,
            'num_decks': num_decks,
            'num_rounds': num_rounds
        }

    @staticmethod
    def create_round_start(round_number: int, total_rounds: int) -> Dict:
        return {
            'type': MessageType.ROUND_START,
            'round_number': round_number,
            'total_rounds': total_rounds,
            'timestamp': __import__('time').time()
        }
    
    @staticmethod
    def create_cards_dealt(cards: List[str], num_cards: int) -> Dict:
        """Create cards dealt message (sent to specific player)."""
        return {
            'type': MessageType.CARDS_DEALT,
            'cards': cards,
            'num_cards': num_cards
        }
    
    # Bidding messages
    @staticmethod
    def create_bid_turn(player_id: str, min_bid: int, max_bid: int) -> Dict:
        """Create bid turn message."""
        return {
            'type': MessageType.BID_TURN,
            'player_id': player_id,
            'min_bid': min_bid,
            'max_bid': max_bid
        }
    
    @staticmethod
    def create_bid_made(player_id: str, amount: int) -> Dict:
        """Create bid made message."""
        return {
            'type': MessageType.BID_MADE,
            'player_id': player_id,
            'amount': amount
        }

    @staticmethod
    def create_bidding_status(current_bidder: str, bids_so_far: int, total_players: int) -> Dict:
        """Create bidding status message for spectators."""
        return {
            'type': MessageType.BIDDING_STATUS,
            'current_bidder': current_bidder,
            'bids_so_far': bids_so_far,
            'total_players': total_players
        }
    
    @staticmethod
    def create_bidding_complete(all_bids: Dict[str, int]) -> Dict:
        """Create bidding complete message."""
        return {
            'type': MessageType.BIDDING_COMPLETE,
            'all_bids': all_bids
        }

    # Trump selection messages
    @staticmethod
    def create_trump_chooser_selected(player_id: str, player_name: str) -> Dict:
        return {
            'type': MessageType.TRUMP_CHOOSER_SELECTED,
            'player_id': player_id,
            'player_name': player_name
        }

    @staticmethod
    def create_trump_selection_request(chooser_id: str) -> Dict:
        return {
            'type': MessageType.TRUMP_SELECTION_REQUEST,
            'chooser_id': chooser_id,
            'available_suits': ['Spades', 'Hearts', 'Diamonds', 'Clubs']
        }

    @staticmethod
    def create_trump_selected(chooser_id: str, trump_suit: str, round_number: int) -> Dict:
        return {
            'type': MessageType.TRUMP_SELECTED,
            'chooser_id': chooser_id,
            'trump_suit': trump_suit,
            'round_number': round_number
        }
    
    # Playing messages
    @staticmethod
    def create_play_turn(player_id: str, valid_cards: List[str]) -> Dict:
        """Create play turn message."""
        return {
            'type': MessageType.PLAY_TURN,
            'player_id': player_id,
            'valid_cards': valid_cards
        }

    @staticmethod
    def create_playing_status(current_player: str, trick_size: int) -> Dict:
        """Create playing status broadcast message."""
        return {
            'type': MessageType.PLAYING_STATUS,
            'current_player': current_player,
            'trick_size': trick_size
        }
    
    @staticmethod
    def create_card_played(player_id: str, card: str, trick_cards: List[tuple]) -> Dict:
        """Create card played message."""
        return {
            'type': MessageType.CARD_PLAYED,
            'player_id': player_id,
            'card': card,
            'trick_cards': [(pid, c) for pid, c in trick_cards]
        }
    
    @staticmethod
    def create_trick_won(winner_id: str, cards: List[tuple], 
                        tricks_won_count: Dict[str, int]) -> Dict:
        """Create trick won message."""
        return {
            'type': MessageType.TRICK_WON,
            'winner_id': winner_id,
            'cards': [(pid, c) for pid, c in cards],
            'tricks_won_count': tricks_won_count
        }
    
    # Scoring messages
    @staticmethod
    def create_round_end(scores: Dict[str, float], 
                        total_scores: Dict[str, float],
                        tricks_won: Dict[str, int]) -> Dict:
        """Create round end message."""
        return {
            'type': MessageType.ROUND_END,
            'scores': scores,
            'total_scores': total_scores,
            'tricks_won': tricks_won
        }
    
    @staticmethod
    def create_game_end(final_scores: Dict[str, float], 
                       winner: str,
                       all_round_scores: List[Dict]) -> Dict:
        """Create game end message."""
        return {
            'type': MessageType.GAME_END,
            'final_scores': final_scores,
            'winner': winner,
            'all_round_scores': all_round_scores
        }

    # State sync / reconnect
    @staticmethod
    def create_state_sync_request(player_id: str) -> Dict:
        return {
            'type': MessageType.STATE_SYNC_REQUEST,
            'player_id': player_id,
            'timestamp': __import__('time').time()
        }

    @staticmethod
    def create_state_sync_snapshot(data: Dict) -> Dict:
        return {
            'type': MessageType.STATE_SYNC_SNAPSHOT,
            **data
        }

    @staticmethod
    def create_player_rejoin(player_id: str) -> Dict:
        return {
            'type': MessageType.PLAYER_REJOIN,
            'player_id': player_id,
            'timestamp': __import__('time').time()
        }
    
    # Error message
    @staticmethod
    def create_error(message: str, error_code: str = 'GENERAL_ERROR') -> Dict:
        """Create error message."""
        return {
            'type': MessageType.ERROR,
            'message': message,
            'error_code': error_code
        }
