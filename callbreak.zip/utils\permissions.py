"""
Android permissions handler for Call Break game.
"""

from kivy.utils import platform


def request_all_permissions():
    """
    Request necessary Android permissions.
    
    Permissions needed:
    - INTERNET: Network communication
    - ACCESS_WIFI_STATE: Check WiFi status
    - CHANGE_WIFI_STATE: Manage WiFi
    - ACCESS_NETWORK_STATE: Check network status
    """
    if platform == 'android':
        try:
            from android.permissions import request_permissions, Permission
            
            permissions = [
                Permission.INTERNET,
                Permission.ACCESS_WIFI_STATE,
                Permission.CHANGE_WIFI_STATE,
                Permission.ACCESS_NETWORK_STATE,
            ]
            
            # WiFi-only permissions

            print("📋 Requesting Android permissions...")
            request_permissions(permissions)
            print("✅ Permissions requested")
            
        except ImportError:
            print("⚠️ Android permissions module not available")
    else:
        print("ℹ️ Not on Android - skipping permission request")


def check_permission_granted(permission_name: str) -> bool:
    """
    Check if a specific permission is granted.
    
    Args:
        permission_name: Permission to check
        
    Returns:
        True if granted, False otherwise
    """
    if platform == 'android':
        try:
            from android.permissions import check_permission, Permission
            
            return check_permission(permission_name)
        except ImportError:
            return False
    
    return True  # Non-Android always returns True


def get_permissions_status() -> dict:
    """
    Get status of all required permissions.
    
    Returns:
        Dictionary mapping permission names to granted status
    """
    if platform != 'android':
        return {'platform': 'non-android', 'all_granted': True}
    
    try:
        from android.permissions import check_permission, Permission
        
        permissions_status = {
            'INTERNET': check_permission(Permission.INTERNET),
            'ACCESS_WIFI_STATE': check_permission(Permission.ACCESS_WIFI_STATE),
            'CHANGE_WIFI_STATE': check_permission(Permission.CHANGE_WIFI_STATE),
            'ACCESS_NETWORK_STATE': check_permission(Permission.ACCESS_NETWORK_STATE),
        }
        
        permissions_status['all_granted'] = all(permissions_status.values())
        
        return permissions_status
        
    except ImportError:
        return {'error': 'android.permissions not available'}
