from kivy.app import App
from kivy.clock import Clock
from kivy.properties import NumericProperty
from kivy.uix.screenmanager import Screen

from ui.screens.bidding_screen import BiddingScreen


class BiddingOverlay(Screen):
    """Screen wrapper around the bidding UI that wires networking."""

    countdown = NumericProperty(30)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.content = BiddingScreen()
        self.add_widget(self.content)
        self.countdown_event = None

    def setup_bid(self, min_bid: int, max_bid: int):
        self.content.min_bid = min_bid
        self.content.max_bid = max_bid
        self.content.current_bid = min_bid
        self.content.slider.min = min_bid
        self.content.slider.max = max_bid
        self.content.slider.value = min_bid
        self._start_timer()

    def _start_timer(self):
        self.countdown = 30
        if self.countdown_event:
            self.countdown_event.cancel()
        self.countdown_event = Clock.schedule_interval(self._tick, 1.0)

    def _tick(self, _dt):
        self.countdown -= 1
        if self.countdown <= 0:
            self._submit_bid()

    def on_leave(self, *args):
        if self.countdown_event:
            self.countdown_event.cancel()

    def _submit_bid(self):
        app = App.get_running_app()
        if self.countdown_event:
            self.countdown_event.cancel()
        bid_value = int(self.content.current_bid)
        if app:
            if app.network_client:
                app.network_client.send_bid(bid_value)
            elif app.network_server:
                app.network_server.handle_bid(app.player_id, bid_value)
        if app:
            app.goto_screen("game")

    # Expose button callback for content
    def confirm_bid(self):
        self._submit_bid()
