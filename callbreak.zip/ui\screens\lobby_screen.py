"""
Lobby Screen for Call Break game.

WiFi-only connection entry: host or join via local network game code.
"""

from kivy.graphics import Color, Rectangle
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.scrollview import ScrollView
from kivy.uix.togglebutton import ToggleButton
from kivy.uix.textinput import TextInput

from networking.game_code import GameCodeManager


class LobbyScreen(BoxLayout):
    """Lobby screen with WiFi-only connection and player selection."""

    def __init__(self, app, **kwargs):
        super().__init__(**kwargs)
        self.app = app
        self.orientation = 'vertical'
        self.padding = [20, 16, 20, 16]
        self.spacing = 16

        with self.canvas.before:
            Color(0.10, 0.14, 0.28, 1)
            self.bg_rect = Rectangle()
        self.bind(size=self._update_bg, pos=self._update_bg)

        self._build_ui()
        self._update_connection_info(self.player_count)

    def _build_ui(self):
        """Build the WiFi-only lobby UI."""
        # Title / header
        title = Label(
            text='[b][color=FFD700]CALL BREAK[/color][/b]\n[size=18sp]Local Multiplayer[/size]',
            font_size='44sp',
            size_hint=(1, None),
            height=140,
            markup=True,
            halign='center',
            valign='middle',
            color=(1, 1, 1, 1),
        )
        title.bind(size=title.setter('text_size'))
        self.add_widget(title)

        # Player count selector (pills 2-12)
        self.player_count = 4
        pill_row_container = BoxLayout(orientation='vertical', size_hint=(1, None), height=140, spacing=8)
        pill_row_container.add_widget(Label(text='Number of Players', font_size='18sp', color=(1, 1, 1, 0.9), size_hint_y=None, height=26))
        pill_scroll = ScrollView(size_hint=(1, None), height=90, do_scroll_y=False)
        pill_row = BoxLayout(orientation='horizontal', spacing=12, size_hint_x=None, height=72, padding=[6, 0])
        pill_row.bind(minimum_width=pill_row.setter('width'))
        for i in range(2, 13):
            btn = ToggleButton(
                text=str(i),
                size_hint=(None, None),
                size=(68, 68),
                group='players',
                state='down' if i == self.player_count else 'normal',
                background_normal='',
                background_color=(0.99, 0.84, 0.0, 1) if i == self.player_count else (0, 0, 0, 0),
                border=(2, 2, 2, 2),
            )
            btn.bind(on_press=lambda inst, count=i: self._select_player_count(count))
            pill_row.add_widget(btn)
        pill_scroll.add_widget(pill_row)
        pill_row_container.add_widget(pill_scroll)
        self.add_widget(pill_row_container)

        # Connection info label
        self.connection_info = Label(
            text='1 Deck • 13 Cards Each',
            font_size='16sp',
            size_hint=(1, None),
            height=32,
            color=(0.82, 0.82, 0.82, 1)
        )
        self.add_widget(self.connection_info)

        # WiFi Section
        wifi_card = BoxLayout(orientation='vertical', padding=[14, 12], spacing=12, size_hint=(1, None), height=260)
        wifi_card.canvas.before.clear()
        with wifi_card.canvas.before:
            Color(0.12, 0.45, 0.22, 0.9)
            wifi_card.bg = Rectangle()
        wifi_card.bind(pos=lambda *_: self._update_card_bg(wifi_card), size=lambda *_: self._update_card_bg(wifi_card))

        wifi_header = Label(
            text='📶 WiFi Local Network',
            font_size='20sp',
            color=(0.85, 1, 0.85, 1),
            size_hint_y=None,
            height=32,
        )
        wifi_card.add_widget(wifi_header)

        info_label = Label(
            text='Connect players on same WiFi',
            font_size='15sp',
            color=(0.9, 0.98, 0.9, 1),
            size_hint_y=None,
            height=26,
        )
        wifi_card.add_widget(info_label)

        self.host_wifi_btn = Button(
            text='🌐 HOST GAME',
            size_hint_y=None,
            height=72,
            font_size='20sp',
            background_normal='',
            background_color=(0.20, 0.80, 0.40, 1),
        )
        self.host_wifi_btn.bind(on_press=self.host_wifi_game)
        wifi_card.add_widget(self.host_wifi_btn)

        self.ip_input = TextInput(
            hint_text='Enter Game Code (e.g., ABC-123)',
            multiline=False,
            size_hint_y=None,
            height=64,
            font_size='20sp',
            background_color=(1, 1, 1, 0.12),
            foreground_color=(1, 1, 1, 1),
            cursor_color=(1, 1, 1, 1),
            halign='center',
        )
        wifi_card.add_widget(self.ip_input)

        self.join_wifi_btn = Button(
            text='🔍 JOIN GAME',
            size_hint_y=None,
            height=72,
            font_size='20sp',
            background_normal='',
            background_color=(0.20, 0.60, 0.90, 1),
        )
        self.join_wifi_btn.bind(on_press=self.join_wifi_game)
        wifi_card.add_widget(self.join_wifi_btn)

        self.add_widget(wifi_card)

        # Help footer
        footer = BoxLayout(orientation='horizontal', size_hint=(1, None), height=52, spacing=10)
        help_btn = Button(
            text='❓ How to Connect',
            font_size='14sp',
            background_color=(0, 0, 0, 0),
            color=(1, 1, 1, 1),
            border=(0, 0, 0, 0),
        )
        help_btn.bind(on_press=self.show_help)
        footer.add_widget(help_btn)
        footer.add_widget(Label(text='v1.0', font_size='12sp', color=(0.7, 0.7, 0.7, 1), size_hint_x=None, width=60))
        self.add_widget(footer)
    
    def _select_player_count(self, count):
        self.player_count = count
        self._update_connection_info(count)

    def _update_connection_info(self, num_players):
        from utils.helpers import format_player_count

        self.connection_info.text = format_player_count(num_players)
    
    def host_wifi_game(self, instance):
        """Start hosting via WiFi."""
        self.app.start_wifi_server(self.player_count)
    
    def join_wifi_game(self, instance):
        """Join game via WiFi."""
        raw = self.ip_input.text.strip()
        if not raw:
            self.show_error_popup('Error', 'Please enter the 6-digit game code')
            return

        # Expect 6-character code (with or without dash)
        clean = raw.replace('-', '').upper()
        if len(clean) != 6:
            self.show_error_popup('Error', 'Enter the 6-digit game code shared by the host')
            return

        resolved = GameCodeManager.resolve_code(f"{clean[:3]}-{clean[3:]}")
        if resolved:
            host_ip, port, _host = resolved
            self.app.connect_wifi_client(host_ip, port=port)
        else:
            self.show_error_popup('Not Found', 'Game code not found. Make sure the host is running and you are on the same WiFi.')

    def _update_bg(self, *args):
        if hasattr(self, 'bg_rect'):
            self.bg_rect.pos = self.pos
            self.bg_rect.size = self.size

    def _update_card_bg(self, widget):
        if hasattr(widget, 'bg'):
            widget.bg.pos = widget.pos
            widget.bg.size = widget.size
    
    def show_help(self, instance):
        """Show simplified WiFi-only connection instructions."""
        popup_content = BoxLayout(orientation='vertical', padding=20, spacing=15)

        title = Label(
            text='How to Connect',
            font_size='24sp',
            bold=True,
            size_hint_y=0.15
        )
        popup_content.add_widget(title)

        instructions = Label(
            text=(
                "1. Make sure all players are on the SAME WiFi network\n\n"
                "2. One player clicks HOST GAME\n\n"
                "3. Share the 6-digit game code with others\n\n"
                "4. Other players click JOIN GAME and enter the code\n\n"
                "5. Once everyone joins, host starts the game!"
            ),
            font_size='16sp',
            markup=True,
            size_hint_y=0.7,
            halign='left',
            valign='top'
        )
        instructions.bind(size=instructions.setter('text_size'))
        popup_content.add_widget(instructions)

        close_btn = Button(
            text='Got It!',
            size_hint=(1, None),
            height=50,
            background_color=(0.2, 0.7, 0.4, 1)
        )
        popup_content.add_widget(close_btn)

        popup = Popup(
            title='',
            content=popup_content,
            size_hint=(0.85, 0.7),
            separator_height=0
        )
        close_btn.bind(on_press=popup.dismiss)
        popup.open()
    
    def show_error_popup(self, title, message):
        """Show error popup."""
        content = BoxLayout(orientation='vertical', padding=10, spacing=10)
        content.add_widget(Label(text=message, markup=True))
        
        popup = Popup(
            title=title,
            content=content,
            size_hint=(0.8, 0.5)
        )
        
        close_btn = Button(text='OK', size_hint_y=0.25)
        close_btn.bind(on_press=popup.dismiss)
        content.add_widget(close_btn)
        
        popup.open()
    
    def show_info_popup(self, title, message):
        """Show info popup."""
        content = BoxLayout(orientation='vertical', padding=10, spacing=10)
        
        scroll = ScrollView(size_hint=(1, 0.8))
        info_label = Label(
            text=message,
            markup=True,
            size_hint_y=None,
            halign='left',
            valign='top'
        )
        info_label.bind(texture_size=info_label.setter('size'))
        info_label.bind(size=info_label.setter('text_size'))
        scroll.add_widget(info_label)
        content.add_widget(scroll)
        
        popup = Popup(
            title=title,
            content=content,
            size_hint=(0.85, 0.8)
        )
        
        close_btn = Button(text='Close', size_hint_y=0.15)
        close_btn.bind(on_press=popup.dismiss)
        content.add_widget(close_btn)
        
        popup.open()
    
    def show_confirmation_popup(self, title, message, on_yes=None):
        """Retained for interface compatibility (not used in WiFi-only flow)."""
        content = BoxLayout(orientation='vertical', padding=10, spacing=10)
        content.add_widget(Label(text=message, markup=True, size_hint_y=0.7))

        popup = Popup(
            title=title,
            content=content,
            size_hint=(0.8, 0.6)
        )

        btn_layout = BoxLayout(orientation='horizontal', size_hint_y=0.3, spacing=10)

        dismiss_btn = Button(text='OK', background_color=(0.2, 0.6, 0.2, 1))
        dismiss_btn.bind(on_press=popup.dismiss)

        btn_layout.add_widget(dismiss_btn)
        content.add_widget(btn_layout)

        popup.open()
