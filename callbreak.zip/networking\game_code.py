"""Simple game code management for LAN hosts.

Generates short codes and tracks active games locally (best-effort LAN mapping).
"""

from __future__ import annotations

import random
import socket
import string
from typing import Dict, Optional, Tuple

# In-memory code registry: {code: (ip, port, host_name)}
ACTIVE_GAMES: Dict[str, Tuple[str, int, str]] = {}


class GameCodeManager:
    """Generates and resolves short game codes."""

    @staticmethod
    def generate_code(length: int = 6) -> str:
        chars = string.ascii_uppercase + string.digits
        code = "".join(random.choice(chars) for _ in range(length))
        return f"{code[:3]}-{code[3:]}"

    @staticmethod
    def get_local_ip() -> str:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
            s.close()
            return local_ip
        except Exception:
            try:
                return socket.gethostbyname(socket.gethostname())
            except Exception:
                return "127.0.0.1"

    @staticmethod
    def get_default_port() -> int:
        return 5555

    @staticmethod
    def resolve_code(code: str) -> Optional[Tuple[str, int, str]]:
        norm = code.strip().upper()
        return ACTIVE_GAMES.get(norm)

    @staticmethod
    def register(code: str, ip: str, port: int, host_name: str) -> None:
        ACTIVE_GAMES[code.upper()] = (ip, port, host_name)

    @staticmethod
    def unregister(code: Optional[str]) -> None:
        if not code:
            return
        ACTIVE_GAMES.pop(code.upper(), None)
