"""
Unit tests for game logic.

Run with: pytest tests/test_game_logic.py
"""

import pytest
from game.card import Card, Deck, get_deck_config
from game.player import Player
from game.game_logic import GameState, GamePhase
from networking.message_handler import MessageHandler, MessageType


class TestCard:
    """Test Card class."""
    
    def test_card_creation(self):
        """Test creating a card."""
        card = Card('Spades', 'A')
        assert card.suit == 'Spades'
        assert card.rank == 'A'
        assert card.value == 14
    
    def test_trump_comparison(self):
        """Test trump beats non-trump."""
        spade_2 = Card('Spades', '2')
        heart_ace = Card('Hearts', 'A')
        assert spade_2.compare(heart_ace, 'Spades') == 1
    
    def test_same_suit_comparison(self):
        """Test comparing same suit."""
        heart_king = Card('Hearts', 'K')
        heart_10 = Card('Hearts', '10')
        assert heart_king.compare(heart_10, 'Spades') == 1

    def test_dynamic_trump_changes(self):
        """Test that chosen trump suit drives comparison."""
        spade_ace = Card('Spades', 'A')
        heart_two = Card('Hearts', '2')
        # Hearts trump beats non-trump spade in this mode
        assert heart_two.compare(spade_ace, 'Hearts') == 1
    
    def test_card_string(self):
        """Test card string representation."""
        card = Card('Spades', 'A')
        assert str(card) == 'AS'


class TestDeck:
    """Test Deck class."""
    
    def test_single_deck(self):
        """Test single deck has 52 cards."""
        deck = Deck(num_decks=1)
        assert len(deck) == 52
    
    def test_double_deck(self):
        """Test double deck has 104 cards."""
        deck = Deck(num_decks=2)
        assert len(deck) == 104
    
    def test_dealing_4_players(self):
        """Test dealing to 4 players."""
        deck = Deck(num_decks=1)
        hands, remaining = deck.deal(4)
        
        assert len(hands) == 4
        assert len(hands[0]) == 13
        assert len(remaining) == 0
    
    def test_deck_config(self):
        """Test deck configuration."""
        num_decks, cards_per_player, remaining = get_deck_config(4)
        assert num_decks == 1
        assert cards_per_player == 13
        assert remaining == 0
        
        num_decks, cards_per_player, remaining = get_deck_config(9)
        assert num_decks == 2
        assert cards_per_player == 11
        assert remaining == 5


class TestPlayer:
    """Test Player class."""
    
    def test_player_creation(self):
        """Test creating a player."""
        player = Player('id123', 'John')
        assert player.player_id == 'id123'
        assert player.name == 'John'
        assert player.total_score == 0.0
    
    def test_score_exact_match(self):
        """Test scoring with exact match."""
        player = Player('id1', 'Test')
        player.current_bid = 5
        player.tricks_won_this_round = 5
        
        score = player.calculate_score()
        assert score == 5.0
    
    def test_score_over_trick(self):
        """Test scoring with over-tricks."""
        player = Player('id1', 'Test')
        player.current_bid = 3
        player.tricks_won_this_round = 6
        
        score = player.calculate_score()
        assert score == 3.3
    
    def test_score_under_trick(self):
        """Test scoring with under-tricks (penalty)."""
        player = Player('id1', 'Test')
        player.current_bid = 4
        player.tricks_won_this_round = 2
        
        score = player.calculate_score()
        assert score == -4.0


class TestGameState:
    """Test GameState class."""
    
    def test_game_creation(self):
        """Test creating a game."""
        game = GameState(num_players=4, num_rounds=5)
        assert game.num_players == 4
        assert game.num_rounds == 5
        assert game.phase == GamePhase.LOBBY
    
    def test_add_player(self):
        """Test adding players."""
        game = GameState(num_players=4)
        player1 = Player('id1', 'Player1')
        player2 = Player('id2', 'Player2')
        
        assert game.add_player(player1) == True
        assert game.add_player(player2) == True
        assert len(game.players) == 2


def test_bidding_timeout_message_shape():
    # Ensure bid_turn/status follow protocol for UI
    bid_turn = MessageHandler.create_bid_turn('p1', 1, 13)
    assert bid_turn['type'] == MessageType.BID_TURN
    assert bid_turn['player_id'] == 'p1'
    assert bid_turn['min_bid'] == 1
    assert bid_turn['max_bid'] == 13

    bid_status = MessageHandler.create_bidding_status('Alice', 2, 4)
    assert bid_status['type'] == MessageType.BIDDING_STATUS
    assert bid_status['current_bidder'] == 'Alice'
    assert bid_status['bids_so_far'] == 2
    assert bid_status['total_players'] == 4


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
