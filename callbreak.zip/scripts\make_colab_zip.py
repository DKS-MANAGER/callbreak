import os
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT.parent / "callbreak-colab.zip"
EXCLUDE_DIRS = {"__pycache__", ".git", ".idea", ".vscode", ".buildozer", "build", "bin"}
EXCLUDE_SUFFIXES = (".pyc", ".pyo", ".pyd", ".so", ".dll", ".zip", ".apk", ".log")


def should_skip(rel_path: Path) -> bool:
    parts = rel_path.parts
    if any(part in EXCLUDE_DIRS for part in parts):
        return True
    return rel_path.suffix in EXCLUDE_SUFFIXES


def main() -> None:
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in ROOT.rglob("*"):
            rel_path = path.relative_to(ROOT)
            if path.is_dir():
                if rel_path.name in EXCLUDE_DIRS:
                    continue
                if any(part in EXCLUDE_DIRS for part in rel_path.parts):
                    continue
                continue  # directories are added implicitly
            if should_skip(rel_path):
                continue
            arcname = rel_path.as_posix()
            zf.write(path, arcname)
    print(f"Wrote {OUT}")


if __name__ == "__main__":
    main()
