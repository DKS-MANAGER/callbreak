"""
Player class for Call Break game.

Manages player state including hand, bids, scores, and tricks won.
"""

from typing import List, Optional
from .card import Card


class Player:
    """
    Represents a player in the Call Break game.
    
    Attributes:
        player_id: Unique identifier
        name: Display name
        hand: List of cards in player's hand
        current_bid: Bid for current round
        tricks_won_this_round: Number of tricks won this round
        score_this_round: Score for current round
        total_score: Cumulative score across all rounds
        is_ready: Ready state in lobby
        is_connected: Connection status
        round_scores: History of scores per round
    """
    
    def __init__(self, player_id: str, name: str):
        """
        Initialize a player.
        
        Args:
            player_id: Unique identifier (UUID recommended)
            name: Player's display name
        """
        self.player_id = player_id
        self.name = name
        self.hand: List[Card] = []
        self.current_bid: int = 0
        self.tricks_won_this_round: int = 0
        self.score_this_round: float = 0.0
        self.total_score: float = 0.0
        self.is_ready: bool = False
        self.is_connected: bool = True
        self.round_scores: List[float] = []
    
    def set_hand(self, cards: List[Card], trump_suit: str = 'Spades'):
        """
        Set player's hand and sort it.
        
        Args:
            cards: List of cards dealt to player
            trump_suit: Current trump suit for sorting priority
        """
        self.hand = cards
        self.sort_hand(trump_suit)
    
    def sort_hand(self, trump_suit: str = 'Spades'):
        """
        Sort cards by suit (trump first) and rank.
        """
        suit_order = {s: (1 if s != trump_suit else 0) for s in ['Spades', 'Hearts', 'Diamonds', 'Clubs']}
        self.hand.sort(key=lambda c: (suit_order.get(c.suit, 2), -c.value))
    
    def play_card(self, card: Card) -> bool:
        """
        Remove and return a card from player's hand.
        
        Args:
            card: Card to play
            
        Returns:
            True if card was in hand and removed, False otherwise
        """
        if card in self.hand:
            self.hand.remove(card)
            return True
        return False
    
    def has_suit(self, suit: str) -> bool:
        """
        Check if player has any cards of specified suit.
        
        Args:
            suit: Suit to check
            
        Returns:
            True if player has at least one card of that suit
        """
        return any(c.suit == suit for c in self.hand)
    
    def has_trump(self, trump_suit: str) -> bool:
        """Check if player has any trump cards for the given suit."""
        return any(c.suit == trump_suit for c in self.hand)
    
    def get_cards_of_suit(self, suit: str) -> List[Card]:
        """
        Get all cards of specified suit in hand.
        
        Args:
            suit: Suit to filter
            
        Returns:
            List of cards of that suit
        """
        return [c for c in self.hand if c.suit == suit]
    
    def get_trump_cards(self, trump_suit: str) -> List[Card]:
        """Get all trump cards for the given suit."""
        return [c for c in self.hand if c.suit == trump_suit]
    
    def set_bid(self, bid: int):
        """
        Set player's bid for the round.
        
        Args:
            bid: Number of tricks player expects to win
        """
        self.current_bid = bid
    
    def win_trick(self):
        """Increment tricks won counter."""
        self.tricks_won_this_round += 1
    
    def calculate_score(self) -> float:
        """
        Calculate score for current round based on bid vs tricks won.
        
        Scoring Rules:
        - Exact match: Win exactly bid amount = +bid points
        - Over-trick: Win more than bid = +bid + 0.1 per extra trick
        - Under-trick (PENALTY): Win fewer than bid = -bid points
        
        Returns:
            Score for this round
            
        Examples:
            >>> player.current_bid = 5
            >>> player.tricks_won_this_round = 5
            >>> player.calculate_score()
            5.0  # Exact match
            
            >>> player.current_bid = 3
            >>> player.tricks_won_this_round = 6
            >>> player.calculate_score()
            3.3  # Over-trick: 3 + (3 * 0.1)
            
            >>> player.current_bid = 4
            >>> player.tricks_won_this_round = 2
            >>> player.calculate_score()
            -4.0  # Under-trick penalty
        """
        if self.tricks_won_this_round == self.current_bid:
            # Exact match - bid points
            self.score_this_round = float(self.current_bid)
        elif self.tricks_won_this_round > self.current_bid:
            # Over-trick - bid + 0.1 per extra
            extra_tricks = self.tricks_won_this_round - self.current_bid
            self.score_this_round = float(self.current_bid) + (extra_tricks * 0.1)
        else:
            # Under-trick - negative bid (penalty)
            self.score_this_round = float(-self.current_bid)
        
        self.total_score += self.score_this_round
        self.round_scores.append(self.score_this_round)
        
        return self.score_this_round
    
    def reset_for_round(self):
        """Reset player state for a new round."""
        self.hand = []
        self.current_bid = 0
        self.tricks_won_this_round = 0
        self.score_this_round = 0.0
    
    def to_dict(self) -> dict:
        """
        Convert player to dictionary for JSON serialization.
        
        Returns:
            Dictionary with player data
        """
        return {
            'player_id': self.player_id,
            'name': self.name,
            'hand_size': len(self.hand),
            'current_bid': self.current_bid,
            'tricks_won': self.tricks_won_this_round,
            'score_this_round': self.score_this_round,
            'total_score': self.total_score,
            'is_ready': self.is_ready,
            'is_connected': self.is_connected
        }
    
    def get_hand_strings(self) -> List[str]:
        """Get list of card strings for network transmission."""
        return [str(card) for card in self.hand]
    
    def __str__(self) -> str:
        """String representation."""
        return f"Player({self.name}, Score: {self.total_score})"
    
    def __repr__(self) -> str:
        """Detailed representation."""
        return (f"Player(id={self.player_id}, name={self.name}, "
                f"hand={len(self.hand)}, bid={self.current_bid}, "
                f"tricks={self.tricks_won_this_round}, score={self.total_score})")
