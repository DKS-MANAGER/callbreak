"""
Game State Manager for Call Break.

Manages the entire game flow, phases, and state transitions.
"""

import random
from typing import List, Optional, Dict, Tuple
from .card import Card, Deck, get_deck_config
from .player import Player
from .trick_validator import (
    validate_card_play,
    get_valid_cards,
    determine_trick_winner
)
from .scoring import calculate_round_scores, get_total_scores, get_tricks_won


class GamePhase:
    """Game phase constants."""
    LOBBY = 'LOBBY'
    DEALING = 'DEALING'
    TRUMP_SELECTION = 'TRUMP_SELECTION'
    BIDDING = 'BIDDING'
    PLAYING = 'PLAYING'
    ROUND_END = 'ROUND_END'
    GAME_END = 'GAME_END'


class GameState:
    """
    Manages the complete game state for Call Break.
    
    Attributes:
        num_players: Number of players (2-12)
        num_rounds: Total rounds to play (default 5)
        current_round: Current round number (1-based)
        phase: Current game phase
        players: List of Player objects
        player_order: Player IDs in turn order (counter-clockwise)
        current_player_index: Index of player whose turn it is
        dealer_index: Index of dealer
        deck: Current deck
        current_trick: Cards played in current trick
        led_suit: Suit led in current trick
        tricks_history: History of completed tricks
        round_history: History of round scores
    """
    
    def __init__(self, num_players: int, num_rounds: int = 5, trump_mode: str = 'dynamic'):
        """
        Initialize game state.
        
        Args:
            num_players: Number of players (2-12)
            num_rounds: Number of rounds to play (default 5)
        """
        if not 2 <= num_players <= 12:
            raise ValueError("num_players must be between 2 and 12")
        
        self.num_players = num_players
        self.num_rounds = num_rounds
        self.current_round = 0
        self.phase = GamePhase.LOBBY
        self.trump_mode = trump_mode  # 'dynamic' or 'classic'
        self.current_trump_suit: Optional[str] = None
        self.trump_chooser_id: Optional[str] = None
        
        self.players: List[Player] = []
        self.player_order: List[str] = []
        self.current_player_index = 0
        self.dealer_index = 0
        
        self.deck: Optional[Deck] = None
        self.current_trick: List[Tuple[str, Card]] = []
        self.led_suit: Optional[str] = None
        self.tricks_history: List[Dict] = []
        self.round_history: List[Dict] = []
        
        # Deck configuration
        num_decks, cards_per_player, _ = get_deck_config(num_players)
        self.num_decks = num_decks
        self.cards_per_player = cards_per_player
    
    def add_player(self, player: Player) -> bool:
        """
        Add a player to the game (lobby phase).
        
        Args:
            player: Player to add
            
        Returns:
            True if added successfully
        """
        if self.phase != GamePhase.LOBBY:
            return False
        
        if len(self.players) >= self.num_players:
            return False
        
        if player.player_id in [p.player_id for p in self.players]:
            return False
        
        self.players.append(player)
        return True
    
    def remove_player(self, player_id: str) -> bool:
        """
        Remove a player from the game.
        
        Args:
            player_id: ID of player to remove
            
        Returns:
            True if removed successfully
        """
        player = self.get_player(player_id)
        if player:
            self.players.remove(player)
            return True
        return False
    
    def get_player(self, player_id: str) -> Optional[Player]:
        """Get player by ID."""
        for player in self.players:
            if player.player_id == player_id:
                return player
        return None
    
    def get_current_player(self) -> Optional[Player]:
        """Get player whose turn it is."""
        if not self.player_order:
            return None
        player_id = self.player_order[self.current_player_index]
        return self.get_player(player_id)
    
    def all_players_ready(self) -> bool:
        """Check if all players are ready to start."""
        if len(self.players) != self.num_players:
            return False
        return all(p.is_ready for p in self.players)
    
    def start_game(self):
        """
        Start the game (transition from LOBBY to DEALING).
        
        Sets up player order and starts first round.
        """
        if self.phase != GamePhase.LOBBY:
            raise ValueError("Can only start game from LOBBY phase")
        
        if not self.all_players_ready():
            raise ValueError("Not all players are ready")
        
        # Randomize player order (counter-clockwise from dealer's right)
        random.shuffle(self.players)
        self.player_order = [p.player_id for p in self.players]
        self.dealer_index = 0
        
        # Start first round
        self.current_round = 1
        self.start_round()
    
    def start_round(self):
        """Start a new round."""
        if self.current_round > self.num_rounds:
            self.end_game()
            return
        
        # Reset players for new round
        for player in self.players:
            player.reset_for_round()
        
        # Create and shuffle deck
        self.deck = Deck(num_decks=self.num_decks)
        self.deck.shuffle()
        
        # Deal cards
        self.phase = GamePhase.DEALING
        self.deal_cards()
        
        # Trump selection phase
        self.phase = GamePhase.TRUMP_SELECTION
        self.current_trump_suit = None
        self.trump_chooser_id = self.select_trump_chooser()
        if self.trump_mode == 'classic':
            self.set_trump_suit('Spades')
    
    def deal_cards(self):
        """Deal cards to all players."""
        hands, _ = self.deck.deal(self.num_players)
        
        for player, hand in zip(self.players, hands):
            player.set_hand(hand, trump_suit=None)
    
    def place_bid(self, player_id: str, bid: int) -> Tuple[bool, str]:
        """
        Place a bid for a player.
        
        Args:
            player_id: Player placing bid
            bid: Bid amount
            
        Returns:
            Tuple of (success, message)
        """
        if self.phase != GamePhase.BIDDING:
            return False, "Not in bidding phase"
        
        current_player = self.get_current_player()
        if not current_player or current_player.player_id != player_id:
            return False, "Not your turn"
        
        # Validate bid
        if not 1 <= bid <= self.cards_per_player:
            return False, f"Bid must be between 1 and {self.cards_per_player}"
        
        # Set bid
        current_player.set_bid(bid)
        
        # Move to next player
        self.current_player_index = (self.current_player_index + 1) % self.num_players
        
        # Check if bidding complete
        if all(p.current_bid > 0 for p in self.players):
            self.start_playing()
        
        return True, "Bid placed"
    
    def start_playing(self):
        """Start the playing phase after all bids placed."""
        self.phase = GamePhase.PLAYING
        self.current_trick = []
        self.led_suit = None
        self.tricks_history = []
        
        # First player after dealer leads
        self.current_player_index = (self.dealer_index + 1) % self.num_players
    
    def play_card(self, player_id: str, card: Card) -> Tuple[bool, str]:
        """
        Play a card for a player.
        
        Args:
            player_id: Player playing card
            card: Card to play
            
        Returns:
            Tuple of (success, message)
        """
        if self.phase != GamePhase.PLAYING:
            return False, "Not in playing phase"
        
        current_player = self.get_current_player()
        if not current_player or current_player.player_id != player_id:
            return False, "Not your turn"
        
        # Validate card play
        is_valid, reason = validate_card_play(
            current_player,
            card,
            self.current_trick,
            self.led_suit,
            self.current_trump_suit
        )
        
        if not is_valid:
            return False, reason
        
        # Play the card
        if not current_player.play_card(card):
            return False, "Card not in hand"
        
        # Add to trick
        self.current_trick.append((player_id, card))
        
        # Set led suit if first card
        if len(self.current_trick) == 1:
            self.led_suit = card.suit
        
        # Move to next player
        self.current_player_index = (self.current_player_index + 1) % self.num_players
        
        # Check if trick complete
        if len(self.current_trick) == self.num_players:
            self.complete_trick()
        
        return True, "Card played"
    
    def complete_trick(self):
        """Complete current trick and determine winner."""
        if len(self.current_trick) != self.num_players:
            raise ValueError("Trick not complete")
        
        # Determine winner
        winner_index, winner_id = determine_trick_winner(
            self.current_trick,
            self.led_suit,
            self.current_trump_suit
        )
        
        winner = self.get_player(winner_id)
        if winner:
            winner.win_trick()
        
        # Save trick to history
        self.tricks_history.append({
            'trick_number': len(self.tricks_history) + 1,
            'cards': [(pid, str(card)) for pid, card in self.current_trick],
            'led_suit': self.led_suit,
            'winner_id': winner_id,
            'winner_name': winner.name if winner else ''
        })
        
        # Reset for next trick
        self.current_trick = []
        self.led_suit = None
        
        # Winner leads next trick
        self.current_player_index = self.player_order.index(winner_id)
        
        # Check if round complete
        if all(len(p.hand) == 0 for p in self.players):
            self.end_round()
    
    def end_round(self):
        """End current round and calculate scores."""
        self.phase = GamePhase.ROUND_END
        
        # Calculate scores
        round_scores = calculate_round_scores(self.players)
        total_scores = get_total_scores(self.players)
        tricks_won = get_tricks_won(self.players)
        
        # Save round history
        self.round_history.append({
            'round': self.current_round,
            'bids': {p.player_id: p.current_bid for p in self.players},
            'tricks_won': tricks_won,
            'scores': round_scores,
            'total_scores': total_scores
        })
        
        # Move to next round or end game
        self.current_round += 1
        
        if self.current_round > self.num_rounds:
            self.end_game()
        else:
            # Rotate dealer
            self.dealer_index = (self.dealer_index + 1) % self.num_players
    
    def continue_to_next_round(self):
        """Continue to next round after viewing scores."""
        if self.phase != GamePhase.ROUND_END:
            return
        
        self.start_round()
    
    def end_game(self):
        """End the game."""
        self.phase = GamePhase.GAME_END
    
    def get_valid_cards_for_current_player(self) -> List[Card]:
        """Get list of valid cards for current player."""
        current_player = self.get_current_player()
        if not current_player:
            return []
        
        return get_valid_cards(
            current_player,
            self.current_trick,
            self.led_suit,
            self.current_trump_suit
        )

    # ========== Trump selection helpers ==========

    def select_trump_chooser(self) -> Optional[str]:
        """Randomly select and store the trump chooser for this round."""
        if not self.players:
            return None
        chooser = random.choice(self.players)
        self.trump_chooser_id = chooser.player_id
        return chooser.player_id

    def set_trump_suit(self, suit: str):
        """Set current trump suit for this round and advance to bidding."""
        if suit not in Card.SUITS:
            raise ValueError("Invalid trump suit")
        self.current_trump_suit = suit
        # Resort hands with trump priority
        for player in self.players:
            player.sort_hand(trump_suit=suit)
        # Proceed to bidding
        self.phase = GamePhase.BIDDING
        self.current_player_index = (self.dealer_index + 1) % self.num_players

    def update_trump_suit(self, trump_suit: str):
        """Update trump metadata on all cards without advancing phase."""
        self.current_trump_suit = trump_suit
        for player in self.players:
            for card in player.hand:
                card.is_trump = (card.suit == trump_suit)
            player.sort_hand(trump_suit=trump_suit)
        for idx, (pid, card) in enumerate(list(self.current_trick)):
            card.is_trump = (card.suit == trump_suit)
    
    def to_dict(self) -> dict:
        """Convert game state to dictionary for serialization."""
        return {
            'num_players': self.num_players,
            'num_rounds': self.num_rounds,
            'current_round': self.current_round,
            'phase': self.phase,
            'players': [p.to_dict() for p in self.players],
            'player_order': self.player_order,
            'current_player_index': self.current_player_index,
            'dealer_index': self.dealer_index,
            'current_trick': [(pid, str(card)) for pid, card in self.current_trick],
            'led_suit': self.led_suit,
            'current_trump_suit': self.current_trump_suit,
            'trump_chooser_id': self.trump_chooser_id,
            'trump_mode': self.trump_mode,
            'num_decks': self.num_decks,
            'cards_per_player': self.cards_per_player
        }
