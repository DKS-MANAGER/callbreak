# Build APK on Google Colab (Buildozer)

Use this notebook snippet to build the APK in Colab. It installs buildozer and runs the debug build. Upload `callbreak.zip` when prompted.

```python
#@title Build Callbreak APK with Buildozer
!sudo apt-get update -qq
!sudo apt-get install -y -qq python3-pip python3-setuptools git zip unzip openjdk-11-jdk zlib1g-dev
!pip install --quiet buildozer Cython==0.29.36 virtualenv

from google.colab import files
import os, subprocess

# Upload your project zip (exported as callbreak.zip)
uploaded = files.upload()
if 'callbreak.zip' not in uploaded:
    raise SystemExit('Upload callbreak.zip first')
!unzip -q callbreak.zip -d workspace
os.chdir('workspace/callbreak')

# Optional: pin Kivy version in buildozer.spec if not already
# !sed -i "s/^requirements =.*/requirements = python3,kivy==2.3.0/" buildozer.spec

# Init SDK/NDK and build debug APK
!buildozer android debug

# Find the APK and download
apk_files = !ls bin/*.apk
print('APKs:', apk_files)
if apk_files:
    files.download(apk_files[0])
```

**Notes**
- Buildozer must run on Linux; Colab works, but first build takes time to download SDK/NDK.
- Ensure `buildozer.spec` has correct `requirements` (python3,kivy==2.3.0 plus any extras like requests/jinja2) and `android.permissions` includes WiFi/network permissions (INTERNET, ACCESS_WIFI_STATE, CHANGE_WIFI_STATE, ACCESS_NETWORK_STATE).
- The output APK will be in `bin/`. The snippet attempts to download the first APK automatically.
