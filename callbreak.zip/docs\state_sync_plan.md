## State Sync / Reconnect Plan

Goal: allow reconnecting clients to request a snapshot and resume mid-round with minimal disruption.

### Snapshot contents
- round_number
- phase (lobby/game_start/dealing/trump_selection/bidding/playing/trick_end/round_end)
- player_order, current_player_id (or bidder)
- trump_suit, trump_chooser_id
- hands per player (only send to that player), remaining hand sizes for others
- bids per player, tricks_won_count
- current_trick cards (ordered tuples of player_id, card)
- scores: round_scores so far, total_scores
- timers: remaining timeout for current action (optional, best-effort)

### Protocol additions
- Request: `state_sync_request` with player_id
- Response (to requester): `state_sync_snapshot` with snapshot fields above; hand is filtered to requester; other hands omitted/length only
- Broadcast (optional): `player_rejoin` to inform others the player is back

### Server hooks (WiFi)
- Maintain `last_snapshot` per player or generate on demand from authoritative state (game_state + in-flight trick/bid context).
- On client reconnect (or explicit request), send `state_sync_snapshot` via send_to_player.
- Guard against phase drift: if snapshot phase mismatches current phase, force client to lobby/observe until next round.

### Client handling
- On `state_sync_snapshot`:
  - Update local round/phase, trump, bids, tricks, scores.
  - Replace local hand with provided cards; update remaining hand sizes for others.
  - If a turn is pending for this client (bid_turn/play_turn), re-enable UI using valid_cards from snapshot if provided.
  - Clear stale UI (trick area, status text) then render current_trick, trump, bids, trick counts, and scores.

### Minimal data structures
```
{
  "type": "state_sync_snapshot",
  "round_number": 2,
  "phase": "playing",
  "player_order": ["p1","p2","p3","p4"],
  "current_player_id": "p3",
  "trump_suit": "Spades",
  "trump_chooser_id": "p2",
  "bids": {"p1":3,"p2":2,"p3":3,"p4":2},
  "tricks_won_count": {"p1":1,"p2":0,"p3":1,"p4":0},
  "current_trick": [["p3","7H"],["p4","9H"]],
  "hands": {"self": ["AS","KD", "..."], "others": {"p1":6,"p2":5,"p4":6}},
  "scores": {"round": {"p1":1.0}, "total": {"p1":12.0}}
}
```

### Edge cases
- If reconnect during bidding: include current_bidder and bids_so_far; if bidder is requester, resend `bid_turn` after snapshot.
- If reconnect during trump selection: resend `trump_request` to chooser after snapshot.
- If reconnect during trick: include valid_cards if requester is current_player.
- If phase is ROUND_END/GAME_END: send latest round_end/game_end and push client to score/final screen.

### Next steps
- Add MessageType entries for `state_sync_request`, `state_sync_snapshot`, `player_rejoin`.
- Implement server snapshot generator (WiFi) pulling from game_state and in-flight trick/bid state.
- Implement client handler to hydrate UI/game_state from snapshot.
