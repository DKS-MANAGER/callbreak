from kivy.animation import Animation
from kivy.uix.button import Button


class AnimatedButton(Button):
    """Button with simple press/release scale feedback."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._orig_scale = 1.0

    def on_press(self):
        Animation.cancel_all(self)
        anim = Animation(scale=0.95, duration=0.1, transition="out_quad")
        anim.start(self)
        return super().on_press()

    def on_release(self):
        Animation.cancel_all(self)
        anim = Animation(scale=1.0, duration=0.1, transition="out_quad")
        anim.start(self)
        return super().on_release()
