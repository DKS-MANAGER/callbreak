"""
Game Screen - Main gameplay UI inspired by top Callbreak mobile layouts.
"""

import math
import random
from math import cos, pi, sin

from kivy.app import App
from kivy.animation import Animation
from kivy.clock import Clock
from kivy.graphics import Color, Rectangle, RoundedRectangle
from kivy.properties import BooleanProperty, DictProperty, ListProperty, NumericProperty, StringProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.label import Label
from kivy.uix.scrollview import ScrollView
from kivy.uix.togglebutton import ToggleButton

from ui.theme.colors import GameColors
from ui.widgets.animated_button import AnimatedButton
from ui.widgets.card_widget import CardWidget
from ui.widgets.player_widget import PlayerWidget
from ui.widgets.trick_display import TrickDisplay
from utils.asset_manager import asset_manager


class GameScreen(FloatLayout):
    """Main game screen with circular player ring, trick area, and hand."""

    players = ListProperty()
    hand_cards = ListProperty()
    current_trick = ListProperty()
    round_number = NumericProperty(1)
    total_rounds = NumericProperty(5)
    connection = StringProperty("wifi")
    score = NumericProperty(0.0)
    status = StringProperty("Waiting for host...")
    can_play_cards = BooleanProperty(False)
    player_widgets_map = DictProperty({})
    trump_suit = StringProperty("")

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.player_widgets = []
        self.trick_display = TrickDisplay()
        self.trick_cards_widgets = []
        self.cards_in_hand = []

        with self.canvas.before:
            Color(*GameColors.PRIMARY_BG)
            self.bg_rect = Rectangle()
            Color(*GameColors.SECONDARY_BG)
            self.bg_overlay = Rectangle()

        self._build_layout()
        self.bind(size=self._on_resize)

    # ---------- Layout construction ----------

    def _build_layout(self):
        # Top bar
        top_bar = BoxLayout(size_hint=(1, 0.1), padding=[16, 8], spacing=12)
        self.round_label = Label(text=self._round_text(), font_size="16sp", bold=True, color=(1, 1, 1, 0.9))
        self.score_label = Label(text=self._score_text(), font_size="18sp", bold=True, color=(0.99, 0.84, 0.0, 1))
        self.connection_label = Label(text=self._connection_text(), font_size="14sp", color=(0.75, 0.87, 0.93, 1))
        self.trump_label = Label(text="Trump: -", font_size="14sp", color=(0.95, 0.95, 0.95, 0.9))
        menu_button = AnimatedButton(text="⋯", size_hint=(None, None), size=(54, 42), background_color=(0.16, 0.32, 0.18, 1))
        top_bar.add_widget(self.round_label)
        top_bar.add_widget(self.score_label)
        top_bar.add_widget(self.connection_label)
        top_bar.add_widget(self.trump_label)
        top_bar.add_widget(menu_button)
        self.add_widget(top_bar)

        # Center table area
        self.table_layer = FloatLayout(size_hint=(1, 0.62), pos_hint={"x": 0, "y": 0.28})
        self.table_layer.add_widget(self.trick_display)
        self.add_widget(self.table_layer)

        # Status message ribbon
        self.status_label = Label(
            text=self.status,
            size_hint=(None, None),
            size=(320, 36),
            pos_hint={"center_x": 0.5, "y": 0.23},
            color=(0.95, 0.95, 0.95, 1),
            bold=True,
        )
        self.add_widget(self.status_label)

        # Hand area
        hand_container = BoxLayout(orientation="vertical", size_hint=(1, 0.28), padding=[12, 6], spacing=6)
        controls = BoxLayout(size_hint=(1, None), height=42, spacing=8, padding=[0, 4])
        controls.add_widget(Label(text="Your hand", bold=True, color=(1, 1, 1, 0.9)))
        controls.add_widget(ToggleButton(text="Sort: Suit", group="sort", state="down", size_hint=(None, None), size=(110, 36)))
        controls.add_widget(ToggleButton(text="Sort: Rank", group="sort", size_hint=(None, None), size=(110, 36)))
        controls.add_widget(Label(text="", size_hint=(1, 1)))
        hand_container.add_widget(controls)

        self.hand_scroll = ScrollView(size_hint=(1, 1), bar_width=6, scroll_type=["bars", "content"])
        self.hand_row = BoxLayout(size_hint_y=None, height=150, spacing=8, padding=[6, 0])
        self.hand_row.size_hint_x = None
        self.hand_scroll.add_widget(self.hand_row)
        hand_container.add_widget(self.hand_scroll)
        self.add_widget(hand_container)

    # ---------- Public setters ----------

    def set_players(self, players):
        self.players = players or []
        Clock.schedule_once(lambda *_: self._layout_players(), 0)

    def set_hand_cards(self, cards):
        self.hand_cards = cards or []
        self._refresh_hand()

    def set_trick(self, trick_cards):
        self.current_trick = trick_cards or []
        self.trick_display.set_trick(self.current_trick)

    def on_enter(self, *args):
        bg = asset_manager.get_background("table")
        if bg:
            self.bg_rect.texture = bg.texture

    # ---------- Internal helpers ----------

    def _on_resize(self, *args):
        self.bg_rect.pos = self.pos
        self.bg_rect.size = self.size
        self.bg_overlay.pos = self.pos
        self.bg_overlay.size = self.size
        self._layout_players()

    def _layout_players(self):
        # Remove existing player widgets
        for widget in self.player_widgets:
            if widget.parent:
                self.table_layer.remove_widget(widget)
        self.player_widgets.clear()
        self.player_widgets_map = {}

        if not self.players:
            return

        if self.table_layer.width <= 0 or self.table_layer.height <= 0:
            return
        total = len(self.players)
        center_x = self.table_layer.width / 2
        center_y = self.table_layer.height / 2
        radius = min(self.table_layer.width, self.table_layer.height) * (0.42 if total <= 6 else 0.36)

        for idx, pdata in enumerate(self.players):
            angle = (2 * pi / total) * idx - pi / 2
            x = center_x + radius * cos(angle)
            y = center_y + radius * sin(angle)
            widget = PlayerWidget(pdata)
            widget.pos = (x - widget.width / 2, y - widget.height / 2)
            self.table_layer.add_widget(widget)
            self.player_widgets.append(widget)
            pid = pdata.get("id") or pdata.get("player_id") or pdata.get("name")
            if pid:
                self.player_widgets_map[pid] = widget

        # Center trick display
        self.trick_display.pos = (
            center_x - self.trick_display.width / 2,
            center_y - self.trick_display.height / 2,
        )

    def _refresh_hand(self):
        self.hand_row.clear_widgets()
        self.cards_in_hand = self.hand_cards[:]
        for code in self.hand_cards:
            card = CardWidget(code)
            card.bind(on_release=lambda inst, *_: self.card_clicked(inst))
            self.hand_row.add_widget(card)
        # Stretch row width for scrolling
        total_width = len(self.hand_cards) * 98
        self.hand_row.width = max(total_width, self.width)

    def _round_text(self):
        return f"Round {self.round_number} / {self.total_rounds}"

    def _score_text(self):
        return f"Score: {self.score:+.1f}"

    def _connection_text(self):
        return "WiFi connected"

    def refresh_header(self):
        self.round_label.text = self._round_text()
        self.score_label.text = self._score_text()
        self.connection_label.text = self._connection_text()
        self.status_label.text = self.status
    
    def show_notification(self, text: str, duration: float = 2.0):
        self.status = text
        self.refresh_header()
        Clock.schedule_once(lambda *_: self._clear_notification(text), duration)

    def _clear_notification(self, text):
        if self.status == text:
            self.status = ""
            self.refresh_header()

    # ---------- Gameplay helpers ----------

    def display_hand(self, cards_data):
        # Accept list of strings or dicts with suit/rank
        parsed = []
        for item in cards_data or []:
            if isinstance(item, str):
                parsed.append(item)
            elif isinstance(item, dict):
                rank = item.get("rank")
                suit = item.get("suit")
                if rank and suit:
                    parsed.append(f"{rank}{suit[0].upper()}")
        self.set_hand_cards(parsed)

    def show_trump_waiting(self, chooser_name: str):
        self.status = f"Waiting for {chooser_name} to pick trump" if chooser_name else "Waiting for trump"
        self.refresh_header()

    def show_trump_announcement(self, trump_suit: str, announcement_text: str, duration: float = 3.0):
        """Full-screen trump announcement overlay with animated card and symbol."""
        overlay = FloatLayout()
        overlay.opacity = 0

        # Darken background
        with overlay.canvas.before:
            Color(0, 0, 0, 0.9)
            self.overlay_bg = Rectangle(pos=overlay.pos, size=overlay.size)
        overlay.bind(pos=self._update_overlay_bg, size=self._update_overlay_bg)

        # Announcement card
        card = BoxLayout(
            orientation="vertical",
            size_hint=(0.85, 0.5),
            pos_hint={"center_x": 0.5, "center_y": 0.5},
            padding=30,
            spacing=20,
        )
        with card.canvas.before:
            Color(0.15, 0.15, 0.15, 1)
            self.card_bg = RoundedRectangle(pos=card.pos, size=card.size, radius=[16])
        card.bind(pos=self._update_card_bg, size=self._update_card_bg)

        suit_symbols = {"Spades": "♠", "Hearts": "♥", "Diamonds": "♦", "Clubs": "♣"}
        suit_colors = {
            "Spades": (0.5, 0.2, 1, 1),
            "Hearts": (1, 0.2, 0.2, 1),
            "Diamonds": (1, 0.6, 0, 1),
            "Clubs": (0.2, 1, 0.2, 1),
        }

        symbol = Label(
            text=suit_symbols.get(trump_suit, ""),
            font_size="140sp",
            color=suit_colors.get(trump_suit, (1, 1, 1, 1)),
            size_hint_y=0.6,
        )

        text_label = Label(
            text=announcement_text,
            font_size="22sp",
            bold=True,
            color=(1, 1, 1, 1),
            size_hint_y=0.25,
            halign="center",
            valign="middle",
        )
        text_label.bind(size=text_label.setter("text_size"))

        trump_label = Label(
            text=f"TRUMP: {trump_suit.upper()}",
            font_size="18sp",
            color=suit_colors.get(trump_suit, (1, 1, 1, 1)),
            size_hint_y=0.15,
        )

        card.add_widget(symbol)
        card.add_widget(text_label)
        card.add_widget(trump_label)
        overlay.add_widget(card)
        self.add_widget(overlay)

        # Animations
        Animation(opacity=1, duration=0.4, transition="out_quad").start(overlay)

        symbol.opacity = 0
        symbol.scale = 0
        anim_symbol = Animation(opacity=1, duration=0.3) & Animation(
            scale=1.3, duration=0.6, transition="out_elastic"
        )
        Clock.schedule_once(lambda *_: anim_symbol.start(symbol), 0.2)

        text_label.opacity = 0
        text_label.y = text_label.y - 50
        anim_text = Animation(opacity=1, duration=0.4, transition="out_quad") & Animation(
            y=text_label.y + 50, duration=0.4, transition="out_quad"
        )
        Clock.schedule_once(lambda *_: anim_text.start(text_label), 0.4)

        def pulse_symbol(_dt):
            pulse = Animation(opacity=0.7, duration=0.8, transition="in_out_sine") + Animation(
                opacity=1.0, duration=0.8, transition="in_out_sine"
            )
            pulse.repeat = True
            pulse.start(symbol)

        Clock.schedule_once(pulse_symbol, 0.8)

        def dismiss(_dt):
            anim_out = Animation(opacity=0, duration=0.5, transition="in_quad")
            anim_out.bind(on_complete=lambda *_: self.remove_widget(overlay))
            anim_out.start(overlay)

        Clock.schedule_once(dismiss, duration)
        self.update_trump_indicator(trump_suit)
        self.refresh_header()

    def _update_overlay_bg(self, instance, _value):
        if hasattr(self, "overlay_bg"):
            self.overlay_bg.pos = instance.pos
            self.overlay_bg.size = instance.size

    def _update_card_bg(self, instance, _value):
        if hasattr(self, "card_bg"):
            self.card_bg.pos = instance.pos
            self.card_bg.size = instance.size

    def update_trump_indicator(self, trump_suit: str):
        self.trump_suit = trump_suit or ""
        self.trump_label.text = f"Trump: {trump_suit or '-'}"
        suit_colors = {
            "Spades": (0, 0, 0, 1),
            "Hearts": (0.9, 0.2, 0.2, 1),
            "Diamonds": (0.9, 0.5, 0.1, 1),
            "Clubs": (0.1, 0.5, 0.1, 1),
        }
        self.trump_label.color = suit_colors.get(trump_suit, (0.95, 0.95, 0.95, 0.9))
        self.update_hand_trump_glows(trump_suit)

    def update_hand_trump_glows(self, trump_suit: str):
        for widget in self.hand_row.children:
            if isinstance(widget, CardWidget):
                widget.update_trump_glow(
                    is_trump=bool(trump_suit) and widget.card_code.endswith(trump_suit[:1]),
                    trump_suit=trump_suit,
                )

    def show_bidding_waiting(self, player_id: str):
        self.status = f"Waiting for {player_id} to bid"
        self.refresh_header()

    def show_bidding_status(self, current_bidder: str, bids_so_far: int, total_players: int):
        self.status = f"{current_bidder} is bidding ({bids_so_far}/{total_players})" if current_bidder else "Bidding in progress"
        self.refresh_header()

    def start_playing_phase(self, all_bids):
        # Update bids on player widgets if ids are known
        if all_bids:
            for pid, bid in all_bids.items():
                self.update_player_bid(pid, bid)
        self.status = "Playing phase"
        self.refresh_header()

    def enable_card_play(self, valid_cards=None):
        self.can_play_cards = True
        valid_set = set(valid_cards or [])
        for widget in self.hand_row.children:
            if isinstance(widget, CardWidget):
                widget.playable = not valid_set or widget.card_code in valid_set
        self.status = "Your turn"
        self.refresh_header()

    def show_play_waiting(self, player_id: str):
        self.can_play_cards = False
        for widget in self.hand_row.children:
            if isinstance(widget, CardWidget):
                widget.playable = False
        self.status = f"Waiting for {player_id}"
        self.refresh_header()

    def show_playing_status(self, current_player: str, trick_size: int):
        self.can_play_cards = False
        for widget in self.hand_row.children:
            if isinstance(widget, CardWidget):
                widget.playable = False
        self.status = f"Waiting for {current_player}" if current_player else "Playing phase"
        if trick_size:
            self.status += f" • Trick cards: {trick_size}"
        self.refresh_header()

    def card_clicked(self, card_widget: CardWidget):
        if not self.can_play_cards:
            return
        card_code = card_widget.card_code
        app = App.get_running_app()
        if app:
            if app.network_client:
                app.network_client.send_card_play(card_code)
            elif app.network_server:
                app.network_server.handle_card_play(app.player_id, card_code)
        self.can_play_cards = False

    def animate_card_to_table(self, player_id, card_str, all_trick_cards):
        """Smooth card animation from player to table center with arc and bounce."""
        card_widget = CardWidget(card_str, size=(100, 150))
        start_x, start_y = self.get_player_position(player_id)
        card_widget.pos = (start_x, start_y)

        num_cards = len(all_trick_cards)
        angle = (360 / max(4, num_cards or 1)) * (num_cards - 1)
        center_x, center_y = self.width / 2, self.height / 2
        radius = 80
        end_x = center_x + radius * math.cos(math.radians(angle)) - 50
        end_y = center_y + radius * math.sin(math.radians(angle)) - 75

        self.table_layer.add_widget(card_widget)
        self.trick_cards_widgets.append(card_widget)

        anim = Animation(
            x=end_x,
            y=end_y,
            rotation=random.randint(-8, 8),
            duration=0.5,
            transition="out_quad",
        )
        anim.bind(on_complete=lambda *_: self._bounce_card(card_widget))
        anim.start(card_widget)

        self.trick_display.set_trick([
            {"card_code": card, "player_name": pid} for pid, card in all_trick_cards
        ])

    def _bounce_card(self, card_widget):
        bounce = Animation(scale=1.1, duration=0.1, transition="out_quad") + Animation(
            scale=1.0, duration=0.1, transition="in_quad"
        )
        bounce.start(card_widget)

    def animate_trick_win(self, winner_id, cards, tricks_count):
        winner_pos = self.get_player_position(winner_id)
        winner_widget = self.player_widgets_map.get(winner_id)
        if winner_widget:
            flash = Animation(opacity=0.3, duration=0.15) + Animation(opacity=1.0, duration=0.15)
            flash.repeat = 2
            flash.start(winner_widget)

        for idx, widget in enumerate(list(self.trick_cards_widgets)):
            delay = idx * 0.1

            def animate_to_winner(_dt, cw=widget):
                anim = Animation(
                    x=winner_pos[0],
                    y=winner_pos[1],
                    scale=0.5,
                    opacity=0.6,
                    duration=0.6,
                    transition="in_quad",
                )
                anim.bind(on_complete=lambda *_: self.table_layer.remove_widget(cw))
                anim.start(cw)

            Clock.schedule_once(animate_to_winner, delay)

        self.trick_cards_widgets.clear()
        Clock.schedule_once(lambda *_: self.trick_display.set_trick([]), 0.7)

        def show_plus_one(_dt):
            popup = Label(
                text="+1",
                font_size="32sp",
                color=(0, 1, 0, 1),
                pos=winner_pos,
                size_hint=(None, None),
                size=(60, 60),
            )
            self.add_widget(popup)
            anim = Animation(y=popup.y + 50, opacity=0, duration=1.0, transition="out_quad")
            anim.bind(on_complete=lambda *_: self.remove_widget(popup))
            anim.start(popup)

        Clock.schedule_once(show_plus_one, 0.8)
        self.update_all_trick_counts(tricks_count)

    def update_trump_indicator_from_state(self):
        app = App.get_running_app()
        if app and app.game_state:
            self.update_trump_indicator(app.game_state.current_trump_suit or "")

    def update_player_bid(self, player_id, bid_amount):
        widget = self.player_widgets_map.get(player_id)
        if widget:
            widget.bid = bid_amount
            widget.data["bid"] = bid_amount

    def update_all_trick_counts(self, tricks_count):
        for pid, count in (tricks_count or {}).items():
            widget = self.player_widgets_map.get(pid)
            if widget:
                widget.tricks = count

    def calculate_trick_card_position(self, index: int):
        center_x = self.table_layer.width / 2
        center_y = self.table_layer.height / 2
        offset = 20 * index
        return (center_x - 40 + offset, center_y - 60)

    def get_player_position(self, player_id):
        widget = self.player_widgets_map.get(player_id)
        if widget:
            return widget.pos
        return (self.width / 2, self.height / 2)

    # ---------- Waiting overlays ----------

    def show_waiting_overlay(self, message: str, show_spinner: bool = True):
        overlay = FloatLayout()
        overlay.opacity = 0

        with overlay.canvas.before:
            Color(0, 0, 0, 0.7)
            self.wait_bg = Rectangle(pos=overlay.pos, size=overlay.size)
        overlay.bind(pos=lambda *_: setattr(self.wait_bg, "pos", overlay.pos))
        overlay.bind(size=lambda *_: setattr(self.wait_bg, "size", overlay.size))

        content = BoxLayout(
            orientation="vertical",
            size_hint=(0.6, 0.3),
            pos_hint={"center_x": 0.5, "center_y": 0.5},
            spacing=20,
        )

        if show_spinner:
            spinner = Label(text="", font_size="40sp", size_hint_y=0.4)
            content.add_widget(spinner)

            def animate_dots(_dt):
                current = spinner.text
                spinner.text = "" if len(current) >= 3 else current + "●"

            Clock.schedule_interval(animate_dots, 0.5)

        msg_label = Label(
            text=message,
            font_size="18sp",
            color=(1, 1, 1, 1),
            halign="center",
            valign="middle",
        )
        msg_label.bind(size=msg_label.setter("text_size"))
        content.add_widget(msg_label)

        overlay.add_widget(content)
        self.add_widget(overlay)
        Animation(opacity=1, duration=0.3).start(overlay)
        self.waiting_overlay = overlay
        return overlay

    def hide_waiting_overlay(self):
        if hasattr(self, "waiting_overlay") and self.waiting_overlay:
            anim = Animation(opacity=0, duration=0.3)
            anim.bind(on_complete=lambda *_: self.remove_widget(self.waiting_overlay))
            anim.start(self.waiting_overlay)
