"""
Unit tests for networking components.

Run with: pytest tests/test_networking.py
"""

import pytest
from networking.message_handler import MessageHandler, MessageType


def test_trick_won_payload_keys():
    msg = MessageHandler.create_trick_won(
        winner_id='p1',
        cards=[('p1', 'AS'), ('p2', 'KH')],
        tricks_won_count={'p1': 1, 'p2': 0}
    )
    assert msg['type'] == MessageType.TRICK_WON
    assert msg['tricks_won_count'] == {'p1': 1, 'p2': 0}
    assert msg['cards'] == [('p1', 'AS'), ('p2', 'KH')]


def test_round_end_payload_shape():
    msg = MessageHandler.create_round_end(
        scores={'p1': 5.0},
        total_scores={'p1': 5.0},
        tricks_won={'p1': 5}
    )
    assert msg['type'] == MessageType.ROUND_END
    assert msg['scores']['p1'] == 5.0
    assert msg['total_scores']['p1'] == 5.0
    assert msg['tricks_won']['p1'] == 5


def test_game_end_payload_shape():
    msg = MessageHandler.create_game_end(
        final_scores={'p1': 25.0},
        winner='p1',
        all_round_scores=[{'round': 1, 'scores': {'p1': 5.0}}]
    )
    assert msg['type'] == MessageType.GAME_END
    assert msg['winner'] == 'p1'
    assert msg['final_scores']['p1'] == 25.0
    assert msg['all_round_scores'][0]['round'] == 1


class TestMessageHandler:
    """Test message encoding/decoding."""
    
    def test_encode_decode(self):
        """Test encoding and decoding a message."""
        message = {
            'type': MessageType.PLAYER_JOIN,
            'player_id': 'id123',
            'player_name': 'John'
        }
        
        # Encode
        data = MessageHandler.encode(message)
        assert isinstance(data, bytes)
        
        # Decode
        decoded = MessageHandler.decode(data)
        assert decoded['type'] == MessageType.PLAYER_JOIN
        assert decoded['player_id'] == 'id123'
        assert decoded['player_name'] == 'John'
    
    def test_create_player_join(self):
        """Test creating player join message."""
        message = MessageHandler.create_player_join('id123', 'John')
        
        assert message['type'] == MessageType.PLAYER_JOIN
        assert message['player_id'] == 'id123'
        assert message['player_name'] == 'John'
        assert 'timestamp' in message
    
    def test_create_bid_made(self):
        """Test creating bid message."""
        message = MessageHandler.create_bid_made('id123', 5)
        
        assert message['type'] == MessageType.BID_MADE
        assert message['player_id'] == 'id123'
        assert message['amount'] == 5
    
    def test_create_error(self):
        """Test creating error message."""
        message = MessageHandler.create_error('Test error', 'TEST_ERROR')
        
        assert message['type'] == MessageType.ERROR
        assert message['message'] == 'Test error'
        assert message['error_code'] == 'TEST_ERROR'


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
