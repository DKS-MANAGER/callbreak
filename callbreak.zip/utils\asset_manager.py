import os

from kivy.core.image import Image as CoreImage


class AssetManager:
    """Loads and caches card and UI assets."""

    def __init__(self):
        self.card_images = {}
        self.backgrounds = {}
        self.ui_elements = {}
        self.loaded = False

    def load_all_assets(self):
        if self.loaded:
            return
        suits = ["S", "H", "D", "C"]
        ranks = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"]
        for suit in suits:
            for rank in ranks:
                code = f"{rank}{suit}"
                path = os.path.join("assets", "cards", f"{code}.png")
                if os.path.exists(path):
                    self.card_images[code] = CoreImage(path)
        back_path = os.path.join("assets", "cards", "card_back.png")
        if os.path.exists(back_path):
            self.card_images["back"] = CoreImage(back_path)
        table_path = os.path.join("assets", "backgrounds", "table_green.png")
        if os.path.exists(table_path):
            self.backgrounds["table"] = CoreImage(table_path)
        lobby_path = os.path.join("assets", "backgrounds", "lobby_bg.png")
        if os.path.exists(lobby_path):
            self.backgrounds["lobby"] = CoreImage(lobby_path)
        trump_dir = os.path.join("assets", "ui", "trump_icons")
        for name in ["spade", "heart", "diamond", "club"]:
            candidate = os.path.join(trump_dir, f"{name}.png")
            if os.path.exists(candidate):
                self.ui_elements[f"trump_{name}"] = CoreImage(candidate)
        self.loaded = True

    def get_card_image(self, code: str):
        if not self.loaded:
            self.load_all_assets()
        return self.card_images.get(code, self.card_images.get("back"))

    def get_background(self, name: str):
        if not self.loaded:
            self.load_all_assets()
        return self.backgrounds.get(name)


asset_manager = AssetManager()
