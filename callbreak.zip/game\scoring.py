"""
Scoring logic for Call Break game.

Handles score calculation and round/game scoring.
"""

from typing import Dict, List
from .player import Player


def calculate_score(player: Player) -> float:
    """
    Calculate and update player's score for current round.
    
    Scoring Rules:
    - Exact match: Win exactly bid amount = +bid points
    - Over-trick: Win more than bid = +bid + 0.1 per extra trick
    - Under-trick (PENALTY): Win fewer than bid = -bid points
    
    Args:
        player: Player to calculate score for
        
    Returns:
        Score for this round
        
    Examples:
        Bid 5, Win 5 → +5.0
        Bid 3, Win 6 → +3.3 (3 + 0.3 for 3 extra)
        Bid 4, Win 2 → -4.0 (penalty)
    """
    return player.calculate_score()


def calculate_round_scores(players: List[Player]) -> Dict[str, float]:
    """
    Calculate scores for all players at end of round.
    
    Args:
        players: List of all players
        
    Returns:
        Dictionary mapping player_id to round score
    """
    scores = {}
    for player in players:
        score = calculate_score(player)
        scores[player.player_id] = score
    
    return scores


def get_total_scores(players: List[Player]) -> Dict[str, float]:
    """
    Get cumulative total scores for all players.
    
    Args:
        players: List of all players
        
    Returns:
        Dictionary mapping player_id to total score
    """
    return {player.player_id: player.total_score for player in players}


def get_tricks_won(players: List[Player]) -> Dict[str, int]:
    """
    Get tricks won count for all players in current round.
    
    Args:
        players: List of all players
        
    Returns:
        Dictionary mapping player_id to tricks won
    """
    return {player.player_id: player.tricks_won_this_round for player in players}


def get_all_bids(players: List[Player]) -> Dict[str, int]:
    """
    Get bids for all players in current round.
    
    Args:
        players: List of all players
        
    Returns:
        Dictionary mapping player_id to bid amount
    """
    return {player.player_id: player.current_bid for player in players}


def get_game_winner(players: List[Player]) -> Player:
    """
    Determine game winner (player with highest total score).
    
    Args:
        players: List of all players
        
    Returns:
        Player with highest total score
    """
    return max(players, key=lambda p: p.total_score)


def get_leaderboard(players: List[Player]) -> List[Dict]:
    """
    Get sorted leaderboard of players.
    
    Args:
        players: List of all players
        
    Returns:
        List of player dictionaries sorted by total score (highest first)
    """
    sorted_players = sorted(players, key=lambda p: p.total_score, reverse=True)
    
    leaderboard = []
    for rank, player in enumerate(sorted_players, 1):
        leaderboard.append({
            'rank': rank,
            'player_id': player.player_id,
            'name': player.name,
            'total_score': player.total_score,
            'round_scores': player.round_scores
        })
    
    return leaderboard


def format_score(score: float) -> str:
    """
    Format score for display.
    
    Args:
        score: Numeric score
        
    Returns:
        Formatted string with sign
        
    Examples:
        >>> format_score(5.0)
        '+5.0'
        >>> format_score(-4.0)
        '-4.0'
        >>> format_score(3.3)
        '+3.3'
    """
    if score >= 0:
        return f"+{score:.1f}"
    return f"{score:.1f}"


def get_score_summary(player: Player) -> str:
    """
    Get human-readable score summary for player.
    
    Args:
        player: Player to summarize
        
    Returns:
        Summary string
        
    Example:
        "John: Bid 5, Won 5 → +5.0 (Total: 12.3)"
    """
    status = "✓" if player.tricks_won_this_round == player.current_bid else "✗"
    
    return (f"{player.name} {status}: "
            f"Bid {player.current_bid}, Won {player.tricks_won_this_round} → "
            f"{format_score(player.score_this_round)} "
            f"(Total: {player.total_score:.1f})")
