"""
Connection Manager for handling disconnections and reconnections.
"""

import threading
import time
from typing import Dict, Callable, Optional


class ConnectionManager:
    """
    Manages client connections, disconnections, and reconnections.
    
    Attributes:
        connections: Dictionary of active connections
        disconnect_callback: Callback when client disconnects
        reconnect_timeout: Seconds to wait for reconnection
    """
    
    def __init__(self, disconnect_callback: Optional[Callable] = None,
                 reconnect_timeout: int = 30):
        """
        Initialize connection manager.
        
        Args:
            disconnect_callback: Function to call on disconnect
            reconnect_timeout: Seconds before considering disconnect permanent
        """
        self.connections: Dict[str, Dict] = {}
        self.disconnect_callback = disconnect_callback
        self.reconnect_timeout = reconnect_timeout
        self.lock = threading.Lock()
    
    def add_connection(self, player_id: str, connection: any, 
                      player_name: str = ''):
        """
        Add a new connection.
        
        Args:
            player_id: Unique player identifier
            connection: Socket or connection object
            player_name: Player's display name
        """
        with self.lock:
            self.connections[player_id] = {
                'connection': connection,
                'name': player_name,
                'connected': True,
                'last_seen': time.time(),
                'disconnect_time': None
            }
    
    def remove_connection(self, player_id: str):
        """Remove a connection."""
        with self.lock:
            if player_id in self.connections:
                del self.connections[player_id]
    
    def mark_disconnected(self, player_id: str):
        """
        Mark a player as disconnected but keep in connection pool.
        
        Args:
            player_id: Player who disconnected
        """
        with self.lock:
            if player_id in self.connections:
                self.connections[player_id]['connected'] = False
                self.connections[player_id]['disconnect_time'] = time.time()
                
                # Call disconnect callback
                if self.disconnect_callback:
                    self.disconnect_callback(player_id)
    
    def mark_reconnected(self, player_id: str, connection: any):
        """
        Mark a player as reconnected.
        
        Args:
            player_id: Player who reconnected
            connection: New connection object
        """
        with self.lock:
            if player_id in self.connections:
                self.connections[player_id]['connection'] = connection
                self.connections[player_id]['connected'] = True
                self.connections[player_id]['last_seen'] = time.time()
                self.connections[player_id]['disconnect_time'] = None
    
    def is_connected(self, player_id: str) -> bool:
        """Check if player is connected."""
        with self.lock:
            if player_id in self.connections:
                return self.connections[player_id]['connected']
        return False
    
    def get_connection(self, player_id: str) -> Optional[any]:
        """Get connection object for player."""
        with self.lock:
            if player_id in self.connections and \
               self.connections[player_id]['connected']:
                return self.connections[player_id]['connection']
        return None
    
    def get_all_connected(self) -> Dict[str, any]:
        """Get all connected players."""
        with self.lock:
            return {
                pid: info['connection'] 
                for pid, info in self.connections.items()
                if info['connected']
            }
    
    def get_disconnected_players(self) -> list:
        """Get list of disconnected player IDs."""
        with self.lock:
            return [
                pid for pid, info in self.connections.items()
                if not info['connected']
            ]
    
    def check_timeouts(self) -> list:
        """
        Check for disconnections that have exceeded timeout.
        
        Returns:
            List of player IDs to permanently remove
        """
        current_time = time.time()
        to_remove = []
        
        with self.lock:
            for player_id, info in self.connections.items():
                if not info['connected'] and info['disconnect_time']:
                    if current_time - info['disconnect_time'] > self.reconnect_timeout:
                        to_remove.append(player_id)
        
        return to_remove
    
    def update_last_seen(self, player_id: str):
        """Update last seen timestamp for player."""
        with self.lock:
            if player_id in self.connections:
                self.connections[player_id]['last_seen'] = time.time()
    
    def close_all(self):
        """Close all connections."""
        with self.lock:
            for info in self.connections.values():
                try:
                    conn = info['connection']
                    if hasattr(conn, 'close'):
                        conn.close()
                except Exception:
                    pass
            self.connections.clear()
