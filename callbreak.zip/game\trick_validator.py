"""
Trick validation logic for Call Break game.

Validates card plays according to game rules and determines trick winners.
"""

from typing import List, Tuple, Optional
from .card import Card
from .player import Player


def validate_card_play(
    player: Player,
    card: Card,
    current_trick: List[Tuple[str, Card]],
    led_suit: Optional[str],
    trump_suit: Optional[str]
) -> Tuple[bool, str]:
    """
    Validate if a player can legally play a card according to Call Break rules.
    
     Rules:
     1. Must Follow Suit: If you have the led suit, you MUST play it
     2. Trump When Can't Follow: If you can't follow suit, MUST play trump suit if available
     3. Higher Trump Required: If trump already played and you can't follow suit,
         must play higher trump if possible
     4. Discard: If can't follow suit and no trump, play any card
    
    Args:
        player: Player attempting to play
        card: Card player wants to play
        current_trick: List of (player_id, Card) tuples already played
        led_suit: Suit of the first card played (None if leading)
        
    Returns:
        Tuple of (is_valid, reason)
        
    Examples:
        >>> # Player has Hearts, Hearts was led - must follow
        >>> validate_card_play(player, Card('Diamonds', '5'), [...], 'Hearts', 'Spades')
        (False, "Must follow suit Hearts")
        
        >>> # Player has no Hearts, but has Spades - must play trump
        >>> validate_card_play(player, Card('Diamonds', 'K'), [...], 'Hearts', 'Spades')
        (False, "Must play trump (Spades) when cannot follow suit")
        
        >>> # Player has no Hearts, no Spades - can play anything
        >>> validate_card_play(player, Card('Diamonds', 'K'), [...], 'Hearts', 'Spades')
        (True, "Valid discard")
    """
    # Check if card is in player's hand
    if card not in player.hand:
        return False, "Card not in hand"
    
    # If leading the trick (first card), any card is valid
    if not current_trick or led_suit is None:
        return True, "Valid lead"
    
    # Rule 1: Must follow suit if possible
    has_led_suit = player.has_suit(led_suit)
    if has_led_suit:
        if card.suit != led_suit:
            return False, f"Must follow suit {led_suit}"
        return True, "Valid follow suit"
    
    # Player cannot follow suit
    has_trump = player.has_trump(trump_suit) if trump_suit else False
    
    # Rule 2: Must play trump if available when can't follow suit
    if has_trump and card.suit != trump_suit:
        return False, f"Must play trump ({trump_suit}) when cannot follow suit"
    
    # Rule 3: If trump already played, must play higher trump if possible
    if trump_suit and card.suit == trump_suit:
        # Check if any trump already played in this trick
        trump_cards_played = [c for _, c in current_trick if c.suit == trump_suit]
        
        if trump_cards_played:
            highest_trump_played = max(trump_cards_played, key=lambda c: c.value)
            player_trump_cards = player.get_trump_cards(trump_suit)
            
            # Check if player has any trump higher than highest played
            has_higher_trump = any(c.value > highest_trump_played.value 
                                   for c in player_trump_cards)
            
            if has_higher_trump and card.value <= highest_trump_played.value:
                return False, "Must play higher trump if available"
        
        return True, "Valid trump play"
    
    # Rule 4: No led suit, no trump - can discard any card
    return True, "Valid discard"


def get_valid_cards(
    player: Player,
    current_trick: List[Tuple[str, Card]],
    led_suit: Optional[str],
    trump_suit: Optional[str]
) -> List[Card]:
    """
    Get list of cards player can legally play.
    
    Args:
        player: Player whose turn it is
        current_trick: Cards already played in trick
        led_suit: Suit that was led (None if leading)
        
    Returns:
        List of valid cards player can play
        
    Example:
        >>> valid = get_valid_cards(player, current_trick, 'Hearts')
        >>> # Returns all Hearts if player has them,
        >>> # else all Spades if player has them,
        >>> # else all cards
    """
    if not current_trick or led_suit is None:
        # Leading - can play any card
        return player.hand.copy()
    
    # Must follow suit if possible
    led_suit_cards = player.get_cards_of_suit(led_suit)
    if led_suit_cards:
        return led_suit_cards
    
    # Can't follow suit - must play trump if available
    trump_cards = player.get_trump_cards(trump_suit) if trump_suit else []
    if trump_cards:
        # Check if must play higher trump
        trump_cards_played = [c for _, c in current_trick if trump_suit and c.suit == trump_suit]
        
        if trump_cards_played:
            highest_trump_played = max(trump_cards_played, key=lambda c: c.value)
            higher_trumps = [c for c in trump_cards 
                            if c.value > highest_trump_played.value]
            
            if higher_trumps:
                return higher_trumps
        
        return trump_cards
    
    # No led suit, no trump - can play any card
    return player.hand.copy()


def determine_trick_winner(
    trick: List[Tuple[str, Card]],
    led_suit: str,
    trump_suit: Optional[str]
) -> Tuple[int, str]:
    """
    Determine which player won the trick.
    
    Rules:
    1. Highest trump (Spade) wins if any trump played
    2. If no trump, highest card of led suit wins
    
    Args:
        trick: List of (player_id, Card) tuples in play order
        led_suit: Suit of the first card played
        
    Returns:
        Tuple of (winner_index, player_id)
        winner_index: Index in trick list of winning card
        player_id: ID of winning player
        
    Example:
        >>> trick = [
        ...     ('player1', Card('Hearts', 'K')),
        ...     ('player2', Card('Spades', '5')),  # Trump
        ...     ('player3', Card('Hearts', 'A'))
        ... ]
        >>> determine_trick_winner(trick, 'Hearts')
        (1, 'player2')  # Spade beats everything
    """
    if not trick:
        raise ValueError("Empty trick")
    
    # Separate trump and non-trump cards
    trump_cards = [(i, pid, card) for i, (pid, card) in enumerate(trick) 
                   if trump_suit and card.suit == trump_suit]
    
    if trump_cards:
        # Highest trump wins
        winner_idx, winner_pid, winner_card = max(
            trump_cards,
            key=lambda x: x[2].value
        )
        return winner_idx, winner_pid
    
    # No trump played - highest card of led suit wins
    led_suit_cards = [(i, pid, card) for i, (pid, card) in enumerate(trick)
                      if card.suit == led_suit]
    
    if not led_suit_cards:
        # Should never happen in valid game
        raise ValueError("No cards of led suit in trick")
    
    winner_idx, winner_pid, winner_card = max(
        led_suit_cards,
        key=lambda x: x[2].value
    )
    
    return winner_idx, winner_pid


def get_trick_leader(
    trick: List[Tuple[str, Card]],
    led_suit: str,
    trump_suit: Optional[str]
) -> Tuple[Optional[str], Optional[Card]]:
    """
    Get the player currently winning the trick.
    
    Args:
        trick: Current trick cards
        led_suit: Suit that was led
        
    Returns:
        Tuple of (player_id, winning_card) or (None, None) if empty
    """
    if not trick:
        return None, None
    
    _, winner_pid = determine_trick_winner(trick, led_suit, trump_suit)
    winning_card = next(card for pid, card in trick if pid == winner_pid)
    
    return winner_pid, winning_card
