"""
Modern host screen showing game code, players, and start control.
"""

from kivy.animation import Animation
from kivy.clock import Clock
from kivy.core.clipboard import Clipboard
from kivy.graphics import Color, Ellipse, RoundedRectangle
from kivy.properties import BooleanProperty, ListProperty, NumericProperty, StringProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.screenmanager import Screen

from ui.widgets.modern_controls import IconButton, ModernButton, ModernOutlineButton


class ModernHostScreen(Screen):
    """Immersive hosting screen with code display and player avatars."""

    is_host = BooleanProperty(True)
    game_code = StringProperty("")
    host_ip = StringProperty("")
    max_players = NumericProperty(4)
    players = ListProperty()

    def __init__(self, app, **kwargs):
        super().__init__(**kwargs)
        self.app = app
        self.code_glow_color = None
        self.code_glow = None
        self.code_bg = None
        self.code_display = None
        self.player_count_badge = None
        self.players_grid = None
        self.start_btn = None
        self.build_ui()

    def build_ui(self):
        root = FloatLayout(size_hint=(1, 1))
        with root.canvas.before:
            Color(0.1, 0.15, 0.2, 1)
            self.bg_rect = RoundedRectangle(pos=root.pos, size=root.size, radius=[0])
        root.bind(size=self._update_bg, pos=self._update_bg)

        back_btn = IconButton(icon="←", pos_hint={"x": 0.02, "top": 0.98})
        back_btn.bind(on_press=self._back_to_menu)
        root.add_widget(back_btn)

        title = Label(
            text="HOST GAME",
            font_size="32sp",
            bold=True,
            size_hint=(1, 0.08),
            pos_hint={"x": 0, "top": 0.98},
        )
        root.add_widget(title)

        # Game code card
        code_card = FloatLayout(size_hint=(0.88, 0.35), pos_hint={"center_x": 0.5, "center_y": 0.65})
        with code_card.canvas.before:
            self.code_glow_color = Color(0.2, 0.8, 0.4, 0.2)
            self.code_glow = RoundedRectangle(pos=code_card.pos, size=code_card.size, radius=[12])
            Color(0.15, 0.20, 0.25, 1)
            self.code_bg = RoundedRectangle(pos=code_card.pos, size=code_card.size, radius=[10])
        code_card.bind(pos=self._update_code_card, size=self._update_code_card)

        code_content = BoxLayout(orientation="vertical", padding=20, spacing=12)
        share_label = Label(
            text="📱 Share this code with friends",
            font_size="18sp",
            color=(1, 1, 1, 0.7),
            size_hint_y=0.2,
        )
        code_content.add_widget(share_label)

        self.code_display = Label(
            text="------",
            font_size="64sp",
            bold=True,
            color=(1, 0.84, 0, 1),
            size_hint_y=0.5,
        )
        code_content.add_widget(self.code_display)

        actions_row = BoxLayout(orientation="horizontal", size_hint_y=0.3, spacing=12)
        copy_btn = ModernOutlineButton(text="📋 COPY", background_color=(0.2, 0.6, 0.9, 1))
        copy_btn.bind(on_press=self.copy_code)
        actions_row.add_widget(copy_btn)
        share_btn = ModernOutlineButton(text="📤 SHARE", background_color=(0.8, 0.3, 0.9, 1))
        share_btn.bind(on_press=self.share_code)
        actions_row.add_widget(share_btn)
        code_content.add_widget(actions_row)
        code_card.add_widget(code_content)
        root.add_widget(code_card)

        # Players area
        players_card = FloatLayout(size_hint=(0.88, 0.35), pos_hint={"center_x": 0.5, "y": 0.12})
        with players_card.canvas.before:
            Color(0.12, 0.18, 0.24, 1)
            self.players_bg = RoundedRectangle(pos=players_card.pos, size=players_card.size, radius=[8])
        players_card.bind(pos=self._update_players_card, size=self._update_players_card)

        players_content = BoxLayout(orientation="vertical", padding=16, spacing=10)
        players_header = BoxLayout(orientation="horizontal", size_hint_y=0.2)
        players_title = Label(
            text="👥 Players",
            font_size="20sp",
            bold=True,
            halign="left",
            size_hint_x=0.6,
        )
        players_title.bind(size=players_title.setter("text_size"))
        players_header.add_widget(players_title)
        self.player_count_badge = Label(
            text="0 / 0",
            font_size="18sp",
            bold=True,
            color=(0.2, 0.8, 0.4, 1),
            size_hint_x=0.4,
        )
        players_header.add_widget(self.player_count_badge)
        players_content.add_widget(players_header)

        self.players_grid = GridLayout(cols=4, spacing=12, size_hint_y=0.8)
        players_content.add_widget(self.players_grid)
        players_card.add_widget(players_content)
        root.add_widget(players_card)

        self.start_btn = ModernButton(
            text="START GAME",
            size_hint=(0.7, None),
            height=64,
            pos_hint={"center_x": 0.5, "y": 0.02},
            background_color=(0.2, 0.8, 0.4, 1),
            disabled=True,
        )
        self.start_btn.bind(on_press=self.start_game)
        root.add_widget(self.start_btn)

        self.add_widget(root)
        Clock.schedule_once(lambda *_: self.animate_glow(), 0.2)

    # ---------- Setup ----------

    def setup_host(self, game_code: str, host_ip: str, max_players: int, host_name: str):
        self.game_code = game_code
        self.host_ip = host_ip
        self.max_players = max_players
        if self.code_display:
            self.code_display.text = game_code or "------"
        self.update_players([
            {"player_id": "host", "player_name": host_name or "Host", "is_ready": True, "is_host": True}
        ])

    # ---------- UI updates ----------

    def update_players(self, players_list, max_players=None):
        if max_players:
            self.max_players = max_players
        self.players = players_list or []
        self.players_grid.clear_widgets()
        for pdata in self.players:
            self._add_player_avatar(pdata.get("player_name", "Player"), pdata.get("is_host"))
        slot_count = max((self.max_players or 0) - len(self.players), 0)
        for _ in range(slot_count):
            self._add_empty_slot()
        ready_count = sum(1 for p in self.players if p.get("is_ready"))
        total = len(self.players)
        self.player_count_badge.text = f"{total} / {self.max_players}"
        # Enable start if everyone is ready and at least 2 players
        self.start_btn.disabled = not (total >= 2 and ready_count == total and self.is_host)

    def _add_player_avatar(self, name, is_host=False):
        avatar_container = BoxLayout(orientation="vertical", spacing=4)
        avatar = FloatLayout(size_hint_y=0.7)
        with avatar.canvas.before:
            Color(0.3, 0.7, 0.5, 1) if is_host else Color(0.5, 0.5, 0.6, 1)
            circle = Ellipse(pos=(avatar.x + 5, avatar.y + 5), size=(avatar.width - 10, avatar.height - 10))
        avatar.bind(pos=lambda inst, *_: self._update_circle(inst, circle), size=lambda inst, *_: self._update_circle(inst, circle))
        emoji = Label(text="👑" if is_host else "👤", font_size="32sp")
        avatar.add_widget(emoji)
        avatar_container.add_widget(avatar)
        name_label = Label(
            text=name,
            font_size="12sp",
            size_hint_y=0.3,
            color=(1, 1, 1, 0.9) if is_host else (1, 1, 1, 0.7),
        )
        avatar_container.add_widget(name_label)
        self.players_grid.add_widget(avatar_container)
        avatar_container.opacity = 0
        avatar_container.scale = 0
        Animation(opacity=1, scale=1, duration=0.4, transition="out_elastic").start(avatar_container)

    def _add_empty_slot(self):
        slot = BoxLayout(orientation="vertical", spacing=4)
        empty_avatar = FloatLayout(size_hint_y=0.7)
        with empty_avatar.canvas.before:
            Color(0.3, 0.3, 0.35, 1)
            dash = Ellipse(pos=(empty_avatar.x + 10, empty_avatar.y + 10), size=(empty_avatar.width - 20, empty_avatar.height - 20))
        empty_avatar.bind(pos=lambda inst, *_: self._update_circle(inst, dash), size=lambda inst, *_: self._update_circle(inst, dash))
        waiting_icon = Label(text="⏳", font_size="28sp", color=(1, 1, 1, 0.3))
        empty_avatar.add_widget(waiting_icon)
        slot.add_widget(empty_avatar)
        waiting_text = Label(text="Waiting...", font_size="11sp", size_hint_y=0.3, color=(1, 1, 1, 0.4))
        slot.add_widget(waiting_text)
        self.players_grid.add_widget(slot)

    # ---------- Actions ----------

    def start_game(self, *_):
        if self.app and self.app.network_server:
            self.app.network_server.start_game()

    def copy_code(self, *_):
        if not self.game_code:
            return
        Clipboard.copy(self.game_code)

    def share_code(self, *_):
        if not self.game_code:
            return
        try:
            from android import mActivity
            from jnius import autoclass

            Intent = autoclass("android.content.Intent")
            String = autoclass("java.lang.String")

            intent = Intent()
            intent.setAction(Intent.ACTION_SEND)
            intent.setType("text/plain")
            intent.putExtra(Intent.EXTRA_TEXT, String(f"Join my Call Break game! Code: {self.game_code}"))
            mActivity.startActivity(Intent.createChooser(intent, String("Share Game Code")))
        except Exception:
            # Silent fallback on non-Android
            pass

    def _back_to_menu(self, *_):
        if self.manager:
            self.manager.current = "menu"

    # ---------- Animations & updates ----------

    def animate_glow(self):
        if not self.code_glow_color:
            return
        anim = Animation(a=0.4, duration=1.5, transition="in_out_sine") + Animation(a=0.1, duration=1.5, transition="in_out_sine")
        anim.repeat = True
        anim.bind(on_progress=lambda inst, prog: setattr(self.code_glow_color, "a", inst.a))
        anim.start(self.code_glow_color)

    def _update_bg(self, root, *_):
        self.bg_rect.pos = root.pos
        self.bg_rect.size = root.size

    def _update_code_card(self, widget, *_):
        if self.code_glow:
            self.code_glow.pos = (widget.x - 10, widget.y - 10)
            self.code_glow.size = (widget.width + 20, widget.height + 20)
        if self.code_bg:
            self.code_bg.pos = widget.pos
            self.code_bg.size = widget.size

    def _update_players_card(self, widget, *_):
        if self.players_bg:
            self.players_bg.pos = widget.pos
            self.players_bg.size = widget.size

    def _update_circle(self, widget, shape):
        shape.pos = (widget.x + 5, widget.y + 5)
        shape.size = (max(widget.width - 10, 0), max(widget.height - 10, 0))
