"""
WiFi Server for Call Break game (Host).

Primary connection method supporting 2-12 players.
"""

import logging
import random
import socket
import threading
import time
from enum import Enum
from typing import Optional, Callable, Dict, List

from kivy.clock import Clock

from .connection_manager import ConnectionManager
from .message_handler import MessageHandler, MessageType
from .game_code import GameCodeManager, ACTIVE_GAMES
from game.player import Player


class GamePhase(Enum):
    """Minimal server-side phase machine for sequencing."""

    LOBBY = "lobby"
    GAME_START = "game_start"
    DEALING = "dealing"
    TRUMP_SELECTION = "trump_selection"
    BIDDING = "bidding"
    PLAYING = "playing"
    TRICK_END = "trick_end"
    ROUND_END = "round_end"
    GAME_END = "game_end"


class WiFiGameServer:
    """
    WiFi game server using TCP sockets.
    
    Host device creates server and clients connect via local IP.
    Supports 2-12 players with stable performance.
    
    Attributes:
        host: IP address to bind to (default 0.0.0.0)
        port: Port to listen on (default 5555)
        max_players: Maximum number of players
        server_socket: Main server socket
        clients: Dictionary of client connections
        game_callback: Callback for game events
        running: Server running state
    """
    
    def __init__(self, host: str = '0.0.0.0', port: int = 5555,
                 max_players: int = 12, game_callback: Optional[Callable] = None):
        """
        Initialize WiFi server.
        
        Args:
            host: IP to bind to (0.0.0.0 for all interfaces)
            port: Port number
            max_players: Maximum players (2-12)
            game_callback: Callback for game events
        """
        self.host = host
        self.port = port
        self.max_players = max_players
        self.game_callback = game_callback
        
        self.server_socket: Optional[socket.socket] = None
        self.connection_manager = ConnectionManager(
            disconnect_callback=self._handle_disconnect
        )
        self.running = False
        self.lock = threading.Lock()
        self.phase_lock = threading.Lock()
        self.phase_transition_in_progress = False
        
        self.local_ip = self._get_local_ip()
        self.game_code: Optional[str] = None
        # Trump selection state
        self.trump_chooser_id: Optional[str] = None
        self.trump_chooser_name: str = ""
        self.trump_selection_timeout: Optional[threading.Thread] = None
        self.trump_selected_event = threading.Event()
        self.current_trump_suit: Optional[str] = None
        self.host_player_id: Optional[str] = None
        self.host_player_name: str = "Host"
        self.game_state = None

        # Round / phase tracking
        self.current_phase: GamePhase = GamePhase.LOBBY
        self.current_round: int = 0
        self.total_rounds: int = 5
        self.dealing_complete = False
        self.trump_selection_complete = False
        self.bidding_complete = False
        self.tricks_completed = 0
        self.cards_dealt_count = 0
        self.bids_received_count = 0
        self.trump_selection_started = False
        self.bidding_started = False
        self.dealt_rounds = set()
        self.dealing_in_progress = False

        # Bidding / playing state
        self.bidding_order: List = []
        self.current_bidder_index: int = 0
        self.bid_timeouts: Dict[str, threading.Thread] = {}
        self.play_order: List = []
        self.current_player_index: int = 0
        self.current_trick = []
        self.led_suit = None

        # Lobby readiness tracking
        self.ready_players = set()

        # Logger
        self.logger = logging.getLogger('GameServer')
        if not self.logger.handlers:
            handler = logging.FileHandler('game_server.log')
            handler.setFormatter(logging.Formatter('%(asctime)s [%(levelname)s] %(message)s'))
            self.logger.addHandler(handler)
        self.logger.setLevel(logging.DEBUG)

        # Network safety limits
        self.max_message_size = 1024 * 512  # 512KB guardrail to prevent runaway payloads
        self.recv_timeout = 30.0
        self.handshake_timeout = 10.0
    
    def _get_local_ip(self) -> str:
        """
        Get device's local IP address.
        
        Returns:
            Local IP address string
        """
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            # Connect to external address (doesn't actually send data)
            s.connect(('10.255.255.255', 1))
            ip = s.getsockname()[0]
        except Exception:
            ip = '127.0.0.1'
        finally:
            s.close()
        return ip

    # ---------- Socket helpers ----------

    def _send_with_length(self, conn: socket.socket, payload: bytes) -> None:
        """Prefix payload with length header and send safely."""
        header = len(payload).to_bytes(4, 'big')
        conn.sendall(header + payload)

    def _recv_exact(self, conn: socket.socket, nbytes: int) -> Optional[bytes]:
        """Receive exactly nbytes or return None on failure/timeout."""
        data = bytearray()
        while len(data) < nbytes:
            chunk = conn.recv(nbytes - len(data))
            if not chunk:
                return None
            data.extend(chunk)
        return bytes(data)

    def _recv_message(self, conn: socket.socket) -> Optional[Dict]:
        """Receive a single length-prefixed JSON message with bounds checking."""
        try:
            header = self._recv_exact(conn, 4)
            if not header:
                return None
            length = int.from_bytes(header, 'big')
            if length <= 0 or length > self.max_message_size:
                self.logger.warning(f"Rejected message of size {length}")
                return None
            payload = self._recv_exact(conn, length)
            if not payload:
                return None
            return MessageHandler.decode(payload)
        except Exception as exc:  # log and continue without crashing accept loop
            self.logger.warning(f"Receive error: {exc}")
            return None
    
    def start(self) -> tuple:
        """Start the WiFi server and generate a join code.

        Returns:
            Tuple (success: bool, code: Optional[str], ip: Optional[str])
        """
        try:
            self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

            ports_to_try = [self.port, 5556, 5557, 0]
            for candidate in ports_to_try:
                try:
                    self.server_socket.bind((self.host, candidate))
                    # Update actual port (0 => ephemeral assigned)
                    self.port = self.server_socket.getsockname()[1]
                    break
                except OSError:
                    continue
            else:
                raise Exception("No available ports")

            self.server_socket.listen(self.max_players)
            self.running = True

            # Generate and register game code
            self.game_code = GameCodeManager.generate_code()
            self.local_ip = GameCodeManager.get_local_ip()
            GameCodeManager.register(self.game_code, self.local_ip, self.port, self.host_player_name)

            print(f"🌐 WiFi Server started on {self.local_ip}:{self.port}")
            print(f"📱 Game Code: {self.game_code}")

            # Start accepting connections
            accept_thread = threading.Thread(target=self._accept_connections)
            accept_thread.daemon = True
            accept_thread.start()

            # Initialize game flow state
            self.current_phase = GamePhase.GAME_START

            # Initial lobby broadcast including host
            self._broadcast_lobby_update()

            return True, self.game_code, self.local_ip

        except Exception as e:
            print(f"❌ Failed to start server: {e}")
            return False, None, None
    
    def _accept_connections(self):
        """Accept incoming client connections."""
        while self.running:
            try:
                # Check if we have room for more players
                connected_count = len(self.connection_manager.get_all_connected())
                if connected_count >= self.max_players - 1:  # -1 for host
                    time.sleep(0.5)
                    continue
                
                # Set timeout to check running flag periodically
                self.server_socket.settimeout(1.0)
                
                try:
                    conn, addr = self.server_socket.accept()
                    print(f"📥 Connection from {addr}")
                    
                    # Start handler thread
                    handler_thread = threading.Thread(
                        target=self._handle_new_connection,
                        args=(conn, addr)
                    )
                    handler_thread.daemon = True
                    handler_thread.start()
                    
                except socket.timeout:
                    continue
                    
            except Exception as e:
                if self.running:
                    print(f"⚠️ Accept error: {e}")
    
    def _handle_new_connection(self, conn: socket.socket, addr: tuple):
        """
        Handle a new client connection.
        
        Args:
            conn: Client socket
            addr: Client address
        """
        try:
            # Receive player info
            conn.settimeout(self.handshake_timeout)
            message = self._recv_message(conn)
            
            if message.get('type') != MessageType.PLAYER_JOIN:
                conn.close()
                return
            
            player_id = message.get('player_id')
            player_name = message.get('player_name', 'Unknown')
            
            # Add to connection manager
            self.connection_manager.add_connection(player_id, conn, player_name)
            # Track readiness per player
            with self.lock:
                if player_id in self.ready_players:
                    self.ready_players.discard(player_id)
            
            print(f"✅ Player joined: {player_name} ({player_id})")
            
            # Notify game callback
            if self.game_callback:
                self.game_callback('player_join', {
                    'player_id': player_id,
                    'player_name': player_name
                })

            # Broadcast lobby state
            self._broadcast_lobby_update()
            
            # Start message handler for this client
            self._handle_client(player_id, conn)
            
        except Exception as e:
            print(f"❌ New connection error: {e}")
            try:
                conn.close()
            except:
                pass
    
    def _handle_client(self, player_id: str, conn: socket.socket):
        """
        Handle messages from a client.
        
        Args:
            player_id: Player's unique ID
            conn: Client socket
        """
        conn.settimeout(self.recv_timeout)
        
        try:
            while self.running and self.connection_manager.is_connected(player_id):
                try:
                    message = self._recv_message(conn)
                    if not message:
                        break

                    # Update last seen
                    self.connection_manager.update_last_seen(player_id)

                    self._process_message(player_id, message)
                    
                except socket.timeout:
                    # Check if still connected with ping/pong
                    continue
                    
        except Exception as e:
            print(f"⚠️ Client {player_id} error: {e}")
        finally:
            self.connection_manager.mark_disconnected(player_id)
            try:
                conn.close()
            except:
                pass
    
    def _process_message(self, player_id: str, message: Dict):
        """
        Process received message from client.
        
        Args:
            player_id: Sender's ID
            message: Decoded message dictionary
        """
        msg_type = message.get('type')

        if msg_type in ('trump_selected', 'trump_chosen'):
            trump_suit = message.get('trump_suit')
            self.handle_trump_selection(player_id, trump_suit)
            return

        if msg_type == MessageType.READY:
            self.mark_player_ready(player_id)
            return

        if msg_type == MessageType.STATE_SYNC_REQUEST:
            self.send_state_snapshot(player_id)
            return

        if msg_type in ('bid', 'bid_made'):
            amount = message.get('amount')
            self.handle_bid_received(player_id, amount, auto=False)
            return

        if msg_type in ('play', 'card_played'):
            card = message.get('card')
            self.handle_card_played(player_id, card)
            return

        if self.game_callback:
            self.game_callback('message', {
                'player_id': player_id,
                'message': message
            })
    
    def _handle_disconnect(self, player_id: str):
        """
        Handle player disconnection.
        
        Args:
            player_id: Disconnected player ID
        """
        print(f"⚠️ Player disconnected: {player_id}")
        
        if self.game_callback:
            self.game_callback('player_disconnect', {
                'player_id': player_id
            })
        with self.lock:
            self.ready_players.discard(player_id)
        self._broadcast_lobby_update()
    
    def broadcast(self, message: Dict, exclude: Optional[str] = None):
        """
        Broadcast message to all connected clients.
        
        Args:
            message: Message dictionary to send
            exclude: Optional player ID to exclude from broadcast
        """
        self.logger.debug(f"BROADCAST {message.get('type')} r{message.get('round_number')} phase={message.get('phase')}")
        data = MessageHandler.encode(message)

        for player_id, conn in self.connection_manager.get_all_connected().items():
            if player_id != exclude:
                try:
                    self._send_with_length(conn, data)
                except Exception as e:
                    print(f"⚠️ Broadcast error to {player_id}: {e}")
                    self.connection_manager.mark_disconnected(player_id)
        # Deliver to host app if needed
        if self.game_callback and (not exclude or exclude != self.host_player_id):
            self.game_callback('message', {'player_id': 'server', 'message': message})

    def _broadcast_lobby_update(self):
        """Broadcast current lobby players and ready status."""
        players = []
        if self.host_player_id:
            players.append({
                'player_id': self.host_player_id,
                'player_name': self.host_player_name,
                'is_ready': self.host_player_id in self.ready_players
            })
        with self.connection_manager.lock:
            connections_copy = dict(self.connection_manager.connections)
        for pid, info in connections_copy.items():
            players.append({
                'player_id': pid,
                'player_name': info.get('name', pid),
                'is_ready': pid in self.ready_players
            })
        lobby_msg = MessageHandler.create_lobby_update(players, self.max_players)
        self.broadcast(lobby_msg)

    # ---------- Lobby / game start ----------

    def start_game(self) -> bool:
        """Start the game when all players are ready."""
        with self.phase_lock:
            if self.current_phase not in (GamePhase.LOBBY, GamePhase.GAME_START):
                print(f"ERROR: Cannot start game from phase {self.current_phase.value}")
                return False

        # Ensure readiness
        with self.connection_manager.lock:
            connected_snapshot = dict(self.connection_manager.connections)
        expected_players = len(connected_snapshot) + (1 if self.host_player_id else 0)
        ready_count = len(self.ready_players)
        if expected_players == 0:
            print("ERROR: No players connected")
            return False
        if ready_count < expected_players:
            print(f"ERROR: Not all players ready ({ready_count}/{expected_players})")
            return False

        # Build players list (host + clients) and shuffle order
        players: List[Player] = []
        if self.host_player_id:
            players.append(Player(self.host_player_id, self.host_player_name or "Host"))
        for pid, info in connected_snapshot.items():
            players.append(Player(pid, info.get('name', pid)))
        if len(players) < 2:
            print("ERROR: Need at least 2 players to start")
            return False
        random.shuffle(players)

        # Initialize or refresh game state
        try:
            from game.game_logic import GameState as CoreGameState
        except Exception:
            CoreGameState = None

        if self.game_state is None and CoreGameState:
            self.game_state = CoreGameState(num_players=len(players), num_rounds=self.total_rounds)
        if self.game_state:
            self.game_state.players = players
            self.game_state.player_order = [p.player_id for p in players]
            self.game_state.num_players = len(players)
            self.game_state.num_rounds = getattr(self, 'total_rounds', self.game_state.num_rounds)
            self.game_state.current_round = 0
            self.game_state.phase = GamePhase.GAME_START.value.upper()

        self.current_round = 0
        self.reset_round_state()
        self.current_phase = GamePhase.GAME_START

        dealer_id = players[0].player_id
        num_decks = getattr(self.game_state, 'num_decks', 1)
        game_start_msg = MessageHandler.create_game_start(
            player_order=[p.player_id for p in players],
            dealer=dealer_id,
            num_decks=num_decks,
            num_rounds=self.total_rounds,
        )
        self.broadcast(game_start_msg)

        # Inform about round start then schedule first round
        round_start_msg = MessageHandler.create_round_start(1, self.total_rounds)
        self.broadcast(round_start_msg)
        Clock.schedule_once(lambda *_: self.start_new_round(), 0.5)
        return True
    
    def send_to_player(self, player_id: str, message: Dict) -> bool:
        """
        Send message to specific player.
        
        Args:
            player_id: Target player ID
            message: Message dictionary
            
        Returns:
            True if sent successfully
        """
        conn = self.connection_manager.get_connection(player_id)
        if not conn:
            return False
        
        try:
            data = MessageHandler.encode(message)
            self._send_with_length(conn, data)
            return True
        except Exception as e:
            print(f"⚠️ Send error to {player_id}: {e}")
            self.connection_manager.mark_disconnected(player_id)
            return False

    # ---------- Message helpers ----------

    def create_message(self, msg_type: str, data: Dict) -> Dict:
        """Standardize outbound messages with round/phase/timestamp."""
        return {
            'type': msg_type,
            'round_number': self.current_round,
            'phase': self.current_phase.value,
            'timestamp': time.time(),
            **data,
        }

    def mark_player_ready(self, player_id: str):
        """Mark player as ready and broadcast lobby update."""
        with self.lock:
            self.ready_players.add(player_id)
        self._broadcast_lobby_update()

    def send_state_snapshot(self, player_id: str):
        """Send a state snapshot to a reconnecting/requesting player."""
        snapshot = self._build_state_snapshot(player_id)
        if not snapshot:
            return
        msg = MessageHandler.create_state_sync_snapshot(snapshot)
        self.send_to_player(player_id, msg)

    def _build_state_snapshot(self, player_id: str) -> Optional[Dict]:
        if not self.game_state:
            return None
        try:
            # Basic round/phase
            snapshot = {
                'round_number': self.current_round,
                'phase': self.current_phase.value,
                'player_order': [p.player_id for p in self.game_state.players],
                'trump_suit': getattr(self, 'current_trump_suit', None),
                'trump_chooser_id': getattr(self, 'trump_chooser_id', None),
            }

            # Bids / tricks / scores
            snapshot['bids'] = {p.player_id: p.current_bid for p in self.game_state.players}
            snapshot['tricks_won_count'] = {p.player_id: p.tricks_won_this_round for p in self.game_state.players}
            snapshot['scores'] = {
                'round': {p.player_id: getattr(p, 'score_this_round', 0.0) for p in self.game_state.players},
                'total': {p.player_id: p.total_score for p in self.game_state.players},
            }

            # Current turn context
            snapshot['current_trick'] = [(pid, str(c)) for pid, c in self.current_trick]
            snapshot['trick_number'] = self.tricks_completed + (1 if self.current_trick else 0)
            snapshot['current_player_id'] = None
            snapshot['current_bidder_id'] = None

            if self.current_phase == GamePhase.BIDDING and self.bidding_order:
                if 0 <= self.current_bidder_index < len(self.bidding_order):
                    snapshot['current_bidder_id'] = self.bidding_order[self.current_bidder_index].player_id

            if self.current_phase in (GamePhase.PLAYING, GamePhase.TRICK_END) and self.play_order:
                if 0 <= self.current_player_index < len(self.play_order):
                    snapshot['current_player_id'] = self.play_order[self.current_player_index].player_id

            # Hands: only send requester hand; others send counts
            requester = self.game_state.get_player(player_id)
            snapshot['hands'] = {
                'self': [str(c) for c in requester.hand] if requester else [],
                'others': {p.player_id: len(p.hand) for p in self.game_state.players if p.player_id != player_id},
            }

            # If requester is current actor, include valid_cards
            if requester:
                if snapshot.get('current_player_id') == requester.player_id:
                    valid_cards = self.get_valid_cards(requester)
                    snapshot['valid_cards'] = [str(c) for c in valid_cards]
                if snapshot.get('current_bidder_id') == requester.player_id:
                    snapshot['min_bid'] = 1
                    snapshot['max_bid'] = len(requester.hand)

            return snapshot
        except Exception as e:
            print(f"⚠️ Snapshot build error for {player_id}: {e}")
            return None
    
    def get_connected_players(self) -> List[str]:
        """Get list of connected player IDs."""
        return list(self.connection_manager.get_all_connected().keys())

    # ---------- Round lifecycle ----------

    def reset_round_state(self):
        """Reset per-round flags and counters."""
        self.dealing_complete = False
        self.trump_selection_complete = False
        self.bidding_complete = False
        self.trump_selection_started = False
        self.bidding_started = False
        self.dealing_in_progress = False
        self.cards_dealt_count = 0
        self.bids_received_count = 0
        self.tricks_completed = 0
        self.current_trick = []
        self.led_suit = None
        self.bidding_order = []
        self.play_order = []

    def start_new_round(self):
        """Entry point for beginning a round; enforces single start."""
        with self.phase_lock:
            if self.phase_transition_in_progress:
                print("WARNING: Round start already in progress")
                return
            self.phase_transition_in_progress = True
        try:
            with self.phase_lock:
                if self.current_phase not in (GamePhase.GAME_START, GamePhase.ROUND_END, GamePhase.LOBBY):
                    print(f"ERROR: Cannot start new round from {self.current_phase.value}")
                    return
                self.current_round += 1
            if self.current_round > self.total_rounds:
                self.transition_to_phase(GamePhase.GAME_END)
                return
            print(f"\n=== Starting round {self.current_round}/{self.total_rounds} ===")
            self.reset_round_state()
            self.transition_to_phase(GamePhase.DEALING)
            self.deal_cards_for_round()
        except Exception as e:
            print(f"❌ Round start error: {e}")
            raise
        finally:
            with self.phase_lock:
                self.phase_transition_in_progress = False

    def mark_dealing_complete(self, dealt_players: Optional[int] = None):
        """Checkpoint: call once after all hands sent to players."""
        expected = len(self.connection_manager.get_all_connected()) + (1 if self.host_player_id else 0)
        if dealt_players is not None:
            self.cards_dealt_count = dealt_players
        if self.cards_dealt_count and self.cards_dealt_count != expected:
            print(f"WARNING: Dealt to {self.cards_dealt_count}/{expected} players")
        else:
            self.cards_dealt_count = expected
        self.dealing_complete = True
        with self.phase_lock:
            if self.current_phase != GamePhase.DEALING:
                if self.current_phase in (GamePhase.LOBBY, GamePhase.GAME_START, GamePhase.ROUND_END):
                    self.current_phase = GamePhase.DEALING
                else:
                    print(f"ERROR: Dealing complete in wrong phase {self.current_phase.value}")
                    return
            if self.trump_selection_started:
                print("WARNING: Trump selection already started; skipping duplicate trigger")
                return
            self.trump_selection_started = True
            self.dealt_rounds.add(self.current_round or 1)
        if self.transition_to_phase(GamePhase.TRUMP_SELECTION):
            Clock.schedule_once(lambda *_: self.start_trump_selection(), 1.0)
        else:
            with self.phase_lock:
                self.trump_selection_started = False

    # ---------- Phase management ----------

    def transition_to_phase(self, new_phase: GamePhase) -> bool:
        """Validate and transition to a new game phase atomically."""
        with self.phase_lock:
            old_phase = self.current_phase
            if not self._is_valid_phase_transition(old_phase, new_phase):
                print(f"ERROR: Invalid phase transition {old_phase.value} -> {new_phase.value}")
                return False
            self.current_phase = new_phase
            if self.game_state:
                self.game_state.phase = new_phase.value.upper()
            print(f"Phase: {old_phase.value} -> {new_phase.value} (round {self.current_round})")
            return True

    @staticmethod
    def _is_valid_phase_transition(from_phase: GamePhase, to_phase: GamePhase) -> bool:
        """Simple state machine for legal transitions."""
        valid_transitions = {
            GamePhase.LOBBY: [GamePhase.GAME_START],
            GamePhase.GAME_START: [GamePhase.DEALING],
            GamePhase.DEALING: [GamePhase.TRUMP_SELECTION],
            GamePhase.TRUMP_SELECTION: [GamePhase.BIDDING],
            GamePhase.BIDDING: [GamePhase.PLAYING],
            GamePhase.PLAYING: [GamePhase.TRICK_END, GamePhase.ROUND_END],
            GamePhase.TRICK_END: [GamePhase.PLAYING, GamePhase.ROUND_END],
            GamePhase.ROUND_END: [GamePhase.DEALING, GamePhase.GAME_END],
            GamePhase.GAME_END: [],
        }
        return to_phase in valid_transitions.get(from_phase, [])

    # ---------- Trump selection flow ----------

    def start_trump_selection(self):
        """Kick off trump selection after dealing; called once per round."""
        with self.phase_lock:
            if self.current_phase != GamePhase.TRUMP_SELECTION:
                print(f"ERROR: start_trump_selection in phase {self.current_phase.value}")
                return
            if not self.dealing_complete:
                print("ERROR: Trump selection attempted before dealing complete")
                return
        self.trump_selected_event.clear()
        self._select_random_trump_chooser()
        self._broadcast_trump_chooser()
        self._request_trump_from_chooser()
        self._start_trump_timeout()

    def _select_random_trump_chooser(self):
        player_ids = list(self.connection_manager.get_all_connected().keys())
        if self.host_player_id:
            player_ids.append(self.host_player_id)
        if not player_ids:
            return
        self.trump_chooser_id = random.choice(player_ids)
        if self.game_state:
            player = self.game_state.get_player(self.trump_chooser_id)
            self.trump_chooser_name = player.name if player else self.trump_chooser_id
        else:
            self.trump_chooser_name = self.trump_chooser_id

    def _broadcast_trump_chooser(self):
        if not self.trump_chooser_id:
            return
        message = self.create_message('trump_chooser', {
            'player_id': self.trump_chooser_id,
            'player_name': self.trump_chooser_name or self.trump_chooser_id,
        })
        self.broadcast(message)

    def _request_trump_from_chooser(self):
        if not self.trump_chooser_id:
            return
        message = self.create_message('trump_request', {
            'chooser_id': self.trump_chooser_id,
            'available_suits': ['Spades', 'Hearts', 'Diamonds', 'Clubs'],
            'timeout_seconds': 30,
        })
        if self.trump_chooser_id == self.host_player_id:
            # Host is chooser; let host app handle directly via callback
            if self.game_callback:
                self.game_callback('message', {
                    'player_id': self.trump_chooser_id,
                    'message': message
                })
        else:
            self.send_to_player(self.trump_chooser_id, message)

    def _start_trump_timeout(self):
        self.trump_selected_event.clear()

        def timeout_handler():
            selected = self.trump_selected_event.wait(timeout=30.0)
            if not selected:
                self._auto_select_random_trump()

        self.trump_selection_timeout = threading.Thread(target=timeout_handler, daemon=True)
        self.trump_selection_timeout.start()

    def handle_trump_selection(self, player_id: str, trump_suit: str):
        if not self.trump_chooser_id or player_id != self.trump_chooser_id:
            print("IGNORE: Trump selection from non-chooser")
            return
        if trump_suit not in ['Spades', 'Hearts', 'Diamonds', 'Clubs']:
            print("ERROR: Invalid trump suit")
            return
        with self.phase_lock:
            if self.trump_selection_complete:
                print("WARNING: Trump already selected; ignoring duplicate")
                return
        self.trump_selected_event.set()
        self._apply_trump_selection(trump_suit, player_id, auto_selected=False)

    def _auto_select_random_trump(self):
        suit = random.choice(['Spades', 'Hearts', 'Diamonds', 'Clubs'])
        self._apply_trump_selection(suit, self.trump_chooser_id, auto_selected=True)

    def _apply_trump_selection(self, trump_suit: str, chooser_id: Optional[str], auto_selected: bool):
        with self.phase_lock:
            if self.trump_selection_complete:
                print("WARNING: Duplicate trump application; skipping")
                return
        self.current_trump_suit = trump_suit
        if self.game_state:
            self.game_state.update_trump_suit(trump_suit)
        message = self.create_message('trump_chosen', {
            'chooser_id': chooser_id or '',
            'chooser_name': self.trump_chooser_name,
            'trump_suit': trump_suit,
            'auto_selected': auto_selected
        })
        self.broadcast(message)
        with self.phase_lock:
            self.trump_selection_complete = True
        Clock.schedule_once(lambda *_: self.start_bidding_phase(), 0.1)

    def start_bidding_phase(self):
        with self.phase_lock:
            if self.current_phase != GamePhase.TRUMP_SELECTION:
                print(f"ERROR: Bidding start in phase {self.current_phase.value}")
                return
            if not self.trump_selection_complete:
                print("ERROR: Bidding started before trump selection complete")
                return
            if self.bidding_started:
                print("WARNING: Bidding already started; skipping")
                return
            self.bidding_started = True
        if not self.transition_to_phase(GamePhase.BIDDING):
            with self.phase_lock:
                self.bidding_started = False
            return

        print(f"💭 Bidding phase (Round {self.current_round})")
        if not self.game_state or not getattr(self.game_state, 'players', None):
            print("❌ No players for bidding")
            return

        dealer_idx = self.current_round % len(self.game_state.players)
        first_bidder = (dealer_idx + 1) % len(self.game_state.players)
        self.bidding_order = []
        for i in range(len(self.game_state.players)):
            idx = (first_bidder + i) % len(self.game_state.players)
            self.bidding_order.append(self.game_state.players[idx])
        self.current_bidder_index = 0
        self.bids_received_count = 0
        self.bid_timeouts = {}
        print(f"  Order: {[p.name for p in self.bidding_order]}")
        self.request_next_bid()

    def request_next_bid(self):
        """Request bid from next player, advancing when complete."""
        if self.current_bidder_index >= len(self.bidding_order):
            self.complete_bidding_phase()
            return

        current_player = self.bidding_order[self.current_bidder_index]
        cards_in_hand = len(current_player.hand)
        msg = self.create_message('bid_turn', {
            'player_id': current_player.player_id,
            'player_name': current_player.name,
            'min_bid': 1,
            'max_bid': cards_in_hand,
            'timeout_seconds': 30,
        })
        self.send_to_player(current_player.player_id, msg)

        status = self.create_message('bidding_status', {
            'current_bidder': current_player.name,
            'bids_so_far': self.bids_received_count,
            'total_players': len(self.bidding_order),
        })
        self.broadcast(status, exclude=current_player.player_id)
        print(f"  ? {current_player.name} bidding ({self.bids_received_count + 1}/{len(self.bidding_order)})")
        self.start_bid_timeout(current_player)

    def start_bid_timeout(self, player):
        """Start 30s bid timeout that auto-bids minimum."""

        def timeout():
            time.sleep(30)
            if player.current_bid == 0:
                print(f"⏱️ {player.name} bid timeout - auto 1")
                self.handle_bid_received(player.player_id, 1, auto=True)

        t = threading.Thread(target=timeout, daemon=True)
        t.start()
        self.bid_timeouts[player.player_id] = t

    def handle_bid_received(self, player_id: str, bid_amount: int, auto: bool = False):
        """Process bid from player and advance order."""
        if self.current_bidder_index >= len(self.bidding_order):
            print(f"❌ Bid from {player_id} but bidding complete")
            return
        current = self.bidding_order[self.current_bidder_index]
        if player_id != current.player_id:
            print(f"❌ Bid from {player_id} but it's {current.player_id}'s turn")
            return
        cards = len(current.hand)
        if bid_amount < 1 or bid_amount > cards:
            print(f"❌ Invalid bid {bid_amount} (1-{cards})")
            return
        current.current_bid = bid_amount
        self.bids_received_count += 1
        msg = self.create_message('bid_made', {
            'player_id': player_id,
            'player_name': current.name,
            'amount': bid_amount,
            'auto_bid': auto,
            'bids_received': self.bids_received_count,
            'total_players': len(self.bidding_order),
        })
        self.broadcast(msg)
        print(f"  ✓ {current.name}: {bid_amount}")
        self.current_bidder_index += 1
        Clock.schedule_once(lambda *_: self.request_next_bid(), 1.0)

    def complete_bidding_phase(self):
        """Finalize bidding and move to playing phase."""
        with self.phase_lock:
            self.bidding_complete = True
        print("✅ Bidding complete")
        all_bids = {p.player_id: p.current_bid for p in self.game_state.players}
        msg = self.create_message('bidding_complete', {'all_bids': all_bids})
        self.broadcast(msg)
        Clock.schedule_once(lambda *_: self.start_playing_phase(), 2.0)

    # ---------- Playing ----------

    def start_playing_phase(self):
        if not self.transition_to_phase(GamePhase.PLAYING):
            return
        print(f"🃏 Playing phase (Round {self.current_round})")
        self.play_order = list(self.bidding_order)
        self.current_player_index = 0
        self.current_trick = []
        self.led_suit = None
        self.tricks_completed = 0
        self.start_next_trick()

    def start_next_trick(self):
        self.current_trick = []
        self.led_suit = None
        self.tricks_completed += 1
        self.request_next_card_play()

    def request_next_card_play(self):
        if len(self.current_trick) >= len(self.game_state.players):
            self.resolve_trick()
            return
        player = self.play_order[self.current_player_index]
        valid_cards = self.get_valid_cards(player)
        msg = self.create_message('play_turn', {
            'player_id': player.player_id,
            'player_name': player.name,
            'valid_cards': [str(c) for c in valid_cards],
            'led_suit': self.led_suit,
            'trick_number': self.tricks_completed,
        })
        self.send_to_player(player.player_id, msg)
        status = self.create_message('playing_status', {
            'current_player': player.name,
            'trick_size': len(self.current_trick),
        })
        self.broadcast(status, exclude=player.player_id)

    def get_valid_cards(self, player):
        if not self.current_trick:
            return list(player.hand)
        trump_suit = self.game_state.current_trump_suit
        led_cards = [c for c in player.hand if c.suit == self.led_suit]
        if led_cards:
            return led_cards
        trump_cards = [c for c in player.hand if c.suit == trump_suit]
        if trump_cards:
            trick_has_trump = any(c.suit == trump_suit for _, c in self.current_trick)
            if trick_has_trump:
                highest_trump = max((c for _, c in self.current_trick if c.suit == trump_suit), key=lambda c: c.value)
                higher_trumps = [c for c in trump_cards if c.value > highest_trump.value]
                return higher_trumps or trump_cards
            return trump_cards
        return list(player.hand)

    def handle_card_played(self, player_id: str, card_str: str):
        if self.current_player_index >= len(self.play_order):
            return
        current = self.play_order[self.current_player_index]
        if player_id != current.player_id:
            print(f"❌ Card from {player_id} but it's {current.player_id}'s turn")
            return
        from game.card import Card
        card = Card.from_string(card_str)
        if card not in current.hand:
            print(f"❌ {card} not in {current.name}'s hand")
            return
        valid_cards = self.get_valid_cards(current)
        if card not in valid_cards:
            print(f"❌ {card} not a valid play")
            return
        current.hand.remove(card)
        self.current_trick.append((current.player_id, card))
        if len(self.current_trick) == 1:
            self.led_suit = card.suit
        msg = self.create_message('card_played', {
            'player_id': player_id,
            'player_name': current.name,
            'card': card_str,
            'trick_cards': [(pid, str(c)) for pid, c in self.current_trick],
        })
        self.broadcast(msg)
        print(f"  ✓ {current.name}: {card}")
        self.current_player_index = (self.current_player_index + 1) % len(self.play_order)
        Clock.schedule_once(lambda *_: self.request_next_card_play(), 1.0)

    def resolve_trick(self):
        trump_suit = self.game_state.current_trump_suit
        trump_cards = [(pid, c) for pid, c in self.current_trick if c.suit == trump_suit]
        if trump_cards:
            winner_id, winner_card = max(trump_cards, key=lambda x: x[1].value)
        else:
            led_cards = [(pid, c) for pid, c in self.current_trick if c.suit == self.led_suit]
            winner_id, winner_card = max(led_cards, key=lambda x: x[1].value)
        winner = self.game_state.get_player(winner_id)
        if winner:
            winner.tricks_won_this_round += 1
        tricks_count = {p.player_id: p.tricks_won_this_round for p in self.game_state.players}
        msg = self.create_message('trick_won', {
            'winner_id': winner_id,
            'winner_name': winner.name if winner else '',
            'winning_card': str(winner_card),
            'cards': [(pid, str(c)) for pid, c in self.current_trick],
            'tricks_won_count': tricks_count,
        })
        self.broadcast(msg)
        print(f"  🏆 {winner.name if winner else winner_id} wins trick {self.tricks_completed}")
        self.current_player_index = self.play_order.index(winner)
        if not winner.hand:
            Clock.schedule_once(lambda *_: self.complete_round(), 2.0)
        else:
            Clock.schedule_once(lambda *_: self.start_next_trick(), 2.0)

    # ---------- Round end ----------

    def complete_round(self):
        if not self.transition_to_phase(GamePhase.ROUND_END):
            return
        print(f"🏁 Round {self.current_round} complete")
        round_scores = {}
        total_scores = {}
        tricks_won = {}
        bids = {}
        for player in self.game_state.players:
            player.calculate_score()
            round_scores[player.player_id] = player.score_this_round
            total_scores[player.player_id] = player.total_score
            tricks_won[player.player_id] = player.tricks_won_this_round
            bids[player.player_id] = player.current_bid
            print(f"  {player.name}: Bid {player.current_bid}, Won {player.tricks_won_this_round}, Score {player.score_this_round:+.1f}")
        msg = self.create_message('round_end', {
            'scores': round_scores,
            'total_scores': total_scores,
            'tricks_won': tricks_won,
            'bids': bids,
        })
        self.broadcast(msg)
        if self.current_round < self.total_rounds:
            Clock.schedule_once(lambda *_: self.start_new_round(), 8.0)
        else:
            Clock.schedule_once(lambda *_: self.end_game(), 5.0)

    def end_game(self):
        if not self.transition_to_phase(GamePhase.GAME_END):
            return
        print("🎉 Game complete!")
        winner = max(self.game_state.players, key=lambda p: p.total_score)
        final_scores = {p.player_id: p.total_score for p in self.game_state.players}
        msg = self.create_message('game_end', {
            'final_scores': final_scores,
            'winner_id': winner.player_id,
            'winner_name': winner.name,
        })
        self.broadcast(msg)
    
    def stop(self):
        """Stop the server."""
        print("🛑 Stopping WiFi server...")
        self.running = False

        # Unregister code
        GameCodeManager.unregister(self.game_code)
        
        # Close all client connections
        self.connection_manager.close_all()
        
        # Close server socket
        if self.server_socket:
            try:
                self.server_socket.close()
            except:
                pass
        
        print("✅ Server stopped")
    
    def get_server_info(self) -> Dict:
        """Get server information for display."""
        return {
            'ip': self.local_ip,
            'port': self.port,
            'max_players': self.max_players,
            'connected_count': len(self.connection_manager.get_all_connected()),
            'running': self.running
        }
